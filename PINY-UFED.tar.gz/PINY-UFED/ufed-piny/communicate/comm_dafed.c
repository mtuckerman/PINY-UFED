/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: comm_groups.c                                */
/*                                                                          */
/* Subprogram creates group communicators                                   */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_math.h"

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void complete_dafed(CLASS *class, GENERAL_DATA *general_data)
/*=======================================================================*/
/*             Begin routine                                              */
{/*begin routine */
/*=======================================================================*/
/*             Local variable declarations                                */
  CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
  int myid                   = class->communicate_m.myid;
  MPI_Comm world             = class->communicate_m.world;
  DAFED *Ree, *Rgyr, *NH;
  DAFED_INFO *dinfo;  
  int npara_temps_proc       = general_data->tempering_ctrl.npara_temps_proc;
  int ipt;

/*=======================================================================*/

    printf("myid%i\n",myid);
    Ree = clatoms_info->Ree;
    Rgyr =clatoms_info->Rgyr;
    NH = clatoms_info->NH;
    dinfo = clatoms_info->daf_info;
    if(npara_temps_proc>1){
      for(ipt=2;ipt<=npara_temps_proc;ipt++){
         Ree[ipt].on_backup         = Ree[1].on_backup;
         Rgyr[ipt].on_backup        = Rgyr[1].on_backup;
         NH[ipt].on_backup          = NH[1].on_backup;
         Ree[ipt].kTs               = Ree[1].kTs;
         Rgyr[ipt].kTs              = Rgyr[1].kTs;
         NH[ipt].kTs                = NH[1].kTs;
         Ree[ipt].ms                = Ree[1].ms;
         Rgyr[ipt].ms               = Rgyr[1].ms;
         NH[ipt].ms                 = NH[1].ms;
         Ree[ipt].therm.tau         = Ree[1].therm.tau;
         Rgyr[ipt].therm.tau        = Rgyr[1].therm.tau;
         NH[ipt].therm.tau          = NH[1].therm.tau;
         Ree[ipt].therm.nr          = Ree[1].therm.nr;
         Rgyr[ipt].therm.nr         = Rgyr[1].therm.nr;
         NH[ipt].therm.nr           = NH[1].therm.nr;
         Ree[ipt].ks                = Ree[1].ks;
         Rgyr[ipt].ks               = Rgyr[1].ks;
         NH[ipt].ks                 = NH[1].ks;
         Ree[ipt].s                 = Ree[1].s;
         Rgyr[ipt].s                = Rgyr[1].s;
         NH[ipt].s                  = NH[1].s;
         dinfo[ipt].traj_fn         = dinfo[1].traj_fn;
         dinfo[ipt].traj_sr_fn      = dinfo[1].traj_sr_fn;
         dinfo[ipt].freq            = dinfo[1].freq;
         dinfo[ipt].to_file_freq    = dinfo[1].to_file_freq;
         dinfo[ipt].min_sep         = dinfo[1].min_sep;
         dinfo[ipt].n_respa         = dinfo[1].n_respa;
         dinfo[ipt].bias_on         = dinfo[1].bias_on;
         dinfo[ipt].steps_bias      = dinfo[1].steps_bias;
         dinfo[ipt].num_bias        = dinfo[1].num_bias;
      }/*endfor ipt*/
    }/*endif npara_temps_proc*/
  
/*========================================================================*/
}/*end routine*/
/*========================================================================*/



/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void comm_dafed(CLASS *class, GENERAL_DATA *general_data)
/*=======================================================================*/
/*             Begin routine                                              */
{/*begin routine */
/*=======================================================================*/
/*             Local variable declarations                                */

  CLATOMS_INFO *clatoms_info = &(class->clatoms_info);  
  DAFED *Ree,*Rgyr,*NH;
  DAFED_INFO *dinfo; 
  int *Ree_map,*Rgyr_map,*H_map,*O_map;
  int ipt;
  int myid                = class->communicate_m.myid;
  MPI_Comm world          = class->communicate_m.world;
  int npara_temps_proc    = general_data->tempering_ctrl.npara_temps_proc;
  int npara_temps         = general_data->simopts.npara_temps;
  MPI_Datatype daf;
  MPI_Datatype types[22];
  MPI_Aint displs[22];
  int blockcounts[22];
  int fn_len,sr_fn_len;
  

/*=======================================================================*/
  Barrier(world);
  if(myid==0){
    complete_dafed(class,general_data);
  }
  if(myid!=0){
    clatoms_info->Ree        = (DAFED *)cmalloc((2+npara_temps)*sizeof(DAFED))-0;
    clatoms_info->Rgyr       = (DAFED *)cmalloc((2+npara_temps)*sizeof(DAFED))-0;
    clatoms_info->NH         = (DAFED *)cmalloc((2+npara_temps)*sizeof(DAFED))-0;
    clatoms_info->daf_info   = (DAFED_INFO *)cmalloc((2+npara_temps)*sizeof(DAFED_INFO))-0;
    clatoms_info->Ree_map    = (int *)cmalloc(NMEM_MIN*sizeof(int))-1;
    clatoms_info->Rgyr_map   = (int *)cmalloc(NMEM_MIN*sizeof(int))-1;
    clatoms_info->H_map      = (int *)cmalloc(NMEM_MIN*sizeof(int))-1;
    clatoms_info->O_map      = (int *)cmalloc(NMEM_MIN*sizeof(int))-1;
  }
  Ree       = clatoms_info->Ree;
  Rgyr      = clatoms_info->Rgyr;
  NH        = clatoms_info->NH;
  dinfo     = clatoms_info->daf_info;
  Ree_map   = clatoms_info->Ree_map;
  Rgyr_map  = clatoms_info->Rgyr_map;
  H_map     = clatoms_info->H_map;
  O_map     = clatoms_info->O_map;
  Barrier(world);
/*  if(myid==0){
    fn_len = strlen(dinfo[1].traj_fn)+1;
    sr_fn_len = strlen(dinfo[1].traj_sr_fn)+1;
  }
  Barrier(world);
    Bcast(&fn_len,1,MPI_INT,0,world);
    Bcast(&sr_fn_len,1,MPI_INT,0,world);
  Barrier(world);
*/  
  for(ipt=1;ipt<=npara_temps_proc;ipt++){
     Barrier(world);
     if(myid!=0){
       dinfo[ipt].traj_fn = (char *)cmalloc(MAXWORD*sizeof(char))-1;
       dinfo[ipt].traj_sr_fn = (char *)cmalloc(MAXWORD*sizeof(char))-1;
     }
     Barrier(world);
     Address(&(Ree[ipt].on),&displs[0]);
     Address(&(Rgyr[ipt].on),&displs[1]);
     Address(&(NH[ipt].on),&displs[2]);
     Address(&(Ree[ipt].kTs),&displs[3]);
     Address(&(Rgyr[ipt].kTs),&displs[4]);
     Address(&(NH[ipt].kTs),&displs[5]);
     Address(&(dinfo[ipt].n_respa),&displs[6]);
     Address(&(Ree[ipt].therm.tau),&displs[7]);
     Address(&(Rgyr[ipt].therm.tau),&displs[8]);
     Address(&(NH[ipt].therm.tau),&displs[9]);
     Address(&(Ree[ipt].therm.nr),&displs[10]);
     Address(&(Rgyr[ipt].therm.nr),&displs[11]);
     Address(&(NH[ipt].therm.nr),&displs[12]);
     Address(dinfo[ipt].traj_fn,&displs[13]);
     Address(dinfo[ipt].traj_sr_fn,&displs[14]);
     Address(&(clatoms_info->num_Ree),&displs[15]);
     Address(Ree_map,&displs[16]);
     Address(Rgyr_map,&displs[17]);
     Address(H_map,&displs[18]);
     Address(O_map,&displs[19]);
     Address(&(dinfo[ipt].freq),&displs[20]);
     Address(&(dinfo[ipt].bias_on),&displs[21]);

     types[0] = MPI_INT;
     types[1] = MPI_INT;
     types[2] = MPI_INT;
     types[3] = MPI_DOUBLE;
     types[4] = MPI_DOUBLE;
     types[5] = MPI_DOUBLE;
     types[6] = MPI_INT;
     types[7] = MPI_DOUBLE;
     types[8] = MPI_DOUBLE;
     types[9] = MPI_DOUBLE;
     types[10] = MPI_INT;
     types[11] = MPI_INT;
     types[12] = MPI_INT;
     types[13] = MPI_CHAR;
     types[14] = MPI_CHAR;
     types[15] = MPI_INT;
     types[16] = MPI_INT;
     types[17] = MPI_INT;
     types[18] = MPI_INT;
     types[19] = MPI_INT;
     types[20] = MPI_INT;
     types[21] = MPI_INT;


     blockcounts[0] = 2;
     blockcounts[1] = 2;
     blockcounts[2] = 2;
     blockcounts[3] = 4;
     blockcounts[4] = 4;
     blockcounts[5] = 4;
     blockcounts[6] = 3;
     blockcounts[7] = 1;
     blockcounts[8] = 1;
     blockcounts[9] = 1;
     blockcounts[10] = 1;
     blockcounts[11] = 1;
     blockcounts[12] = 1;
     blockcounts[13] = MAXWORD;
     blockcounts[14] = MAXWORD;
     blockcounts[15] = 4;
     blockcounts[16] = NMEM_MIN;
     blockcounts[17] = NMEM_MIN;
     blockcounts[18] = NMEM_MIN;
     blockcounts[19] = NMEM_MIN;
     blockcounts[20] = 1;
     blockcounts[21] = 12;
         
     Barrier(world);
       Type_struct(21,blockcounts,displs,types,&daf);
     Barrier(world);
       Type_commit(&daf);
     Barrier(world);
       Bcast(MPI_BOTTOM,1,daf,0,world);
     Barrier(world);
       Type_free(&daf);
     Barrier(world);
  }/*endfor ipt*/

/*========================================================================*/
}/*end routine*/
/*========================================================================*/








