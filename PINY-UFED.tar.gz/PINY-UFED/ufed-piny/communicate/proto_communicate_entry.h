void communicate_interface(CLASS * , BONDED *, CP *,GENERAL_DATA *,
                           NULL_INTER_PARSE *,CLASS_PARSE *,CP_PARSE *,FILENAME_PARSE *);

void control_group_communicators(CLASS *,CP *,int);
