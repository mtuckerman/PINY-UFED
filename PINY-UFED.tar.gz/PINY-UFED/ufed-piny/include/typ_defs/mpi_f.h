#define MPI_Comm int
#define MPI_Datatype int
#define MPI_Aint int
#define MPI_Op int
#define MPI_Group int
#define MPI_Status int
#define MPI_Request int


