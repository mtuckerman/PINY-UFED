#include "../../integrate/cppimd/proto_integrate_cppimd_entry.h"
