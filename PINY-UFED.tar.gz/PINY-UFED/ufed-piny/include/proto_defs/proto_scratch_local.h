#include "../../interface/scratch/proto_scratch_local.h"
