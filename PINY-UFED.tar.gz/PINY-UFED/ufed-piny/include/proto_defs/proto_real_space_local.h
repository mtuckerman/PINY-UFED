#include "../../energy/inter/real_space/proto_real_space_local.h"
