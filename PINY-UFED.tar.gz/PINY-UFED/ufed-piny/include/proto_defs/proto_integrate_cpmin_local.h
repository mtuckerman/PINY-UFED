#include "../../integrate/cpmin/proto_integrate_cpmin_local.h"
