#include "../../energy/cp/proto_energy_cp_local.h"
