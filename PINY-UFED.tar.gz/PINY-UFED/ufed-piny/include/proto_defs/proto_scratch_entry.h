#include "../../interface/scratch/proto_scratch_entry.h"
