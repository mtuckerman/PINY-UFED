#include "../../energy/cp/proto_energy_cp_entry.h"
