#include "../../integrate/min/proto_integrate_min_local.h"
