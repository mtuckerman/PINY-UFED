#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_entry.h"
#include "../proto_defs/proto_dafed_helper.h"

inline void zero (double *d, int i) {

  int iii;
  for (iii = 1; iii <= i; iii++) d[iii] = 0.0;
}

void zero_forces(DAFED *daf, int i) {

  zero(daf->Fx, i);
  zero(daf->Fy, i);
  zero(daf->Fz, i);
}

inline void zero_stats(DAFED_STAT *ds) {

  ds->dkt = 0.0;
  ds->dte = 0.0;
  ds->dke = 0.0;
  ds->dpe = 0.0;

}
inline void zero_stats_avg(DAFED_STAT *ds) {

  ds->av_dkt = 0.0;
  ds->av_dte = 0.0;
  ds->av_dke = 0.0;
  ds->av_dpe = 0.0;

}
void zero_allstats(DAFED_STAT *ds) {
  zero_stats(ds);
  zero_stats_avg(ds);
}  

inline void total_dafed_energy(DAFED_STAT *ds, double *d) {
  *d  = ds->dte;
  *d += ds->dke;
  *d += ds->dpe;
}

void get_kt(DAFED *daf, double *d) {
  *d = pow(daf->vs,2)*daf->ms;
}
void get_ke(DAFED *daf, double *d) {
  get_kt(daf,d); 
  *d *= 0.5;
}

void get_dafed_therm_energy(GGMT *th, double *d,double *pe) {
  *d  = 0.5*(th->Q[1]*pow(th->vt[1],2) + th->Q[2]*pow(th->vt[2],2));
  *pe = th->kTs*(th->qt[1] + th->qt[2]);
  *d += *pe;
}
