#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_dafed_integrate.h"
#include "../proto_defs/proto_dafed_io.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_bias.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void bias_init(CLASS *class,GENERAL_DATA *general_data)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  STAT_AVG *stat_avg          = general_data->stat_avg;
  CLATOMS_INFO *clatoms_info  = &(class->clatoms_info);
  DAFED_INFO *dinfo           = clatoms_info->daf_info;
  DAFED *Ree                  = clatoms_info->Ree;
  DAFED *Rgyr                 = clatoms_info->Rgyr;
  DAFED *NH                   = clatoms_info->NH;
  DAFED *Dih_cor              = clatoms_info->Dih_cor;
  DAFED *Nalpha               = clatoms_info->Nalpha;
  DAFED *Nbeta                = clatoms_info->Nbeta;
  DAFED **Phi                 = clatoms_info->Phi;
  BIAS_PACK *bias;        
  F_HIST *hist;
  BIAS_HIST *bhist;
  int npara_temps_proc        = general_data->tempering_ctrl.npara_temps_proc;
  int ipt,i,j,k,ind,test,n_cv,i_bias,fun_prod;
  int num_phi                 = clatoms_info->num_phi;
  int bias_type;
  int num_bias;
  int num_co;
  int nfun_cv;
  int n_total,div,res,n_total_hist;
  int *n_bin_cv;
  int *n_bin_cv_hist;
  int *n_fun_cu;
  int *n_fun;

  double kTs_ini;
  double temp_diff;
  double scl_fac;
  double grad_scl_fac;
  double Ree_min,Rgyr_min,NH_min,Dc_min,Na_min,Nb_min,Phi_min;
  double Ree_max,Rgyr_max,NH_max,Dc_max,Na_max,Nb_max,Phi_max;
  double a,b;
  double *w_bin,*min,*max,*w_bin_hist;
  FILE *readin;

  //nblt
  int nblt_tot;
  int ind_s;
  int sum_exp;
  C_NBLT *nblt_array;

  /*-------------------------malloc------------------------------*/
  clatoms_info->bias = (BIAS_PACK*)cmalloc(npara_temps_proc*sizeof(BIAS_PACK))-1;
  for(ipt=1;ipt<=npara_temps_proc;ipt++){
    bias = &(clatoms_info->bias[ipt]);
    n_cv = stat_avg[ipt].n_cv;
    nfun_cv = dinfo[ipt].nfun_cv;
    num_co    = dinfo[ipt].nfun_tot;
    bias_type = dinfo[ipt].bias_type;
    stat_avg[ipt].i_bias = 0;
    stat_avg[ipt].bias_pot = 0.0;
    Ree_min = 0.0;
    Ree_max = 0.0;
    Rgyr_min = 5.2;
    Rgyr_max = 13.2;
    NH_min = 0.33;
    NH_max = 2.27;
    Dc_min = 0.0;
    Dc_max = 0.0;
    Na_min = 0.0;
    Na_max = 2.0;
    Nb_min = 0.0;
    Nb_max = 0.0;
    Phi_min = -M_PI;
    Phi_max = M_PI;
    /*if(n_cv>=3){
      printf("-----------Bias potential only support one or two dimmensional FES----------\n");
      fflush(stdout);
      exit(0);
    }*/
    /* Identify CVs  */
    
    bias->cv_type = (int *)cmalloc(n_cv*sizeof(int))-1;
    bias->min = (double *)cmalloc(n_cv*sizeof(double))-1;
    bias->max = (double *)cmalloc(n_cv*sizeof(double))-1;
    bias->w_bin = (double *)cmalloc(n_cv*sizeof(double))-1;
    bias->w_bin_hist = (double *)cmalloc(n_cv*sizeof(double))-1;
    w_bin = bias->w_bin;
    w_bin_hist = bias->w_bin_hist;
    min   = bias->min;
    max   = bias->max;

    ind = 0;
    if(Ree[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 1;
      bias->min[ind] = Ree_min;
      bias->max[ind] = Ree_max;
      w_bin[ind] = stat_avg[ipt].Ree_bin;
      w_bin_hist[ind] = stat_avg[ipt].Ree_bin;
      Ree[ipt].f_ave = 0.0;
    }
    if(Rgyr[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 2;
      bias->min[ind] = Rgyr_min;
      bias->max[ind] = Rgyr_max;
      w_bin[ind] = stat_avg[ipt].Rgyr_bin;
      w_bin_hist[ind] = stat_avg[ipt].Rgyr_bin;  
      Rgyr[ipt].f_ave = 0.0;

    }
    if(NH[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 3;
      bias->min[ind] = NH_min;
      bias->max[ind] = NH_max;
      w_bin[ind] = stat_avg[ipt].NH_bin;
      w_bin_hist[ind] = stat_avg[ipt].NH_bin;

      NH[ipt].f_ave = 0.0;
    }
    for(i=1;i<=num_phi;i++){
       ind += 1;
       bias->cv_type[ind] = 4;
       bias->min[ind] = Phi_min;
       bias->max[ind] = Phi_max;
       w_bin[ind] = stat_avg[ipt].Phi_bin;
       w_bin_hist[ind] = M_PI/150.0;

       Phi[ipt][i].f_ave = 0.0;
    }
    if(Dih_cor[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 5;
      bias->min[ind] = Dc_min;
      bias->max[ind] = Dc_max;
      w_bin[ind] = stat_avg[ipt].Dih_cor_bin;
      w_bin_hist[ind] = stat_avg[ipt].Dih_cor_bin;
      Dih_cor[ipt].f_ave = 0.0;
    }
    if(Nalpha[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 6;
      bias->min[ind] = Na_min;
      bias->max[ind] = Na_max;
      w_bin[ind] = stat_avg[ipt].Nalpha_bin;
      w_bin_hist[ind] = stat_avg[ipt].Nalpha_bin;
      Nalpha[ipt].f_ave = 0.0;
    }
    if(Nbeta[ipt].on>=1){
      ind += 1;
      bias->cv_type[ind] = 7;
      bias->min[ind] = Nb_min;
      bias->max[ind] = Nb_max;
      w_bin[ind] = stat_avg[ipt].Nbeta_bin;
      w_bin_hist[ind] = stat_avg[ipt].Nbeta_bin;
      Nbeta[ipt].f_ave = 0.0;
    }
    test = 0;
    for(i=1;i<=n_cv;i++){
       if(bias->cv_type[i]==4){test += 1;}
    }/*endfor n_cv*/
    bias->test_type = test;
    if(test!=0&&test!=n_cv){
      printf("-----------Mixed type is not ready yet----------------------------\n");
      fflush(stdout);
      exit(0);
    }
    /* Initialize coefficient stuff  */ 
      
    /*for(i=1;i<=n_cv;i++){
       bias->min[i] = 10000000.0;
       bias->max[i] = -1000000.0;
    }*/
    bias->n_fun = (int *)cmalloc(n_cv*sizeof(int))-1;
    n_fun = bias->n_fun;
    fun_prod = 1;
    for(i=1;i<=n_cv;i++){
       bias->n_fun[i] = nfun_cv;
       fun_prod *= nfun_cv;
    }
    /*temp use for ree na*/
    /*bias->n_fun[1] = 16;
    bias->n_fun[2] = 40;
    fun_prod = 640;*/
    /*-------------------*/
    if(fun_prod>=num_co){bias->n_coeff = num_co;}
    else{bias->n_coeff = fun_prod;}
    bias->coeff_list = (CO*)cmalloc(bias->n_coeff*sizeof(CO))-1;
    for(i=1;i<=bias->n_coeff;i++){
       bias->coeff_list[i].order = (ORD*)cmalloc(n_cv*sizeof(ORD))-1;
    }
    bias->coeff_force = (CO*)cmalloc(bias->n_coeff*sizeof(CO))-1;
    for(i=1;i<=bias->n_coeff;i++){
	    bias->coeff_force[i].order = (ORD*)cmalloc(n_cv*sizeof(ORD))-1;
    }
    n_bin_cv = (int*)cmalloc((1+n_cv)*sizeof(int))-1;
    n_bin_cv_hist = (int*)cmalloc((1+n_cv)*sizeof(int))-1;
    bias->n_bin_cv = n_bin_cv;
    bias->n_bin_cv_hist = n_bin_cv_hist;
    n_bin_cv[1+n_cv] = 1;
    n_bin_cv_hist[1+n_cv] = 1;
    i = 1;
    for(i=n_cv;i>=1;i--){
       a = min[i];
       b = max[i];
       n_bin_cv[i] = n_bin_cv[i+1]*(int)((b-a+0.0001*w_bin[i])/w_bin[i]);
       n_bin_cv_hist[i] = n_bin_cv_hist[i+1]*(int)((b-a+0.0001*w_bin_hist[i])/w_bin_hist[i]);
    }/*endfor n_cv*/
    n_total = n_bin_cv[1];
    n_total_hist = n_bin_cv_hist[1];

    bias->n_fun_cu = (int*)cmalloc((n_cv+1)*sizeof(int))-1;
    n_fun_cu = bias->n_fun_cu;
    n_fun_cu[n_cv+1] = 1;
    for(i=n_cv;i>=1;i--){
       n_fun_cu[i] = n_fun_cu[i+1]*n_fun[i];
    }

    /* for bias based on hist */
    hist = (F_HIST*)malloc(n_total*sizeof(F_HIST))-1;
    bias->hist = hist;
    for(i=1;i<=n_total;i++){
      hist[i].x = (double *)malloc(n_cv*sizeof(double))-1;
      hist[i].f_sum = (double *)malloc(n_cv*sizeof(double))-1;
      hist[i].f_ave = (double *)malloc(n_cv*sizeof(double))-1;
      hist[i].hist_sum = 0.0;
      hist[i].hist_log = 0.0;
      hist[i].num_bin = 0;
      //hist[i].gaussian_v = 0.0;
      res = i-1;
      for(j=1;j<=n_cv;j++){
         a = min[j];
         div = (int)(res/n_bin_cv[j+1]);
         res = res%n_bin_cv[j+1];
         hist[i].x[j] = a+(div+0.5)*w_bin[j];
         hist[i].f_sum[j] = 0.0;
      }
    }/*endfor n_bin_cv*/

    bhist = (BIAS_HIST*)malloc(n_total_hist*sizeof(BIAS_HIST))-1;
    bias->bhist = bhist;
    for(i=1;i<=n_total_hist;i++){
      bhist[i].x = (double *)malloc(n_cv*sizeof(double))-1;
      bhist[i].gaussian_v = 0.0;
      res = i-1;
      for(j=1;j<=n_cv;j++){
         a = min[j];
         div = (int)(res/n_bin_cv_hist[j+1]);
         res = res%n_bin_cv_hist[j+1];
         bhist[i].x[j] = a+(div+0.5)*w_bin_hist[j];
      }
    }/*endfor n_bin_cv*/



    num_bias = dinfo[ipt].num_bias;
    dinfo[ipt].nbin_total = 0;
    bias->A = dinfo[ipt].A;
    bias->sigma = dinfo[ipt].sigma;
    if(dinfo[ipt].fun_type==2){dinfo[ipt].nfun_gau = 0;}

    //initialize nblt
    nblt_tot = 1;
    for(i=0;i<n_cv;i++)nblt_tot *= 2;
    bias->nblt_tot = nblt_tot;
    bias->nblt_array = (C_NBLT*)cmalloc(nblt_tot*sizeof(C_NBLT));
    nblt_array = bias->nblt_array;
    for(i=0;i<nblt_tot;i++){
       nblt_array[i].diff = (int*)cmalloc(n_cv*sizeof(int));
    }
    printf("nblt %i\n",nblt_tot);
    for(i=0;i<nblt_tot;i++){
       ind = i;
       sum_exp = 0;
       for(j=0;j<n_cv;j++){
          printf("i %i j %i\n",i,j);
	  ind_s = (ind>>1)<<1;
          printf("ind %i ind_s %i\n",ind,ind_s);
          nblt_array[i].diff[j] = ind-ind_s;
          ind = ind>>1;
	  sum_exp += nblt_array[i].diff[j];
       }
       if(sum_exp%2==0)nblt_array[i].sign = 1.0;
       else nblt_array[i].sign = -1.0;
    }   
    //finish init nblt          
       
  }/*endfor ipt*/

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void bias_update(CLASS *class,GENERAL_DATA *general_data,int ipt, int i_bias)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  CLATOMS_INFO *clatoms_info     = &(class->clatoms_info);
  STAT_AVG *stat_avg             = &(general_data->stat_avg[ipt]);
  DATA_BIAS *data_b              = stat_avg->data;
  F_DATA *force_data             = stat_avg->force_data;
  BIAS_PACK *bias                = &(clatoms_info->bias[ipt]);
  DAFED_INFO *dinfo              = &(clatoms_info->daf_info[ipt]);
  DAFED *Ree                  = clatoms_info->Ree;
  DAFED *Rgyr                 = clatoms_info->Rgyr;
  DAFED *NH                   = clatoms_info->NH;
  DAFED *Dih_cor              = clatoms_info->Dih_cor;
  DAFED *Nalpha               = clatoms_info->Nalpha;
  DAFED *Nbeta                = clatoms_info->Nbeta;
  DAFED **Phi                 = clatoms_info->Phi;
  F_HIST *hist                = bias->hist;
  BIAS_HIST *bhist            = bias->bhist;
  CO *coeff,*coeff_f; 

  int num_bias                   = dinfo->num_bias;
  int n_cv                       = stat_avg->n_cv;
  int steps_bias                 = dinfo->steps_bias;
  int itime                      = general_data->timeinfo.itime;
  int test                       = bias->test_type;
  int num_phi                    = clatoms_info->num_phi;
  int *n_fun                     = bias->n_fun;
  int *cv_type                   = bias->cv_type;
  int *n_bin_cv                  = bias->n_bin_cv;
  int *n_bin_cv_hist             = bias->n_bin_cv_hist;
  int n_coeff                    = bias->n_coeff;
  int bias_readin                = dinfo->bias_readin;
  int bias_type                  = dinfo->bias_type;
  int fun_type                   = dinfo->fun_type;
  int nfun_gau                   = dinfo->nfun_gau;
  int steps_write                = dinfo->bias_write_freq;
  int *n_fun_cu                  = bias->n_fun_cu;
  int n_fun_total                = n_fun_cu[1];                
  int i,j,k,l,n_bin,ind_freq,count,n_total,iflag,ind,order,peak,n_total_hist;
  int iiflag;
  int i_bin,order_1,order_2;
  int *ind_pick;
  int div,res;
  double kT                      = clatoms_info->Rgyr[ipt].kTs; 
  double num_ca                  = (double)(clatoms_info->num_ca);
  double *min                    = bias->min;
  double *max                    = bias->max;
  double *w_bin                  = bias->w_bin;
  double *w_bin_hist             = bias->w_bin_hist;
  double sigma                   = bias->sigma;
  double rat_fac_bias;
  double a,b,prob,w_bin_prod,x,prod,sum,prefac,coeff_modu,coeff_max;
  double dist12;
  double *x1,*x2;
  double *min_old,*max_old;
  double *min_f,*max_f;
  double **bias_pot_value,**bias_pot_dev;
  double **Mat,*c;
  double **Ai_vec,*Aj_vec;
  double **B_v,**B_d;
  double **new_gau;
  double *coeff_vec;
  double temp_diff;
  double ***integ;
  double pi = 3.14159265358979323846;
  double sqrt_2 = 0.707106781;
  double radius = 0.5/sigma;
  double test_sum; //using for debug
  double *freq;
  FILE *file_1,*file_2;
  //for debug
  FILE *file_fes,*file_fave;
  
  dinfo->i_bias = i_bias;

  //for(i=1;i<=n_cv;i++){
  //   printf("min %lg,max %lg,w_bin %lg\n",min[i],max[i],w_bin[i]);
  //}

  n_total = n_bin_cv[1];
  n_total_hist = n_bin_cv_hist[1];
  ind_pick = (int*)cmalloc(n_coeff*sizeof(int))-1;
  //printf("finish setup bins\n");

  /*=======================================================================*/
  /*   update biased potential  */
  /*=======================================================================*/

  /* for bias based on hist */
  if(itime%steps_bias==0){
    update_gau(general_data,class,ipt);  
  }
  //printf("finish updating bias\n"); 

  //exit(0);
  if(itime%steps_write==0){ 
  /*=======================================================================*/
  /* Setup FES bins from data if necessary  */
  /*-------------------------------------------------------------------------*/
  /* Setup average force */
  /* for bias based on hist */
  for(i=1;i<=steps_write;i++){//add up new samples to the history
     ind_freq = 1;
     for(j=1;j<=n_cv;j++){
 	a = min[j];
	ind_freq += (int)((force_data[i].x[j]-a)/w_bin[j])*n_bin_cv[j+1];
     }
     if(ind_freq<=n_total&&ind_freq>=1){
       for(j=1;j<=n_cv;j++){
	  hist[ind_freq].f_sum[j] += force_data[i].f[j];
       }
       hist[ind_freq].num_bin += 1;
     } 
  }//endfor steps_bias
  printf("finish adding new samples\n");
  for(i=1;i<=n_total;i++){//calculate the average
     if(hist[i].num_bin!=0){
       for(j=1;j<=n_cv;j++){
          hist[i].f_ave[j] = hist[i].f_sum[j]/(double)(hist[i].num_bin);
       }
     }
  }
  //exit(0);
  printf("finish setup frequence\n");

  /*-------------------------------------------------------------------------*/
  /* Fit FES: 1.Molloc coefficient list*/

  if(fun_type==1){
    coeff_f = (CO*)cmalloc(n_fun_total*sizeof(CO))-1;
    for(i=1;i<=n_fun_total;i++){
       //coeff[i].type = (int*)cmalloc(n_cv*sizeof(int))-1;
       coeff_f[i].order = (ORD*)cmalloc(n_cv*sizeof(ORD))-1;
       res = i-1;
       for(j=1;j<=n_cv;j++){
      	  div = (int)(res/n_fun_cu[j+1]);
          res = res%n_fun_cu[j+1];
	  if(cv_type[j]!=4){
	    coeff_f[i].order[j].type = 0;
	  }
	  if(cv_type[j]==4){
	    if(div%2==0){
	      coeff_f[i].order[j].type = 1;
	    }
	    else{
	      coeff_f[i].order[j].type = 2;
	    }
          }/**/
          coeff_f[i].order[j].n = div;
       }/*endfor n_cv*/
    }/*endfor n_fun_total*/
  }//endif fun_type==1
  if(fun_type==2){
    //printf("nfun_gau %i\n",nfun_gau);
    n_fun_total = nfun_gau;
    new_gau = (double**)cmalloc((nfun_gau+steps_write)*sizeof(double*))-1;
    for(i=1;i<=nfun_gau+steps_write;i++){
       new_gau[i] = (double*)cmalloc(n_cv*sizeof(double))-1;
       if(i<=nfun_gau){
         for(j=1;j<=n_cv;j++){
	    new_gau[i][j] = bias->coeff_force[i].center[j];
	 }
       }
    }
    for(i=1;i<=steps_write;i++){
       iflag = 0;
       for(j=1;j<=n_fun_total;j++){
          if(dist(new_gau[j],force_data[i].x,n_cv)<radius){
	    iflag += 1;
	  }
       }
       for(j=1;j<=n_cv;j++){
          if(force_data[i].x[j]<min[j]||force_data[i].x[j]>max[j]){
	    iflag += 1;
	  }
       }
       if(iflag==0){
         n_fun_total += 1;
	 for(j=1;j<=n_cv;j++){
	    new_gau[n_fun_total][j] = force_data[i].x[j];
	 }
       }
    }
    coeff_f = (CO*)cmalloc(n_fun_total*sizeof(CO))-1;
    for(i=1;i<=n_fun_total;i++){
       coeff_f[i].center = (double*)cmalloc(n_cv*sizeof(double))-1;
       for(j=1;j<=n_cv;j++){
          coeff_f[i].center[j] = new_gau[i][j];
       }
    }
    dinfo->nfun_gau = n_fun_total;
    for(i=1;i<=nfun_gau+steps_write;i++){
       free(&(new_gau[i][1]));
    }
    free(&(new_gau[1]));
  }   
  //printf("finish step 1\n");
  //exit(0);
  printf("finish molloc coefficient\n");
  /*-------------------------------------------------------------------------*/
  /* Fit FES: 2.Constuct the Matrix and Vector*/
  Mat = (double**)cmalloc(n_fun_total*sizeof(double*))-1;
  for(i=1;i<=n_fun_total;i++){
     Mat[i] = (double*)cmalloc(n_fun_total*sizeof(double))-1;
  }
  c = (double*)cmalloc(n_fun_total*sizeof(double))-1;
  Ai_vec = (double**)cmalloc(n_fun_total*sizeof(double*))-1;
  for(i=1;i<=n_fun_total;i++){
     Ai_vec[i] = (double*)cmalloc(n_cv*sizeof(double))-1;
  }
  if(fun_type==1){
    B_v = (double**)cmalloc(n_cv*sizeof(double*))-1;
    B_d = (double**)cmalloc(n_cv*sizeof(double*))-1;
    for(i=1;i<=n_cv;i++){
       B_v[i] = (double*)cmalloc(n_fun[i]*sizeof(double))-1;
       B_d[i] = (double*)cmalloc(n_fun[i]*sizeof(double))-1;
    }
  }  
  for(i=1;i<=n_fun_total;i++){
     c[i] = 0.0;
     for(j=1;j<=n_fun_total;j++){
	//printf("i %i j %i\n",i,j);
	Mat[i][j] = 0.0;
     }
  }
  printf("finish initialized\n");
  if(fun_type==1){
    for(i_bin=1;i_bin<=n_total;i_bin++){
       for(i=1;i<=n_cv;i++){
         x = hist[i_bin].x[i];
         if(cv_type[i]!=4){
	    L_fun(B_v[i],B_d[i],n_fun[i],min[i],max[i],x);
         }
         if(cv_type[i]==4){
	    T_fun(B_v[i],B_d[i],n_fun[i],x);
         }
       }//get all functions' value and their derivative
       //printf("finish fun v d\n");
       for(i=1;i<=n_fun_total;i++){
          for(k=1;k<=n_cv;k++){
             Ai_vec[i][k] = 1.0;
             for(l=1;l<=n_cv;l++){
                order_1 = coeff_f[i].order[l].n+1;
                //printf("i %i,k %i,l %i,order_1 %i\n",i,k,l,order_1);
                if(l==k){
                  Ai_vec[i][k] *= B_d[l][order_1];
                }
                else{
	          Ai_vec[i][k] *= B_v[l][order_1];
                }
	     }
          }
       }
       for(i=1;i<=n_fun_total;i++){	        
          for(j=1;j<=n_fun_total;j++){
              for(k=1;k<=n_cv;k++){
                 Mat[i][j] += Ai_vec[i][k]*Ai_vec[j][k];
              }
          }
          for(k=1;k<=n_cv;k++){
             c[i] += Ai_vec[i][k]*hist[i_bin].f_ave[k];
          }
       }
    }
    for(i=1;i<=n_cv;i++){
       free(&(B_v[i][1]));
       free(&(B_d[i][1]));
    }
    free(&(B_v[1]));
    free(&(B_d[1]));
  }
  if(fun_type==2){
    for(i_bin=1;i_bin<=n_total;i_bin++){
       x1 = hist[i_bin].x;
       for(i=1;i<=n_fun_total;i++){
	  x2 = coeff_f[i].center;
          dist12 = dist(x1,x2,n_cv);
	  for(j=1;j<=n_cv;j++){
	     Ai_vec[i][j] = -2.0*sigma*(x1[j]-x2[j])*exp(-sigma*dist12);
          }
       }
       for(i=1;i<=n_fun_total;i++){
         for(j=1;j<=n_fun_total;j++){
             for(k=1;k<=n_cv;k++){
                 Mat[i][j] += Ai_vec[i][k]*Ai_vec[j][k];
             }
         }
         for(k=1;k<=n_cv;k++){
            c[i] += Ai_vec[i][k]*hist[i_bin].f_ave[k];
         }
       }
    }
  }//endif fun_type==2

  printf("finish Constucting the Matrix and Vector\n");
/*-------------------------------------------------------------------------*/
/* Fit FES: 3.Gauss elimination */

  coeff_vec = (double*)malloc(n_fun_total*sizeof(double))-1;
  
  Gauss_elim(Mat,coeff_vec,c,n_fun_total);

  for(i=1;i<=n_fun_total;i++){
     coeff_f[i].c = coeff_vec[i];
  }

  printf("finish Gauss elimination\n");
/*-------------------------------------------------------------------------*/
/* Fit FES: 4.Pick the important coeffcients  */
  if(fun_type==1){
    for(i=1;i<=n_coeff;i++){
       ind_pick[i] = 0;
    }
    for(i=1;i<=n_coeff;i++){
      coeff_max = 0.0;
      for(j=1;j<=n_fun_total;j++){
         coeff_modu = coeff_f[j].c*coeff_f[j].c;
         if(coeff_modu>=coeff_max&&find(j,ind_pick,n_coeff)==0){
           ind = j;
           coeff_max = coeff_modu;
         }
      }
      ind_pick[i] = ind;
    }
    for(i=1;i<=n_coeff;i++){
      for(j=1;j<=n_cv;j++){
        bias->coeff_force[i].order[j].n = coeff_f[ind_pick[i]].order[j].n;
        bias->coeff_force[i].order[j].type = coeff_f[ind_pick[i]].order[j].type;
      }
      bias->coeff_force[i].c = coeff_f[ind_pick[i]].c;
    }

  }
  if(fun_type==2){
    bias->coeff_force = (CO*)crealloc(&(bias->coeff_force[1]),n_fun_total*sizeof(CO))-1;
    for(i=1;i<=n_fun_total;i++){
       bias->coeff_force[i].center = (double*)cmalloc(n_cv*sizeof(double))-1;
       for(j=1;j<=n_cv;j++){
          bias->coeff_force[i].center[j] = coeff_f[i].center[j];
       }
       bias->coeff_force[i].c = coeff_f[i].c;
    }
  }
  //printf("finish step 4\n");  

  printf("finish picking important coeffcients\n");

  if(fun_type==1){
    for(i=1;i<=n_fun_total;i++){
       free(&(coeff_f[i].order[1]));
    }
  }
  if(fun_type==2){
    for(i=1;i<=n_fun_total;i++){
       free(&(coeff_f[i].center[1]));
    }
  }
  free(&(coeff_f[1]));
  for(i=1;i<=n_fun_total;i++){
     free(&(Mat[i][1]));
  }
  free(&(Mat[1]));
  free(&(c[1]));
  free(&(coeff_vec[1]));

  //exit(0);
/*-------------------------------------------------------------------------*/
/* IO:print coeffcient  */
  file_1 = fopen("FES_coeff_force","a");
  file_2 = fopen("Mesh_value","a");
  file_fave = fopen("force_ave","a");

  for(i=1;i<=n_cv;i++){
     fprintf(file_2,"%lg    ",min[i]);
     fprintf(file_fave,"%lg    ",min[i]);
  }
  fprintf(file_2,"\n");
  fprintf(file_fave,"\n");
  for(i=1;i<=n_cv;i++){
     fprintf(file_2,"%lg    ",max[i]);
     fprintf(file_fave,"%lg    ",max[i]);
  }
  fprintf(file_2,"\n");
  fprintf(file_fave,"\n");
  for(i=1;i<=n_cv;i++){
     fprintf(file_2,"%lg    ",w_bin_hist[i]);
     fprintf(file_fave,"%lg    ",w_bin[i]);
  }
  fprintf(file_2,"\n");
  fprintf(file_fave,"\n");
  for(i=1;i<=n_total;i++){
     for(j=1;j<=n_cv;j++){
        fprintf(file_fave,"%lg ",hist[i].x[j]);
     }
     for(j=1;j<=n_cv;j++){
        fprintf(file_fave,"%lg ",hist[i].f_ave[j]);
     }
     fprintf(file_fave,"\n");
  }
  
  for(i=1;i<=n_total_hist;i++){
     fprintf(file_2,"%lg\n",bhist[i].gaussian_v);
  }


   if(fun_type==1){  
    fprintf(file_1,"#                ");
    iflag = 0;
    for(i=1;i<=n_cv;i++){
      printf("index i %i\n",i);
      switch(cv_type[i]){
       case 1:fprintf(file_1,"Ree ");
              break;
       case 2:fprintf(file_1,"Rgyr ");
              break;
       case 3:fprintf(file_1,"NH ");
              break;
       case 5:fprintf(file_1,"Dih ");
              break;
       case 6:fprintf(file_1,"Na ");
              break;
       case 7:fprintf(file_1,"Nb ");
              break;
       case 4:iflag += 1;
              fprintf(file_1,"Phi%i ",iflag);
              break;
      }
    }/*endfor*/
    fprintf(file_1,"\n");
    fprintf(file_1,"                ");
    for(i=1;i<=n_cv;i++){
       fprintf(file_1,"%lg ",min[i]);
    }
    fprintf(file_1,"\n");
    fprintf(file_1,"                ");
    for(i=1;i<=n_cv;i++){
       fprintf(file_1,"%lg ",max[i]);
    }
    fprintf(file_1,"\n");
    for(i=1;i<=n_coeff;i++){
       fprintf(file_1,"%16.10lg ",bias->coeff_force[i].c);
       for(j=1;j<=n_cv;j++){
          fprintf(file_1,"%i %i ",bias->coeff_force[i].order[j].n,bias->coeff_force[i].order[j].type);
       }
       fprintf(file_1,"\n");
    }

    fprintf(file_1,"================================================\n");
  }//endif fun_type==1
  if(fun_type==2){
    fprintf(file_1,"        ");
    iflag = 0;
    for(i=1;i<=n_cv;i++){
      printf("index i %i\n",i);
      switch(cv_type[i]){
       case 1:fprintf(file_1,"Ree ");
              break;
       case 2:fprintf(file_1,"Rgyr ");
              break;
       case 3:fprintf(file_1,"NH ");
              break;
       case 5:fprintf(file_1,"Dih ");
              break;
       case 6:fprintf(file_1,"Na ");
              break;
       case 7:fprintf(file_1,"Nb ");
              break;
       case 4:iflag += 1;
              fprintf(file_1,"Phi%i ",iflag);
              break;
      }
    }/*endfor*/
    fprintf(file_1,"\n");
    for(i=1;i<=n_fun_total;i++){
       fprintf(file_1,"%16.10lg ",bias->coeff_force[i].c);
       for(j=1;j<=n_cv;j++){
          fprintf(file_1,"%lg ",bias->coeff_force[i].center[j]);
       }
       fprintf(file_1,"\n");
    }
  }//endif fun_type==2 

  fclose(file_1);
  fclose(file_2);
  fclose(file_fave);

  printf("finish printing\n");

/*-------------------------------------------------------------------------*/
/* Free all local variables  */

   free(&(ind_pick[1]));

   printf("finish freeing local varialbes\n");

  /* For debug input known coeff*/

   /*bias->min[1] = 5.56;
   bias->max[1] = 51.45;

   file_fes = fopen("coeff_debug","r");
   n_coeff = 10;
   bias->n_coeff = 10;
   bias->coeff_list = (CO *)cmalloc(n_coeff*sizeof(CO))-1;
  for(i=1;i<=n_coeff;i++){
    bias->coeff_list[i].order = (ORD*)cmalloc(n_cv*sizeof(ORD))-1;
  }
  for(i=1;i<=n_coeff;i++){
    fscanf(file_fes,"%lg",&(bias->coeff_list[i].c));
    for(j=1;j<=n_cv;j++){
      fscanf(file_fes,"%i",&(bias->coeff_list[i].order[j].n));
      fscanf(file_fes,"%i",&(bias->coeff_list[i].order[j].type));
    }
  }
  fclose(file_fes); */

  //exit(0);
}//endif itime%steps_write

/*-------------------------------------------------------------------------*/
/* Rescale parameters if necessary  */

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

double L_int(double a,double b,double x,double w_bin,int l)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double w_bin_n = w_bin*2.0/(b-a);
  double x_n     = (x - (a+b)*0.5)*2.0/(b-a);
  double integ   = 0.0;
  int k;
  //printf("x_n %lg\n",x_n);

  //printf("x %lg,an %lg,bn %lg\n",x,x_n-0.5*w_bin_n,x_n+0.5*w_bin_n);
  for(k=0;k<=(int)(l/2);k++){
     integ += pow(-1,k)*fact(2*l-2*k)/fact(k)/fact(l-k)/fact(l-2*k+1)*(pow(x_n+0.5*w_bin_n,l-2*k+1)-pow(x_n-0.5*w_bin_n,l-2*k+1));
  }
  return integ/pow(2.0,l);

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

int find(int target,int *source, int len)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  int i,flag;
  
  flag = 0;
 
  for(i=1;i<=len;i++){
     if(target==source[i]){flag += 1;}
  }
  return flag;
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

double fact(int n)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
 
  int i;
  double prod = 1.0;

  for(i=1;i<=n;i++){
     prod *= (double)(i);
  }
  return prod;
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

double power(double x,int n)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  int i;
  double prod = 1.0;

  for(i=1;i<=n;i++){
     prod *= x;
  }
  return prod;

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void calc_bias_pot(BIAS_PACK *bias,double *min_old,double *max_old,
                     double **bias_pot_value,int n_cv,int n_total)
/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  int i,j,k;
  double *L_value,*T_value;
  double *x;
  CO  *coeff                 = bias->coeff_list;
  F_HIST *hist               = bias->hist;
  int *cv_type               = bias->cv_type;
  int *n_fun                 = bias->n_fun;
  int n_coeff                = bias->n_coeff;
  
  double prod,a,b;
  int order;  

/*---------------------------malloc------------------------------------- */

   

/*-----------------------calc bias potential---------------------------- */
   for(i=1;i<=n_total;i++){
     x = hist[i].x;
     for(j=1;j<=n_cv;j++){
        if(cv_type[j]!=4){
          a = min_old[j];
          b = max_old[j];
          //s = 0.5*(b+a);
          //printf("cv %i,s %lg\n",j,s);
          L_value = (double *)cmalloc(n_fun[j]*sizeof(double))-1;
          L_fun_up(L_value,n_fun[j],a,b,x[j]);
          for(k=1;k<=n_coeff;k++){
            order = coeff[k].order[j].n;
            //bias_pot_value[k][j] = L_value[order+1]*sw_fun(s,a,b);//pay attention to a<=s<=b
            //bias_pot_dev[k][j]   = L_dev[order+1]*sw_fun(s,a,b)+L_value[order+1]*sw_fun_dev(s,a,b);
            //printf("order %i, i_cv %i, value %lg, dev %lg\n",order,j,bias_pot_value[k][j],bias_pot_dev[k][j]);
            bias_pot_value[k][j] = L_value[order+1];
          }
          free(&(L_value[1]));
        }/*endif cv_type[i]!=4*/
        else{
          T_value = (double *)cmalloc(bias->n_fun[j]*sizeof(double))-1;
          T_fun_up(T_value,n_fun[j],x[j]);
          for(k=1;k<=n_coeff;k++){
             order = coeff[k].order[j].n;
             bias_pot_value[k][j] = T_value[order+1];
          }
          free(&(T_value[1]));
        }/*end else*/
     }/*endfor n_cv*/
     for(j=1;j<=n_coeff;j++){
        prod = 1.0;
        for(k=1;k<=n_cv;k++){
           prod *= bias_pot_value[j][k];
        }
        hist[i].hist_log += coeff[j].c*prod;
    }

  }//endfor n_total

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/



/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void L_fun_up(double *L_value,int len,double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double x,order;
  int i;
  double b_a_1 = 1.0/(b-a);

  /*-----------------------------------------------------------------------*/
  /* Rescale s */

  if(s>=a&&s<=b){x = 2.0*s*b_a_1-(b+a)*b_a_1;}
  if(s<a){x = -1.0;}
  if(s>b){x = 1.0;}

  /*-----------------------------------------------------------------------*/
  /* Calculate Legendre polynomial */

  if(len==1){
    L_value[1] = 1.0;
  }
  else{
    L_value[1] = 1.0;
    L_value[2] = x;
  }
  for(i=3;i<=len;i++){
    order = (double)(i-2);
    L_value[i] = ((2.0*order+1.0)*x*L_value[i-1]-order*L_value[i-2])/(order+1.0);
  }


/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void T_fun_up(double *T_value,int len,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  int i,order;

  for(i=1;i<=len;i++){
     if(i%2==1){
       order = (int)((i-1)/2);
       if(i==1){
         T_value[i] = 1.0;
       }
       else{
         T_value[i] = cos(order*s);
       }
     }
     else{
       order = (int)(i/2);
       T_value[i] = sin(order*s);
     }
  }

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

void update_gau(GENERAL_DATA *general_data,CLASS *class,int ipt)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  CLATOMS_INFO *clatoms_info     = &(class->clatoms_info);
  STAT_AVG *stat_avg             = &(general_data->stat_avg[ipt]);
  DATA_BIAS *data_b              = stat_avg->data;
  F_DATA *force_data             = stat_avg->force_data;
  BIAS_PACK *bias                = &(clatoms_info->bias[ipt]);
  DAFED_INFO *dinfo              = &(clatoms_info->daf_info[ipt]);
  DAFED *Ree                  = clatoms_info->Ree;
  DAFED *Rgyr                 = clatoms_info->Rgyr;
  DAFED *NH                   = clatoms_info->NH;
  DAFED *Dih_cor              = clatoms_info->Dih_cor;
  DAFED *Nalpha               = clatoms_info->Nalpha;
  DAFED *Nbeta                = clatoms_info->Nbeta;
  DAFED **Phi                 = clatoms_info->Phi;
  BIAS_HIST *bhist            = bias->bhist;

  double *s_v;
  double *w_bin_hist               = bias->w_bin_hist; 
  double sigma                = bias->sigma;
  double A                    = bias->A;
  double dist12;
  double w_sigma = 0.5/sigma;
  double cutoff  = 25.0*w_sigma;

  
  int *cv_type                = bias->cv_type;
  int *n_bin_cv_hist          = bias->n_bin_cv_hist;
  int num_phi                 = clatoms_info->num_phi;
  int n_cv                    = stat_avg->n_cv;
  int n_total_hist            = n_bin_cv_hist[1];
  int i,j,k;
  int iflag;
  
  s_v = (double*)cmalloc(n_cv*sizeof(double))-1;
  iflag = 1;
  for(i=1;i<=n_cv;i++){
     switch(cv_type[i]){
       case 1: s_v[i] = Ree[ipt].s;break;
       case 2: s_v[i] = Rgyr[ipt].s;break;
       case 3: s_v[i] = NH[ipt].s;break;
       case 4: s_v[i] = Phi[ipt][iflag].s;iflag++;break;
       case 5: s_v[i] = Dih_cor[ipt].s;break;
       case 6: s_v[i] = Nalpha[ipt].s;break;
       case 7: s_v[i] = Nbeta[ipt].s;break;
     }
     //printf("s_v %lg\n",s_v[i]);
  }
  //for debug
  //for(i=1;i<=n_cv;i++)printf("%lg ",s_v[i]);
  //printf("\n");
  //for(i=1;i<=n_total_hist;i++){
  //   for(j=1;j<=n_cv;j++)printf("%lg ",bhist[i].x[j]);
  //   printf("\n");
  //}

  for(i=1;i<=n_total_hist;i++){
     //for(j=1;j<=n_cv;j++){
     //   printf("%lg ",hist[i].x[j]);
     //}  
     if(cv_type[1]!=4){
       dist12 =  dist(s_v,bhist[i].x,n_cv);
     }
     else{
       dist12 = dist_pod(s_v,bhist[i].x,n_cv,2.0*M_PI);
     }
     if(dist12<=cutoff){
       bhist[i].gaussian_v += A*exp(-sigma*dist12);
       //printf("g_v %lg\n",hist[i].gaussian_v);
     }
  }
  free(&(s_v[1]));

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

















