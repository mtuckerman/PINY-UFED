/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: communicate_output_pimd.c                    */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_output_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_friend_lib_entry.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void communicate_output_pimd(CLASS *class,int ipt)

/*======================================================================*/
/*                Begin Routine */
{   /*begin routine */

#include "../typ_defs/typ_mask.h"

  double *scr_x,*scr_temp_x;
  double *scr_y,*scr_temp_y;
  double *scr_z,*scr_temp_z;
  double *scr_nhc_x,*scr_temp_nhc_x;
  int ip,ipp,ippp,ipart,ii,num,i,j,k;
  int iproc,iii;
  int n2,n3;

  int len_nhc       = class->therm_info_bead[ipt].len_nhc;
  int num_nhc       = class->therm_info_bead[ipt].num_nhc;
  int natm_tot      = class->clatoms_info.natm_tot;
  int pi_beads      = class->clatoms_info.pi_beads;
  int pi_beads_proc = class->clatoms_info.pi_beads_proc;

  int myid_m        = class->communicate_m.myid;
  int myid_temper   = class->communicate.myid_temper;
  int num_proc      = class->communicate.np_beads;
  int myid          = class->communicate.myid_bead;
  MPI_Comm world    = class->communicate.comm_beads;

  if( (pi_beads % num_proc)!=0 && myid_m==0){
    printf("Oops : fix communicate_output_pimd.c\n");
    printf("pi_beads_proc current must be the same on all procs\n");
    printf("Lazy programmers\n");
    Finalize();
    exit(1);
  }/*endif*/

/*========================================================================*/
/* I) Malloc the memory                                                   */

  if(myid==0){
    scr_x     = (double *)malloc(pi_beads*natm_tot*sizeof(double)) -1;
    scr_y     = (double *)malloc(pi_beads*natm_tot*sizeof(double)) -1;
    scr_z     = (double *)malloc(pi_beads*natm_tot*sizeof(double)) -1;
    num       = pi_beads*len_nhc*num_nhc;
    scr_nhc_x = (double *)cmalloc(num*sizeof(double)) -1;
  }/*endif*/

  if(myid>0){
    scr_temp_x = (double *)malloc(pi_beads_proc*natm_tot*sizeof(double)) -1;
    scr_temp_y = (double *)malloc(pi_beads_proc*natm_tot*sizeof(double)) -1;
    scr_temp_z = (double *)malloc(pi_beads_proc*natm_tot*sizeof(double)) -1;
    num       = pi_beads_proc*len_nhc*num_nhc;
    scr_temp_nhc_x = (double *)cmalloc(num*sizeof(double)) -1;
  }/*endif*/

/*========================================================================*/
/* III) Send the positions, in order, to processor 0                      */

  if(myid>0){
    ii = 0;
    for(ipp=1;ipp<=pi_beads_proc;ipp++){
      ip=(ipt-1)*pi_beads_proc+ipp;
      for(ipart=1;ipart<=natm_tot;ipart++){
        ii++;
        scr_temp_x[ii] = class->clatoms_pos[ip].x[ipart]; 
        scr_temp_y[ii] = class->clatoms_pos[ip].y[ipart]; 
        scr_temp_z[ii] = class->clatoms_pos[ip].z[ipart]; 
      }/*endfor : number of atm's */
    }/*endfor : number of beads */
  }/* endif : myid>0 */


  if(myid>0){
    Send(&scr_temp_x[1],(pi_beads_proc)*(natm_tot),
                      MPI_DOUBLE,0,myid,world);
    Send(&scr_temp_y[1],(pi_beads_proc)*(natm_tot),
                      MPI_DOUBLE,0,myid,world);
    Send(&scr_temp_z[1],(pi_beads_proc)*(natm_tot),
                      MPI_DOUBLE,0,myid,world);
  }/*endif*/


  if(myid==0){
    for(iproc=1;iproc<num_proc;iproc++){
        Recv(&(scr_x[(iproc-1)*pi_beads_proc*natm_tot+1]),
           (pi_beads_proc)*(natm_tot),MPI_DOUBLE,
                    iproc,iproc,world);
        Recv(&(scr_y[(iproc-1)*pi_beads_proc*natm_tot+1]),
           (pi_beads_proc)*(natm_tot),MPI_DOUBLE,
                    iproc,iproc,world);
        Recv(&(scr_z[(iproc-1)*pi_beads_proc*natm_tot+1]),
           (pi_beads_proc)*(natm_tot),MPI_DOUBLE,
                    iproc,iproc,world);
    }/*endfor*/
  }/*endif*/    

  if(myid==0){
    for(ipp=1;ipp<=pi_beads_proc;ipp++){
      ip=(ipt-1)*pi_beads+ipp;
      ippp = (ipt-1)*pi_beads_proc+ipp;
      for(ipart=1;ipart<=natm_tot;ipart++){
        class->clatoms_tmp[ip].x[ipart] = class->clatoms_pos[ippp].x[ipart];
        class->clatoms_tmp[ip].y[ipart] = class->clatoms_pos[ippp].y[ipart];
        class->clatoms_tmp[ip].z[ipart] = class->clatoms_pos[ippp].z[ipart];
      }
    }/*endfor : copy out my guys */
    ii = 0;
    for(ipp=pi_beads_proc+1;ipp<=pi_beads;ipp++){
      ip=(ipt-1)*pi_beads+ipp;
      for(ipart=1;ipart<=natm_tot;ipart++){
        ii++;
        class->clatoms_tmp[ip].x[ipart] = scr_x[ii];
        class->clatoms_tmp[ip].y[ipart] = scr_y[ii];
        class->clatoms_tmp[ip].z[ipart] = scr_z[ii];
      }/*endfor : number of atm's */
    }/*endfor : copy out everyone elses beads */
  }/* endif : myid=0 */

/*========================================================================*/
/* IV ) Send the velocities, in order, to processor 0                     */

  ii = 0;
  if(myid>0){
    for(ipp=1;ipp<=pi_beads_proc;ipp++){
      ip=(ipt-1)*pi_beads_proc+ipp;
      for(ipart=1;ipart<=natm_tot;ipart++){
        ii++;
        scr_temp_x[ii] = class->clatoms_pos[ip].vx[ipart]; 
        scr_temp_y[ii] = class->clatoms_pos[ip].vy[ipart]; 
        scr_temp_z[ii] = class->clatoms_pos[ip].vz[ipart]; 
      }/*endfor : number of atm's */
    }/*endfor : number of beads */
  }/* endif : myid>0 */

  if(myid>0){
    Send(&scr_temp_x[1],(pi_beads_proc)*(natm_tot),
                      MPI_DOUBLE,0,myid,world);
    Send(&scr_temp_y[1],(pi_beads_proc)*(natm_tot),
                      MPI_DOUBLE,0,myid,world);
    Send(&scr_temp_z[1],(pi_beads_proc)*(natm_tot),
                      MPI_DOUBLE,0,myid,world);
  }/*endif*/

  if(myid==0){
    for(iproc=1;iproc<num_proc;iproc++){
        Recv(&(scr_x[(iproc-1)*pi_beads_proc*natm_tot+1]),
           (pi_beads_proc)*(natm_tot),MPI_DOUBLE,
                    iproc,iproc,world);
        Recv(&(scr_y[(iproc-1)*pi_beads_proc*natm_tot+1]),
           (pi_beads_proc)*(natm_tot),MPI_DOUBLE,
                    iproc,iproc,world);
        Recv(&(scr_z[(iproc-1)*pi_beads_proc*natm_tot+1]),
           (pi_beads_proc)*(natm_tot),MPI_DOUBLE,
                    iproc,iproc,world);
    }/*endfor*/
  }/*endif*/    

  if(myid==0){
    for(ipp=1;ipp<=pi_beads_proc;ipp++){
      ip=(ipt-1)*pi_beads+ipp;
      ippp = (ipt-1)*pi_beads_proc+ipp;
      for(ipart=1;ipart<=natm_tot;ipart++){
        class->clatoms_tmp[ip].vx[ipart] = class->clatoms_pos[ippp].vx[ipart];
        class->clatoms_tmp[ip].vy[ipart] = class->clatoms_pos[ippp].vy[ipart];
        class->clatoms_tmp[ip].vz[ipart] = class->clatoms_pos[ippp].vz[ipart];
      }
    }
    ii = 0;
    for(ipp=pi_beads_proc+1;ipp<=pi_beads;ipp++){
      ip=(ipt-1)*pi_beads+ipp;
      for(ipart=1;ipart<=natm_tot;ipart++){
        ii++;
        class->clatoms_tmp[ip].vx[ipart] = scr_x[ii];
        class->clatoms_tmp[ip].vy[ipart] = scr_y[ii];
        class->clatoms_tmp[ip].vz[ipart] = scr_z[ii];
      }/*endfor : number of atm's */
    }/*endfor : number of beads */
  }/* endif : myid=0 */

/*========================================================================*/
/* IV ) Send the NHC velocities, in order, to processor 0                 */

  if(myid>0){
    ii = 0;
    for(ipp=1;ipp<= pi_beads_proc; ipp++){
      ip=(ipt-1)*pi_beads_proc+ipp;
       for(j=1;j<=(len_nhc);j++){
          for(i=1;i<=(num_nhc);i++){
  	      ii++;
              scr_temp_nhc_x[ii] = class->therm_bead[ip].v_nhc[j][i];
          }/*endfor : nhc length */
       }/*endfor : number of nhc's */
    }/*endfor : number of beads */
  }/* endif : myid>0 */

  if(myid>0){
    Send(&scr_temp_nhc_x[1],pi_beads_proc*len_nhc*num_nhc,
                      MPI_DOUBLE,0,myid,world);
  }/*endif*/

  if(myid==0){
    for(iproc=1;iproc<num_proc;iproc++){
        Recv(&(scr_nhc_x[(iproc-1)*pi_beads_proc*len_nhc*num_nhc+1]),
          pi_beads_proc*len_nhc*num_nhc,MPI_DOUBLE,
                    iproc,iproc,world);
    }/*endfor*/
  }/*endif*/    

  if(myid==0){
    for(ipp=1;ipp<=pi_beads_proc;ipp++){
      ip=(ipt-1)*pi_beads+ipp;
      ippp = (ipt-1)*pi_beads_proc+ipp;
       for(j=1;j<=(len_nhc);j++){
          for(i=1;i<=(num_nhc);i++){
	    class->clatoms_tmp[ip].v_nhc[j][i] = class->therm_bead[ippp].v_nhc[j][i];
	  }
       }
    }
    ii =0;
    for(ipp=pi_beads_proc+1;ipp<= pi_beads; ipp++){
      ip=(ipt-1)*pi_beads+ipp;
       for(j=1;j<=(len_nhc);j++){
          for(i=1;i<=(num_nhc);i++){
            ii++;
            class->clatoms_tmp[ip].v_nhc[j][i] = scr_nhc_x[ii];
         }/*endfor : nhc length */
      }/*endfor : number of nhc's */
    }/*endfor : number of beads */
  }/*endif*/

 if(myid==0){
     cfree(&(scr_x[1]));
     cfree(&(scr_y[1]));
     cfree(&(scr_z[1]));
     cfree(&(scr_nhc_x[1]));
 }else{
     cfree(&(scr_temp_x[1]));
     cfree(&(scr_temp_y[1]));
     cfree(&(scr_temp_z[1]));
     cfree(&(scr_temp_nhc_x[1]));
 }/*endif*/

/*========================================================================*/
   }/*end routine*/
/*========================================================================*/









