/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: mall_coord                                   */
/*                                                                          */
/* This subprogram reads atm-atm_NHC vol-vol_NHC input for a MD on a        */ 
/* LD-classical potential energy surface (LD-PES)                           */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_coords_local.h"
#include "../proto_defs/proto_friend_lib_entry.h"

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void mall_coord(CLASS *class,GENERAL_DATA *general_data)

/*======================================================================*/
/*                Begin Routine */
{   /*begin routine */
/*======================================================================*/
/*               Local variable declarations                            */

  int i,iii,moff;
  int ist,iend;
  int pimd_on;           /* below */
  int nhess_mall;        /* below */
  int myid_m             = class->communicate_m.myid;
  int pi_beads_proc      = class->clatoms_info.pi_beads_proc;
  int pi_beads           = class->clatoms_info.pi_beads;
  int natm_mall          = class->clatoms_info.natm_mall;
  int natm_tot           = class->clatoms_info.natm_tot;
  int np                 = class->communicate_m.np;
  int npara_temps        = general_data->simopts.npara_temps_proc;
  int npara_temps2       = npara_temps;
  int natm_mall_tot;
  double *chunk;

  int ioff     = 1;
  int ioff_s   = 1;

  /* parallel malloc sizes : just a tad more */
  if(np>1){
    npara_temps2 += 2; 
    ioff          = -(pi_beads_proc-1);
    ioff_s        = 0;
  }/*endif*/

/*========================================================================*/
/* I) Malloc the vector structures                                        */

  pimd_on = general_data->simopts.pimd 
          + general_data->simopts.cp_pimd 
          + general_data->simopts.cp_wave_pimd 
          + general_data->simopts.cp_wave_min_pimd 
          + general_data->simopts.debug_pimd 
          + general_data->simopts.debug_cp_pimd;

  /* Extra space */
  if(pimd_on==1){   
   class->therm_bead  = (THERM_POS *)cmalloc(pi_beads_proc *npara_temps2*
                              sizeof(THERM_POS))-ioff;
  }/*endif*/

  class->clatoms_pos  = (CLATOMS_POS *)cmalloc(npara_temps2*pi_beads_proc*
                                               sizeof(CLATOMS_POS))-ioff;
  /* input/output only */
  if(pimd_on==1){
    class->clatoms_tmp  = (CLATOMS_TMP *)cmalloc(npara_temps*pi_beads*
                                               sizeof(CLATOMS_TMP))-1;
  }/*endif*/

  class->clatoms_info.ioff_temper  = (int *)cmalloc(npara_temps*sizeof(int))-1;
  for(i=1;i<=npara_temps;i++){
    class->clatoms_info.ioff_temper[i] = pi_beads_proc*(i-1);
  }/*endif*/

/*========================================================================*/
/* I) Malloc atom positions, velocities, and forces                       */

  for(i=1;i<=npara_temps;i++){
   (class->clatoms_sysinfo)[i].roll_sc =
                                 (double *)cmalloc(natm_mall*sizeof(double))-1;
   (class->clatoms_sysinfo)[i].prekf=
                                 (double *)cmalloc(natm_mall*sizeof(double))-1;
  }/*endfor*/

  natm_mall_tot = natm_mall*9+2; /* the "+2" is a dirty trick, to send 2 ints*/
  if(pimd_on==1){natm_mall_tot += 9*natm_mall;}
#ifdef REAL_PARA
  natm_mall_tot += 3*natm_mall;
  if(pimd_on==1){natm_mall_tot += 3*natm_mall;}
#endif
  /* Mess with the cool malloc and you, my friend are toast! */
  ist = 1; iend=0;
  if(npara_temps != npara_temps2){
    ist = 1-pi_beads_proc; iend=1;
  }/*endif*/

  for(i=ist;i<=pi_beads_proc*(npara_temps+iend);i++){
   moff  = 0;
   chunk = (double *)cmalloc(natm_mall_tot*sizeof(double));
   (class->clatoms_pos)[i].x  = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].y  = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].z  = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].fx = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].fy = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].fz = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].vx = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].vy = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].vz = &(chunk[moff])-1; moff+=natm_mall;
#ifdef REAL_PARA
   (class->clatoms_pos)[i].fx_t = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].fy_t = &(chunk[moff])-1; moff+=natm_mall;
   (class->clatoms_pos)[i].fz_t = &(chunk[moff])-1; moff+=natm_mall;
#endif
   moff+=2;
#define DBG_MALL_COORD_OFF
#ifdef DBG_MALL_COORD
   printf("DBG_MALL_COORD : %d %d : %p %p\n",myid_m,i,&chunk[0],&chunk[(moff-1)]);
#endif
   if(pimd_on==1){
     (class->clatoms_pos)[i].fxt  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].fyt  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].fzt  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].fxm  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].fym  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].fzm  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].xmod = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].ymod = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].zmod = &(chunk[moff])-1; moff+=natm_mall;
#ifdef REAL_PARA
     (class->clatoms_pos)[i].fxt_t  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].fyt_t  = &(chunk[moff])-1; moff+=natm_mall;
     (class->clatoms_pos)[i].fzt_t  = &(chunk[moff])-1; moff+=natm_mall;

#endif
     (class->clatoms_pos)[i].mass = (double *)
                                  cmalloc(natm_mall*sizeof(double))-1;
   }else{
    (class->clatoms_pos)[i].xold = (double *)
                                  cmalloc(natm_mall*sizeof(double))-1;
    (class->clatoms_pos)[i].yold = (double *)
                                  cmalloc(natm_mall*sizeof(double))-1;
    (class->clatoms_pos)[i].zold = (double *)
                                  cmalloc(natm_mall*sizeof(double))-1;
   }/*endif*/
  }/*endfor*/

  if(pimd_on==1){
    for(i=1;i<=pi_beads*npara_temps;i++){
      (class->clatoms_tmp)[i].x   = (double *)cmalloc(natm_mall*sizeof(double))-1;
      (class->clatoms_tmp)[i].y   = (double *)cmalloc(natm_mall*sizeof(double))-1;
      (class->clatoms_tmp)[i].z   = (double *)cmalloc(natm_mall*sizeof(double))-1;
      (class->clatoms_tmp)[i].vx  = (double *)cmalloc(natm_mall*sizeof(double))-1;
      (class->clatoms_tmp)[i].vy  = (double *)cmalloc(natm_mall*sizeof(double))-1;
      (class->clatoms_tmp)[i].vz  = (double *)cmalloc(natm_mall*sizeof(double))-1;
    }/*endfor*/
  }/*endif*/

/*========================================================================*/
/* II) Malloc atomic hessian if necessary                                 */

  nhess_mall = (class->clatoms_info.hess_calc > 1 ? 
                natm_tot*natm_tot : natm_tot);
  
  if(class->clatoms_info.hess_calc > 0){
    class->clatoms_pos[1].hess_xx = 
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_xy = 
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_xz = 
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_yy = 
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_yz = 
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_zz = 
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
#ifdef REAL_PARA
    class->clatoms_pos[1].hess_xx_t =
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_xy_t =
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_xz_t =
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_yy_t =
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_yz_t =
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
    class->clatoms_pos[1].hess_zz_t =
               (double *)cmalloc(nhess_mall*sizeof(double))-1;
#endif
  }/* end if */

/*========================================================================*/
    }/* end routine */
/*==========================================================================*/









