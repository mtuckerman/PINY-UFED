
#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_energy_ctrl_entry.h"
#include "../proto_defs/proto_intra_entry.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_real_space_entry.h"
#include "../proto_defs/proto_recip3d_entry.h"
#include "../proto_defs/proto_energy_ctrl_local.h"
#include "../proto_defs/proto_intra_con_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_helper.h"


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void force_dafed_final(CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos,
                       STAT_AVG *stat_avg,int ipt) { 


/*========================================================================*/
/*========================================================================*/

  int    iii,i,index_phi;

  DAFED *Ree          = &(clatoms_info->Ree[ipt]);
  DAFED *Rgyr         = &(clatoms_info->Rgyr[ipt]);
  DAFED *NH           = &(clatoms_info->NH[ipt]);
  DAFED *Dih_cor      = &(clatoms_info->Dih_cor[ipt]);
  DAFED *Nalpha       = &(clatoms_info->Nalpha[ipt]);
  DAFED *Nbeta        = &(clatoms_info->Nbeta[ipt]);
  DAFED *Phi          = clatoms_info->Phi[ipt];
  DAFED *Phi_l;
  DAFED_INFO *dinfo   = &(clatoms_info->daf_info[ipt]);
  DAFED_STAT *ds_ree  = &(stat_avg->ds_ree);
  DAFED_STAT *ds_rgyr = &(stat_avg->ds_rgyr);
  DAFED_STAT *ds_nh   = &(stat_avg->ds_nh);
  DAFED_STAT *ds_phi  = stat_avg->ds_phi;
  DAFED_STAT *ds_nalpha  = &(stat_avg->ds_nalpha);
  DAFED_STAT *ds_nbeta   = &(stat_avg->ds_nbeta);
  DAFED_STAT *ds_dih_cor = &(stat_avg->ds_dih_cor); 
   
  double *clatoms_fx	= clatoms_pos[ipt].fx;
  double *clatoms_fy	= clatoms_pos[ipt].fy;
  double *clatoms_fz	= clatoms_pos[ipt].fz;
  double *Fx,*Fy,*Fz;

  int myatm_start = clatoms_info->myatm_start;
  int myatm_end = clatoms_info->myatm_end;
  int num_phi = clatoms_info->num_phi;
  int calc_flag = dinfo->calc_flag;
  int n_atm_f;
  int index;
  int *atm_fl;
  //double start,end;

  //cputime(&start);
// IC: only atoms between myatm_start and my_atm_end are updated
  if (Ree->on == 1 || Ree->on == 3){
    n_atm_f = Ree->n_atm_f;
    atm_fl  = Ree->atm_fl;
    Fx      = Ree->Fx;
    Fy      = Ree->Fy;
    Fz      = Ree->Fz;
    for(iii=1;iii<=n_atm_f;iii++){
      index = atm_fl[iii];
      if(index>=myatm_start&&index<=myatm_end){
        clatoms_fx[index] += Fx[iii];
        clatoms_fy[index] += Fy[iii];
        clatoms_fz[index] += Fz[iii];
      }
    }
   }
  if (Rgyr->on == 1 || Rgyr->on == 3){
    n_atm_f = Rgyr->n_atm_f;
    atm_fl  = Rgyr->atm_fl;
    Fx      = Rgyr->Fx;
    Fy      = Rgyr->Fy;
    Fz      = Rgyr->Fz;
    for(iii=1;iii<=n_atm_f;iii++){
      index = atm_fl[iii];
      if(index>=myatm_start&&index<=myatm_end){
        clatoms_fx[index] += Fx[iii];
        clatoms_fy[index] += Fy[iii];
        clatoms_fz[index] += Fz[iii];
      }
    }
   }
  if (NH->on == 1 || NH->on == 3){
    n_atm_f = NH->n_atm_f;
    atm_fl  = NH->atm_fl;
    Fx      = NH->Fx;
    Fy      = NH->Fy;
    Fz      = NH->Fz;
    for(iii=1;iii<=n_atm_f;iii++){
      index = atm_fl[iii];
      if(index>=myatm_start&&index<=myatm_end){
        clatoms_fx[index] += Fx[iii];
        clatoms_fy[index] += Fy[iii];
        clatoms_fz[index] += Fz[iii];
      }
    }
   }
  if (Dih_cor->on == 1 || Dih_cor->on == 3){
    n_atm_f = Dih_cor->n_atm_f;
    atm_fl  = Dih_cor->atm_fl;
    Fx      = Dih_cor->Fx;
    Fy      = Dih_cor->Fy;
    Fz      = Dih_cor->Fz;
    for(iii=1;iii<=n_atm_f;iii++){
      index = atm_fl[iii];
      if(index>=myatm_start&&index<=myatm_end){
        clatoms_fx[index] += Fx[iii];
        clatoms_fy[index] += Fy[iii];
        clatoms_fz[index] += Fz[iii];
      }
    }
   }
  if (Nalpha->on == 1 || Nalpha->on == 3){
    n_atm_f = Nalpha->n_atm_f;
    atm_fl  = Nalpha->atm_fl;
    Fx      = Nalpha->Fx;
    Fy      = Nalpha->Fy;
    Fz      = Nalpha->Fz;
    for(iii=1;iii<=n_atm_f;iii++){
      index = atm_fl[iii];
      if(index>=myatm_start&&index<=myatm_end){
        clatoms_fx[index] += Fx[iii];
        clatoms_fy[index] += Fy[iii];
        clatoms_fz[index] += Fz[iii];
      }
    }
   }
  if (Nbeta->on == 1 || Nbeta->on == 3){
    n_atm_f = Nbeta->n_atm_f;
    atm_fl  = Nbeta->atm_fl;
    Fx      = Nbeta->Fx;
    Fy      = Nbeta->Fy;
    Fz      = Nbeta->Fz;
    for(iii=1;iii<=n_atm_f;iii++){
      index = atm_fl[iii];
      if(index>=myatm_start&&index<=myatm_end){
        clatoms_fx[index] += Fx[iii];
        clatoms_fy[index] += Fy[iii];
        clatoms_fz[index] += Fz[iii];
      }
    }
   }

   for(index_phi =1;index_phi<=num_phi;index_phi++){
      Phi_l = Phi+index_phi;
      if (Phi_l->on == 1 || Phi_l->on == 3){
         n_atm_f = Phi_l->n_atm_f;
         atm_fl  = Phi_l->atm_fl;
         Fx      = Phi_l->Fx;
         Fy      = Phi_l->Fy;
         Fz      = Phi_l->Fz;
        for(iii=1;iii<=n_atm_f;iii++){
           index = atm_fl[iii];
           if(index>=myatm_start&&index<=myatm_end){
             clatoms_fx[index] += Fx[iii];
             clatoms_fy[index] += Fy[iii];
             clatoms_fz[index] += Fz[iii];
           }
        }
      }
   }

  //cputime(&end);
  //dinfo[ipt].difftime += end-start;
  //printf("bias_on %i,i_bias %i, calc_flag %i\n",dinfo->bias_on,stat_avg->i_bias,calc_flag);
  if(dinfo->bias_on==1){
    if(dinfo->bias_readin==1||stat_avg->i_bias>=1){
      //printf("calc_flag %i\n",calc_flag);
      if(calc_flag==1){
        force_bias_num_hd(clatoms_info,stat_avg,ipt);
      }
    }
  }
  if (Ree->on  == 1|| Ree->on == 3) { 
    zero_stats(ds_ree);
    ds_ree->dpe     = Ree->pote;
  }
  if (Rgyr->on  == 1|| Rgyr->on == 3) { 
    zero_stats(ds_rgyr);
    ds_rgyr->dpe     = Rgyr->pote;
  }
  if (NH->on  == 1||NH->on == 3) { 
    zero_stats(ds_nh);
    ds_nh->dpe     = NH->pote;
  }
  if (Dih_cor->on  == 1||Dih_cor->on == 3) {
    zero_stats(ds_dih_cor);
    ds_dih_cor->dpe     = Dih_cor->pote;
  }
  if (Nalpha->on  == 1||Nalpha->on == 3) {
    zero_stats(ds_nalpha);
    ds_nalpha->dpe     = Nalpha->pote;
  }
  if (Nbeta->on  == 1||Nbeta->on == 3) {
    zero_stats(ds_nbeta);
    ds_nbeta->dpe     = Nbeta->pote;
  }

  for(index_phi =1;index_phi<=num_phi;index_phi++){
     Phi_l = Phi+index_phi;
     if(Phi_l->on==1||Phi_l->on==1){
       zero_stats(ds_phi+index_phi);
       (ds_phi+index_phi)->dpe   = Phi_l->pote;
     }
  }
}
