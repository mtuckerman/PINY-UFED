
#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_math.h"


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void force_Rgyr (CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos, int ipt ) 
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/


  double dx, dy, dz, rgyrsq, rgyr;
  double sum_sq, sum_x, sum_y, sum_z;
 
  DAFED *Rgyr = &(clatoms_info->Rgyr[ipt]);
  DAFED_INFO *dinfo = clatoms_info->daf_info; 
  double *clatoms_x	= clatoms_pos[ipt].x;
  double *clatoms_y	= clatoms_pos[ipt].y;
  double *clatoms_z	= clatoms_pos[ipt].z; 
  int *i1    = Rgyr->i1;
  int *i2    = Rgyr->i2;
  int i1_num = Rgyr->i1_num;
  int i2_num = Rgyr->i2_num;
  double PRE;
  double x1,y1,z1;
  double s   = Rgyr->s;
  double ks  = Rgyr->ks; 
  double *Fx = Rgyr->Fx;
  double *Fy = Rgyr->Fy;
  double *Fz = Rgyr->Fz;

  int iii, jjj;
  double Nb_1 = 1.0/((double)i1_num);
  double pre2 = 2.0*Nb_1*Nb_1;

/*==========================================================================*/

  sum_sq =0; sum_x = 0; sum_y = 0; sum_z = 0;

  for (iii = 1; iii <= i1_num; iii++) {
     x1 = clatoms_x[i1[iii]];
     y1 = clatoms_y[i1[iii]];
     z1 = clatoms_z[i1[iii]];
     sum_sq += x1*x1;
     sum_sq += y1*y1;
     sum_sq += z1*z1;
  
     sum_x  += x1;
     sum_y  += y1;
     sum_z  += z1;
  }


  rgyrsq  = -(sum_x*sum_x + sum_y*sum_y + sum_z*sum_z)*Nb_1*Nb_1;
  rgyrsq += sum_sq*Nb_1; 
  rgyr    = sqrt(rgyrsq);
  if (s < 0) {Rgyr->s = rgyr - 0.0001;s = Rgyr->s;}
  Rgyr->ss = rgyr;
  
  Rgyr->pote = ks*(rgyr-s)*(rgyr-s)*0.5;
  Rgyr->Fs   = ks*(rgyr-s);
  Rgyr->f_data = Rgyr->Fs;
  Rgyr->f_ave += Rgyr->Fs;

  PRE = -0.5*ks*(rgyr- s)/(rgyr);

  for (iii = 1; iii <= i1_num; iii++) {
     
     for (jjj = 1; jjj <= i2_num; jjj++) {
        Fx[iii] -= clatoms_x[i2[jjj]];
        Fy[iii] -= clatoms_y[i2[jjj]];
        Fz[iii] -= clatoms_z[i2[jjj]];
     }
     Fx[iii] = (pre2*Fx[iii]+2.0*clatoms_x[i1[iii]]*Nb_1)*PRE;
     Fy[iii] = (pre2*Fy[iii]+2.0*clatoms_y[i1[iii]]*Nb_1)*PRE;;
     Fz[iii] = (pre2*Fz[iii]+2.0*clatoms_z[i1[iii]]*Nb_1)*PRE;;
  }
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/



/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double get_Rgyr_value(CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos, int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/


  double dx, dy, dz, rgyrsq, rgyr;
  double sum_sq, sum_x, sum_y, sum_z;

  DAFED *Rgyr = clatoms_info->Rgyr;
  DAFED_INFO *dinfo = clatoms_info->daf_info;
  double *clatoms_x     = clatoms_pos[ipt].x;
  double *clatoms_y     = clatoms_pos[ipt].y;
  double *clatoms_z     = clatoms_pos[ipt].z;

  int iii;
  double Nb = (double) Rgyr[ipt].i1_num;

/*==========================================================================*/

  sum_sq =0; sum_x = 0; sum_y = 0; sum_z = 0;

  for (iii = 1; iii <= Rgyr[ipt].i1_num; iii++) {
     sum_sq += pow(clatoms_x[Rgyr[ipt].i1[iii]],2);
     sum_sq += pow(clatoms_y[Rgyr[ipt].i1[iii]],2);
     sum_sq += pow(clatoms_z[Rgyr[ipt].i1[iii]],2);

     sum_x  += clatoms_x[Rgyr[ipt].i1[iii]];
     sum_y  += clatoms_y[Rgyr[ipt].i1[iii]];
     sum_z  += clatoms_z[Rgyr[ipt].i1[iii]];
  }

  rgyrsq  = -(pow(sum_x,2) + pow(sum_y,2) + pow(sum_z,2))/(pow(Nb,2));
  rgyrsq += sum_sq/Nb;
  rgyr    = sqrt(rgyrsq);

  return(rgyr - 0.0001);
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/













