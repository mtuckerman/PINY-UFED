
#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_math.h"


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void force_NH (CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos, int ipt )
{

  double dx, dy, dz, rij, rijsq, dr, top, bot_1, fac, nhsq, nh;
  double dr2, dr5, dr6, dr7, dr11, dr12, dr17,dr4;
  double fac_x, fac_y, fac_z; 
 
  DAFED *NH = &(clatoms_info->NH[ipt]);
  DAFED_INFO *dinfo = clatoms_info->daf_info; 
  double *clatoms_x	= clatoms_pos[ipt].x;
  double *clatoms_y	= clatoms_pos[ipt].y;
  double *clatoms_z	= clatoms_pos[ipt].z; 
  double *Fx            = NH->Fx;
  double *Fy            = NH->Fy;
  double *Fz            = NH->Fz;
  int *i1               = NH->i1;
  int *i2               = NH->i2;
  double ks             = NH->ks;
  double s              = NH->s;
  int i1_num            = NH->i1_num;
  int i2_num            = NH->i2_num;
  double PRE;
  double diff;

  int iii, jjj;

  //double d0 = 2.5/BOHR;
  double d0_1sq = BOHR*BOHR*0.16;
  int ind_i, ind_j;

  nh = 0.0;

  for (iii = 1; iii <= i1_num; iii++) {
    jjj = iii+i1_num;
    ind_i = i1[iii];
    ind_j = i2[iii];
    dx = clatoms_x[ind_i] - clatoms_x[ind_j];
    dy = clatoms_y[ind_i] - clatoms_y[ind_j];
    dz = clatoms_z[ind_i] - clatoms_z[ind_j];
    rijsq = dx*dx + dy*dy + dz*dz; 
    //rij   = sqrt(rijsq);
    //dr    = rij*d0_1;
    dr2   = rijsq*d0_1sq;
    dr4   = dr2*dr2;
    dr6   = dr4*dr2;
    //dr12  = dr6*dr6;

    //top = 1.0000 - dr6;
    bot_1 = 1.0/(1.0000+dr6); 
    nh += bot_1;
  //  if (iii == ch) printf("%d : rij = %.10g | dr = %.10g | nh = %.10g\n",iii,rij,dr,(top/bot));

    fac    = dr4*bot_1*bot_1;
    fac_x  = fac*dx;
    fac_y  = fac*dy;
    fac_z  = fac*dz; 

    Fx[iii] += fac_x;
    Fx[jjj] -= fac_x;
    Fy[iii] += fac_y;
    Fy[jjj] -= fac_y;
    Fz[iii] += fac_z;
    Fz[jjj] -= fac_z;
    //printf("F on x %d: %.10g\n",ind_i,fac_x);

  }

  if (s < 0) {NH->s = nh - 0.01;s = NH->s;}
  NH->ss = nh;
  
  diff = nh-s;
  NH->pote = ks*diff*diff*0.5;
  NH->Fs   = ks*diff;
  NH->f_data = NH->Fs;
  NH->f_ave += NH->Fs;

  //printf("FS_NH = %.10g \n",NH->Fs);

  PRE = 6.0*ks*diff*d0_1sq;

  for (iii = 1; iii <= 2*i1_num; iii++) {
     Fx[iii] *= PRE;
     Fy[iii] *= PRE;
     Fz[iii] *= PRE;
  } 
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double get_NH_value(CLATOMS_INFO *clatoms_info, CLATOMS_POS *clatoms_pos, int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/

  double dx, dy, dz, rij, rijsq, dr, top, bot, nh;
  double dr2, dr6, dr12,dr4;

  DAFED *NH = clatoms_info->NH;
  DAFED_INFO *dinfo = clatoms_info->daf_info;
  double *clatoms_x     = clatoms_pos[ipt].x;
  double *clatoms_y     = clatoms_pos[ipt].y;
  double *clatoms_z     = clatoms_pos[ipt].z;

  int iii;

  double d0 = 2.5/BOHR;
  int ind_i, ind_j;

  nh = 0.0;


/*==========================================================================*/
  
  for (iii = 1; iii <= NH[ipt].i1_num; iii++) {
    ind_i = NH[ipt].i1[iii];
    ind_j = NH[ipt].i2[iii];
    dx = clatoms_x[ind_i] - clatoms_x[ind_j];
    dy = clatoms_y[ind_i] - clatoms_y[ind_j];
    dz = clatoms_z[ind_i] - clatoms_z[ind_j];
    rijsq = pow(dx,2) + pow(dy,2) + pow(dz,2);
    rij   = sqrt(rijsq);
    dr    = rij/d0;
    dr2   = rijsq/(pow(d0,2));
    dr4   = dr2*dr2;
    dr6   = pow(dr2,3);
    dr12  = pow(dr6,2);

    top = 1.0000 - dr6;
    bot = 1.0000 - dr12;
    nh += (top/bot);
  }/*endfor*/

  return(nh - 0.01);

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/








