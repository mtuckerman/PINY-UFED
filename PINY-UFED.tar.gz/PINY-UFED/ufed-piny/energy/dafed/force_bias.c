#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_math.h"

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void force_bias(CLATOMS_INFO *clatoms_info, STAT_AVG *stat_avg, int ipt)
 
/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  DAFED_INFO *dinfo             = &(clatoms_info->daf_info[ipt]);
  BIAS_PACK *bias;
  CO *coeff;
  DAFED *Ree                    = &(clatoms_info->Ree[ipt]);
  DAFED *Rgyr                   = &(clatoms_info->Rgyr[ipt]);
  DAFED *NH                     = &(clatoms_info->NH[ipt]);
  DAFED *Phi                    = clatoms_info->Phi[ipt];
  DAFED *Dih                    = &(clatoms_info->Dih_cor[ipt]);
  DAFED *Na                     = &(clatoms_info->Nalpha[ipt]);
  DAFED *Nb                     = &(clatoms_info->Nbeta[ipt]);

  double **bias_pot_value,**bias_pot_dev,*L_value,*L_dev,*T_value,*T_dev;
  double *min,*max;
  double a,b,pot,force,prod;
  double dist12;
  double sigma;
  int i_bias                    = stat_avg->i_bias;
  int n_cv                      = stat_avg->n_cv;
  int num_phi                   = clatoms_info->num_phi;
  int nfun_gau                  = dinfo->nfun_gau;
  int fun_type                  = dinfo->fun_type;
  int bias_type                 = dinfo->bias_type;
  int i,j,k,l,n_coeff,order,iflag;
  int *cv_type;
  int *n_fun;  
  double *exp_value,*s_v;
  double delta = 0.001;//using for debug
  double s_p,s_m;//using for debug
  double scale = 3.14159265358979323846/180.0;
  double time = (double)(dinfo->time);
  //double time = 1.0;//for debug

  stat_avg->bias_pot = 0.0;
  //printf("bias_pot %lg\n",stat_avg->bias_pot);
  bias = &(clatoms_info->bias[ipt]);
  n_coeff = bias->n_coeff;
  cv_type = bias->cv_type;
  min = bias->min;
  max = bias->max;
  n_fun = bias->n_fun;
  iflag = 0;
  coeff = bias->coeff_list;
  s_v = (double*)cmalloc(n_cv*sizeof(double))-1;
  if(bias_type==1){fun_type = 1;}
  if(fun_type==1){
     bias_pot_value = (double **)cmalloc(n_coeff*sizeof(double*))-1;
     bias_pot_dev   = (double **)cmalloc(n_coeff*sizeof(double*))-1;
     for(j=1;j<=n_coeff;j++){
        bias_pot_value[j] = (double *)cmalloc(n_cv*sizeof(double))-1;
        bias_pot_dev[j]   = (double *)cmalloc(n_cv*sizeof(double))-1;
     }
  /*-----------------------------------------------------------------------*/
  /* Calculate function value and derivative */
     for(j=1;j<=n_cv;j++){
        if(cv_type[j]!=4){
          switch(cv_type[j]){
           case 1:s_v[j] = Ree->s;break;
           case 2:s_v[j] = Rgyr->s;break;
           case 3:s_v[j] = NH->s;break;
           case 5:s_v[j] = Dih->s;break;
           case 6:s_v[j] = Na->s;break;
           case 7:s_v[j] = Nb->s;break;
          }
          a = min[j];
          b = max[j];
	  //s = 0.5*(b+a);
	  //printf("cv %i,s %lg\n",j,s);
          //printf("n_fun %i\n",n_fun[j]);
          L_value = (double *)cmalloc(n_fun[j]*sizeof(double))-1;
          L_dev   = (double *)cmalloc(n_fun[j]*sizeof(double))-1;
          L_fun(L_value,L_dev,n_fun[j],a,b,s_v[j]);
          for(k=1;k<=n_coeff;k++){
            order = coeff[k].order[j].n;                   
            //bias_pot_value[k][j] = L_value[order+1]*sw_fun(s,a,b);//pay attention to a<=s<=b
            //bias_pot_dev[k][j]   = L_dev[order+1]*sw_fun(s,a,b)+L_value[order+1]*sw_fun_dev(s,a,b);
	    //printf("order %i, i_cv %i, value %lg, dev %lg\n",order,j,bias_pot_value[k][j],bias_pot_dev[k][j]);
            bias_pot_value[k][j] = L_value[order+1];
	    bias_pot_dev[k][j]   = L_dev[order+1];
          }
          free(&(L_value[1]));
          free(&(L_dev[1]));
        }/*endif cv_type[i]!=4*/
        else{
          iflag += 1;
          s_v[j] = Phi[iflag].s;
          T_value = (double *)cmalloc(n_fun[j]*sizeof(double))-1;
          T_dev   = (double *)cmalloc(n_fun[j]*sizeof(double))-1;
          T_fun(T_value,T_dev,n_fun[j],s_v[j]);
          for(k=1;k<=n_coeff;k++){
             order = coeff[k].order[j].n;
             bias_pot_value[k][j] = T_value[order+1];
             bias_pot_dev[k][j]   = T_dev[order+1];
          }
          free(&(T_value[1]));
          free(&(T_dev[1]));
        }/*end else*/
     }/*endfor n_cv*/ 

  /*-----------------------------------------------------------------------*/
  /* Calculate bias potential */
  
     for(j=1;j<=n_coeff;j++){
        prod = 1.0;
        for(k=1;k<=n_cv;k++){
           prod *= bias_pot_value[j][k];
        }
        stat_avg->bias_pot += coeff[j].c*prod;
    }
    //printf("i %i,i_bias %i\n",i,i_bias);
    //printf("potential %lg\n",stat_avg->bias_pot);
  /*-----------------------------------------------------------------------*/
  /* Calculate bias force */

     iflag = 0;
     for(j=1;j<=n_cv;j++){
        force = 0.0;
        if(s_v[j]>=min[j]&&s_v[j]<=max[j]){
          for(k=1;k<=n_coeff;k++){
             prod = 1.0;
             for(l=1;l<=n_cv;l++){
                if(l!=j){prod *= bias_pot_value[k][l];}
                else{prod *= bias_pot_dev[k][l];}
             }/*endfor n_cv*/
             force += coeff[k].c*prod;
          }/*endfor n_coeff*/
        }//endif s[j]
        //printf("s %lg,pot %lg,force %lg\n",s,stat_avg->bias_pot,force);
        if(cv_type[j]==1){Ree->Fs -= force*time;}
        if(cv_type[j]==2){Rgyr->Fs -= force*time;}
        if(cv_type[j]==3){NH->Fs -= force*time;}
	if(cv_type[j]==5){Dih->Fs -= force*time;}
	if(cv_type[j]==6){Na->Fs -= force*time;}
        if(cv_type[j]==7){Nb->Fs -= force*time;}
        if(cv_type[j]==4){
          iflag += 1;
	  //printf("ind %i, Fs %lg, bias %lg, ",iflag,Phi[iflag].Fs,force);
          Phi[iflag].Fs -= force*time;
          //printf("Fs_after %lg\n",Phi[iflag].Fs);
        }
	//printf("ind %i,force %lg\n",j,force);
     }/*endfor n_cv*/

  /*-----------------------------------------------------------------------*/
  /* Test bias force Numerically*/

  /*-----------------------------------------------------------------------*/
  /* Free local variables */
    for(j=1;j<=n_coeff;j++){
       free(&(bias_pot_value[j][1]));
       free(&(bias_pot_dev[j][1]));
    }
    free(&(bias_pot_value[1]));
    free(&(bias_pot_dev[1]));
    //exit(0);
/*-------------------------------------------------------------------------*/
  }//fun_type==1
  if(fun_type==2){
    sigma = bias->sigma;
    exp_value = (double*)cmalloc(nfun_gau*sizeof(double))-1;
    for(i=1;i<=n_cv;i++){       
       switch(cv_type[i]){
         case 1:s_v[i] = Ree->s;break;
         case 2:s_v[i] = Rgyr->s;break;
         case 3:s_v[i] = NH->s;break;
         case 5:s_v[i] = Dih->s;break;
         case 6:s_v[i] = Na->s;break;
         case 7:s_v[i] = Nb->s;break;
       }
    }
    for(i=1;i<=nfun_gau;i++){
       dist12 = dist(coeff[i].center,s_v,n_cv);
       exp_value[i] = coeff[i].c*exp(-sigma*dist12);
       stat_avg->bias_pot += exp_value[i];
    }
    for(i=1;i<=n_cv;i++){
       force = 0.0;
       for(j=1;j<=nfun_gau;j++){
	  force += -2.0*sigma*(s_v[i]-coeff[j].center[i])*exp_value[j];
       }
       switch(cv_type[i]){
        case 1:Ree->Fs -= force*time;break;
        case 2:Rgyr->Fs -= force*time;break;
        case 3:NH->Fs -= force*time;break;
        case 5:Dih->Fs -= force*time;break;
        case 6:Na->Fs -= force*time;break;
        case 7:Nb->Fs -= force*time;break;
       }
    }
    free(&(exp_value[1]));
  }//endif fun_type==2 	
  free(&(s_v[1]));

/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void L_fun(double *L_value, double *L_dev, int len,double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double x,order;
  int i;
  double b_a_1 = 1.0/(b-a);

  /*-----------------------------------------------------------------------*/
  /* Rescale s */
  
  if(s>=a&&s<=b){x = 2.0*s*b_a_1-(b+a)*b_a_1;}
  if(s<a){x = -1.0;}
  if(s>b){x = 1.0;}
  
  /*-----------------------------------------------------------------------*/
  /* Calculate Legendre polynomial */
  
  if(len==1){
    L_value[1] = 1.0;
    L_dev[1] = 0.0;
  }
  else{
    L_value[1] = 1.0;
    L_value[2] = x;
    L_dev[1] = 0.0;
    L_dev[2] = 1.0;
  }
  for(i=3;i<=len;i++){
    order = (double)(i-2);
    L_value[i] = ((2.0*order+1.0)*x*L_value[i-1]-order*L_value[i-2])/(order+1.0);
    if(a<=s&&s<=b){
      L_dev[i] = ((2.0*order+1.0)*(L_value[i-1]+x*L_dev[i-1])-order*L_dev[i-2])/(order+1.0);
    }
    else{
      L_dev[i] = 0.0;
    }
  }
  for(i=1;i<=len;i++){
    L_dev[i] *= 2.0*b_a_1;
  }
    

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void T_fun(double *T_value, double *T_dev, int len,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  int i,order;
 
  for(i=1;i<=len;i++){
     if(i%2==1){
       order = (int)((i-1)/2);
       if(i==1){
         T_value[i] = 1.0;
         T_dev[i] = 0.0;
       }
       else{
         T_value[i] = cos(order*s);
         T_dev[i] = -order*sin(order*s);
       }
     }
     else{
       order = (int)(i/2);
       T_value[i] = sin(order*s);
       T_dev[i] = order*cos(order*s);
     }
  }  

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

double sw_fun(double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double delta = 0.01*(b-a);
  double d_0   = 0.1;
  double x,doub,result;


  if(s<=a-delta){result = 1.0;}
  if(s>=a+delta&&s<=b-delta){result = 1.0;}
  if(s>=b+delta){result = 1.0;}
  if(s>a-delta&&s<a+delta){
    doub = ((s-a)*(s-a)-delta*delta);
    result = -d_0*doub*doub+1.0;
  }
  if(s>b-delta&&s<b+delta){
    doub = ((s-b)*(s-b)-delta*delta);
    result = -d_0*doub*doub+1.0;
  }
  return result;
  
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

double sw_fun_dev(double a,double b,double s)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

  double delta = 0.01*(b-a);
  double d_0 = 0.1;
  double x,doub,result;

  if(s<=a-delta){result = 0.0;}
  if(s>=a+delta&&s<=b-delta){result = 0.0;}
  if(s>=b+delta){result = 0.0;}
  if(s>a-delta&&s<a+delta){
    result = -4.0*d_0*((s-a)*(s-a)-delta*delta)*(s-a);
  }
  if(s>b-delta&&s<b+delta){
    result = -4.0*d_0*((s-b)*(s-b)-delta*delta)*(s-b);
  }
  return result;
 
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void force_bias_num(CLATOMS_INFO *clatoms_info, STAT_AVG *stat_avg, int ipt)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  DAFED_INFO *dinfo             = &(clatoms_info->daf_info[ipt]);
  BIAS_PACK *bias               = &(clatoms_info->bias[ipt]);
  DAFED *Ree                    = &(clatoms_info->Ree[ipt]);
  DAFED *Rgyr                   = &(clatoms_info->Rgyr[ipt]);
  DAFED *NH                     = &(clatoms_info->NH[ipt]);
  DAFED *Phi                    = clatoms_info->Phi[ipt];
  DAFED *Dih                    = &(clatoms_info->Dih_cor[ipt]);
  DAFED *Na                     = &(clatoms_info->Nalpha[ipt]);
  DAFED *Nb                     = &(clatoms_info->Nbeta[ipt]);
  BIAS_HIST *bhist              = bias->bhist;

  double dist12;
  double sigma;
  int n_cv                      = stat_avg->n_cv;
  int num_phi                   = clatoms_info->num_phi;
  int nfun_gau                  = dinfo->nfun_gau;
  int fun_type                  = dinfo->fun_type;
  int bias_type                 = dinfo->bias_type;
  int *n_bin_cv_hist            = bias->n_bin_cv_hist;
  int i,j,k,l,n_coeff,order,iflag;
  int *cv_type                  = bias->cv_type;
  int *n_fun;
  int ind_freq;
  double *exp_value,*s_v,*force,*x_list;
  double *min                   = bias->min;
  double *max                   = bias->max;
  double *w_bin_hist            = bias->w_bin_hist;
  double a,x,y;
  double x1,x2,y1,y2,x1_cp,x2_cp,y1_cp,y2_cp;
  double s1,s2,s3,s4;
  double frac,c1,c2,c3,c4;
  double delta = M_PI/20.0;//using for debug
  double f_num_1,f_num_2;//using for debug
  double scale = 3.14159265358979323846/180.0;
  double time = (double)(dinfo->time);

  s_v = (double*)cmalloc(n_cv*sizeof(double))-1;
  force = (double*)cmalloc(n_cv*sizeof(double))-1;
  x_list = (double*)cmalloc(n_cv*sizeof(double))-1;
  stat_avg->bias_pot = 0.0;
  iflag = 1;  

  for(i=1;i<=n_cv;i++){
     switch(cv_type[i]){
       case 1:s_v[i] = Ree->s;break;
       case 2:s_v[i] = Rgyr->s;break;
       case 3:s_v[i] = NH->s;break;
       case 4:s_v[i] = Phi[iflag].s;iflag ++;break;
       case 5:s_v[i] = Dih->s;break;
       case 6:s_v[i] = Na->s;break;
       case 7:s_v[i] = Nb->s;break;
     }
  }
  
  iflag = 0;  
  
  if(n_cv==2){
    x = s_v[1];
    y = s_v[2];
    force[1] = 0.0;
    force[2] = 0.0;
    x1 = min[1]+((int)((x-min[1]+0.00001)/w_bin_hist[1]-0.5)+0.5)*w_bin_hist[1];
    x2 = min[1]+((int)((x-min[1]+0.00001)/w_bin_hist[1]-0.5)+1.5)*w_bin_hist[1];
    y1 = min[2]+((int)((y-min[2]+0.00001)/w_bin_hist[2]-0.5)+0.5)*w_bin_hist[2];
    y2 = min[2]+((int)((y-min[2]+0.00001)/w_bin_hist[2]-0.5)+1.5)*w_bin_hist[2];
    if(cv_type[1]!=4){
      if(x1<min[1]||x2>max[1]||y1<min[2]||y2>max[2]){force[1] = 0.0;force[2] = 0.0;}
      else{
        x_list[1] = x2;
        x_list[2] = y2;
        s1 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
        x_list[1] = x1;
        x_list[2] = y2;
        s2 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
        x_list[1] = x2;
        x_list[2] = y1;
        s3 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
        x_list[1] = x1;
        x_list[2] = y1;
        s4 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
        frac = 1.0/(x2-x1)/(y2-y1);
        c1 = s1*frac;
        c2 = s2*frac;
        c3 = s3*frac;
        c4 = s4*frac;
        stat_avg->bias_pot = c4*(x2-x)*(y2-y)+c3*(x-x1)*(y2-y)+c2*(x2-x)*(y-y1)+c1*(x-x1)*(y-y1);
        force[1] = (c3-c4)*(y2-y)+(c1-c2)*(y-y1);
        force[2] = (c2-c4)*(x2-x)+(c1-c3)*(x-x1);
      }
    }
    if(cv_type[1]==4){
      x1_cp = x1;
      x2_cp = x2;
      y1_cp = y1;
      y2_cp = y2;
      if(x1_cp<-M_PI){x1_cp += 2.0*M_PI;}
      if(x2_cp>M_PI){x2_cp -= 2.0*M_PI;}
      if(y1_cp<-M_PI){y1_cp += 2.0*M_PI;} 
      if(y2_cp>M_PI){y2_cp -= 2.0*M_PI;}
      x_list[1] = x2_cp;
      x_list[2] = y2_cp;
      s1 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
      x_list[1] = x1_cp;
      x_list[2] = y2_cp;
      s2 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
      x_list[1] = x2_cp;
      x_list[2] = y1_cp;
      s3 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
      x_list[1] = x1_cp;
      x_list[2] = y1_cp;
      s4 = find_gv(x_list,bhist,2,n_bin_cv_hist,min,w_bin_hist);
      frac = 1.0/(x2-x1)/(y2-y1);
      c1 = s1*frac;
      c2 = s2*frac;
      c3 = s3*frac;
      c4 = s4*frac;
      stat_avg->bias_pot = c4*(x2-x)*(y2-y)+c3*(x-x1)*(y2-y)+c2*(x2-x)*(y-y1)+c1*(x-x1)*(y-y1);
      force[1] = (c3-c4)*(y2-y)+(c1-c2)*(y-y1);
      f_num_1 = (s2-s4)/delta;
      f_num_2 = (s1-s3)/delta;
      force[2] = (c2-c4)*(x2-x)+(c1-c3)*(x-x1);
      //printf("f_interp %lg f1 %lg f2 %lg\n",force[2],f_num_1,f_num_2);
    }
  }
  iflag = 1;
  for(i=1;i<=n_cv;i++){
     switch(cv_type[i]){
       case 1:Ree->Fs -= force[i]*time;break;
       case 2:Rgyr->Fs -= force[i]*time;break;
       case 3:NH->Fs -= force[i]*time;break;
       case 4:Phi[iflag].Fs -= force[i]*time;iflag ++;break;
       case 5:Dih->Fs -= force[i]*time;break;
       case 6:Na->Fs -= force[i]*time;break;
       case 7:Nb->Fs -= force[i]*time;break;
     }
  }     
  //for(i=1;i<=n_cv;i++)printf("f %i %lg\n",i,force[i]*time);
  free(&(s_v[1]));
  free(&(force[1]));
  free(&(x_list[1]));
       
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void force_bias_num_hd(CLATOMS_INFO *clatoms_info, STAT_AVG *stat_avg, int ipt)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  DAFED_INFO *dinfo             = &(clatoms_info->daf_info[ipt]);
  BIAS_PACK *bias               = &(clatoms_info->bias[ipt]);
  DAFED *Ree                    = &(clatoms_info->Ree[ipt]);
  DAFED *Rgyr                   = &(clatoms_info->Rgyr[ipt]);
  DAFED *NH                     = &(clatoms_info->NH[ipt]);
  DAFED *Phi                    = clatoms_info->Phi[ipt];
  DAFED *Dih                    = &(clatoms_info->Dih_cor[ipt]);
  DAFED *Na                     = &(clatoms_info->Nalpha[ipt]);
  DAFED *Nb                     = &(clatoms_info->Nbeta[ipt]);
  BIAS_HIST *bhist              = bias->bhist;
  C_NBLT *nblt_array            = bias->nblt_array;

  double dist12;
  double sigma;
  int n_cv                      = stat_avg->n_cv;
  int num_phi                   = clatoms_info->num_phi;
  int nfun_gau                  = dinfo->nfun_gau;
  int fun_type                  = dinfo->fun_type;
  int bias_type                 = dinfo->bias_type;
  int *n_bin_cv_hist            = bias->n_bin_cv_hist;
  int *bin_num                  = bias->bin_num;
  int i,j,k,l,n_coeff,order,iflag;
  int *cv_type                  = bias->cv_type;
  int *type;
  int *n_fun;
  int ind_freq;
  double *exp_value,*s_v,*force,*x_list;
  double *min                   = bias->min;
  double *max                   = bias->max;
  double *w_bin_hist            = bias->w_bin_hist;
  double min_cv,max_cv,w_bin_cv;
  double time = (double)(dinfo->time);  

  /*--------*/
  int nblt_tot = bias->nblt_tot;
  int index;

  double **coord;
  double *lat_point;
  double pot_interp;
  double *w_bin;
  double *sign; 
  double *pot_lat;
  double *x_temp;

  s_v = (double*)cmalloc(n_cv*sizeof(double));
  coord = (double**)cmalloc(nblt_tot*sizeof(double*));
  for(i=0;i<nblt_tot;i++)coord[i] = (double*)cmalloc(n_cv*sizeof(double));
  //index = (int*)cmalloc(n_cv*sizeof(int));
  force     = (double*)cmalloc(n_cv*sizeof(double));
  w_bin     = (double*)cmalloc(n_cv*sizeof(double));
  sign      = (double*)cmalloc(nblt_tot*sizeof(double));
  pot_lat   = (double*)cmalloc(nblt_tot*sizeof(double));
  lat_point = (double*)cmalloc(n_cv*sizeof(double));
  x_temp    = (double*)cmalloc(n_cv*sizeof(double))-1;
  type      = (int*)cmalloc(n_cv*sizeof(int));

  iflag = 1;
  for(i=0;i<n_cv;i++){
     switch(cv_type[i+1]){
       case 1:s_v[i] = Ree->s;break;
       case 2:s_v[i] = Rgyr->s;break;
       case 3:s_v[i] = NH->s;break;
       case 4:s_v[i] = Phi[iflag].s;iflag ++;break;
       case 5:s_v[i] = Dih->s;break;
       case 6:s_v[i] = Na->s;break;
       case 7:s_v[i] = Nb->s;break;	     
     }
     w_bin[i] = w_bin_hist[i+1];
     type[i]  = cv_type[i+1];
  }
  for(i=0;i<n_cv;i++){
     index = (int)((s_v[i]-min[i+1])/w_bin[i]);
     lat_point[i] = min[i+1]+(index+0.5)*w_bin[i];
     if(s_v[i]<lat_point[i]){
       lat_point[i] -= w_bin[i];
       if(cv_type[i+1]==4&&lat_point[i]<=-M_PI)lat_point[i] += 2.0*M_PI;
     }
  }     

  for(i=0;i<nblt_tot;i++){
     for(j=0;j<n_cv;j++){
        if(nblt_array[i].diff[j]==0)coord[i][j] = lat_point[j];
        else{
	  coord[i][j] = lat_point[j]+w_bin[j];
          if(cv_type[j+1]==4&&coord[i][j]>M_PI)coord[i][j] -= 2.0*M_PI;
        }
	x_temp[j+1] = coord[i][j];
     }
     pot_lat[i] = find_gv(x_temp,bhist,n_cv,n_bin_cv_hist,min,w_bin_hist);
     sign[i] = nblt_array[i].sign;
  }
  linear_interp_hd(n_cv,nblt_tot,coord,pot_lat,force,&pot_interp,s_v,w_bin,sign,type);
  stat_avg->bias_pot = pot_interp;
  iflag = 1;
  for(i=0;i<n_cv;i++){
     switch(cv_type[i+1]){
       case 1:Ree->Fs += force[i]*time;break;
       case 2:Rgyr->Fs += force[i]*time;break;
       case 3:NH->Fs += force[i]*time;break;
       case 4:Phi[iflag].Fs += force[i]*time;iflag ++;break;
       case 5:Dih->Fs += force[i]*time;break;
       case 6:Na->Fs += force[i]*time;break;
       case 7:Nb->Fs += force[i]*time;break;
     }
  }
  //for(i=0;i<n_cv;i++)printf("f %i %lg\n",i,force[i]*time);     	  
  free(s_v);
  free(force);
  free(w_bin);
  free(sign);
  free(pot_lat);
  free(lat_point);
  free(&(x_temp[1]));
  free(type);
  for(i=0;i<nblt_tot;i++)free(coord[i]);
  free(coord);

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

double find_gv(double *x,BIAS_HIST *bhist,int n_cv,int *n_bin_cv_hist,double *min,double *w_bin_hist)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
  int j,i;
  int n_total_hist = n_bin_cv_hist[1];
  int ind_freq = 1;
  double gv,a;

  for(j=1;j<=n_cv;j++){
    //printf("j %i w_bin %lg n_bin %i\n",j,w_bin_hist[j],n_bin_cv_hist[j+1]);
    a = min[j];
    ind_freq += (int)((x[j]-a)/w_bin_hist[j])*n_bin_cv_hist[j+1];
  }
  //printf("ind_freq %i\n",ind_freq);
  if(ind_freq<=n_total_hist&&ind_freq>=1){
    gv = bhist[ind_freq].gaussian_v;
  }
  else{
    printf("x is out of range, check the code\n");
    for(i=1;i<=n_cv;i++){
       printf("x %lg\n",x[i]);
    }
    exit(0);
  }
  return gv;
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void linear_interp_hd(int n_cv,int nblt_tot,
		      double **coord,double *pot,double *force,
		      double *pot_int,double *s,double *w_bin_hist,
		      double *sign,int *type)
/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */	
  int i,j,k;
  int ic;
  double *x_c;
  double pre = 1.0;
  double prod;
  double pot_v;
  double lat_m,lat_p;
  double pot_int_local = 0.0;

  /*for debug*/
  /*printf("--------\n");
  for(i=0;i<n_cv;i++)printf("%lg ",s[i]);
  printf("\n");
  for(i=0;i<nblt_tot;i++){
     for(j=0;j<n_cv;j++)printf("%lg ",coord[i][j]);
     printf("%lg ",pot[i]);
     printf("\n");
  }*/


  for(i=0;i<n_cv;i++){
     pre *= w_bin_hist[i];
     force[i] = 0.0;
  }     
  for(i=0;i<nblt_tot;i++){
     ic = nblt_tot-1-i;
     x_c = coord[ic];     
     prod = sign[i];
     for(j=0;j<n_cv;j++){
	if(type[j]==4)prod *= diff_perodic(x_c[j],s[j]);
        else prod *= x_c[j]-s[j];
     }
     pot_int_local += pot[i]*prod;
     for(j=0;j<n_cv;j++){
	prod = sign[i];     
        for(k=0;k<n_cv;k++){
	  if(k!=j){	  
     	    if(type[k]==4)prod *= diff_perodic(x_c[k],s[k]);
	    else prod *= x_c[k]-s[k];
	  }
	}  
	force[j] += pot[i]*prod;
     }
  }
  pot_int_local /= pre;
  *pot_int = pot_int_local;
  for(i=0;i<n_cv;i++){
     force[i] /= pre;
  }  

/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double diff_perodic(double x,double y)
/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
  double diff = x-y;  
  if(diff>=M_PI)diff -= 2.0*M_PI;
  if(diff<-M_PI)diff += 2.0*M_PI;
  return diff;
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/  
















 






