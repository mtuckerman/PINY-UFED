
void surf_pot(CLATOMS_INFO *, CLATOMS_POS *, ATOMMAPS *,SURFACE *, CELL *,
              INTRA_SCR *, PTENS *, double *, int , CLASS_COMM_FORC_PKG *,
              int ,int);

void surf_vspl_fetch(int n,double del[], double [], int [],double []);
