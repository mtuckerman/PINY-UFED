/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                   Module: energy_control.c                               */
/*                                                                          */
/* This routine calls the required force and PE routines                    */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_energy_ctrl_entry.h"
#include "../proto_defs/proto_intra_entry.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_real_space_entry.h"
#include "../proto_defs/proto_recip3d_entry.h"
#include "../proto_defs/proto_energy_ctrl_local.h"
#include "../proto_defs/proto_intra_con_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_helper.h"


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void energy_control_dafed(CLASS *class, BONDED *bonded, 
                    GENERAL_DATA *general_data, int ipt)

/*========================================================================*/
  { /* Begin Routine */
/*========================================================================*/

  CLATOMS_INFO *clatoms_info = &(class->clatoms_info);
  CLATOMS_POS  *clatoms_pos  = class->clatoms_pos;
  int    iii,i;
  double pvten_temp[10];
  int    np_forc     = class->communicate.np_forc;
  int    myid        = class->communicate.myid;
  int    np          = class->communicate.np;
  int    num_phi     = clatoms_info->num_phi;
  int    natm_tot    = clatoms_info->natm_tot;
  int    div,res;
  int    iflag;
  int    phi_start,phi_end,phi_num_proc;
  int    n_atm_f;
  MPI_Comm comm_forc = class->communicate.comm_forc;
  MPI_Comm world     = class->communicate.world;

  DAFED *Ree = &(clatoms_info->Ree[ipt]);
  DAFED *Rgyr= &(clatoms_info->Rgyr[ipt]);
  DAFED *NH  = &(clatoms_info->NH[ipt]);
  DAFED *Dih_cor = &(clatoms_info->Dih_cor[ipt]);
  DAFED *Nalpha  = &(clatoms_info->Nalpha[ipt]);
  DAFED *Nbeta   = &(clatoms_info->Nbeta[ipt]);
  DAFED *Phi= clatoms_info->Phi[ipt];
  DAFED *Phi_l;
  DAFED_INFO *dinfo = clatoms_info->daf_info;
  
//  printf("to_file_curr %d\n",dinfo[ipt].to_file_curr);
//  printf("curr %d\n",dinfo[ipt].curr);
//  printf("i_respa %d,n_respa %d\n",dinfo[ipt].i_respa,dinfo[ipt].n_respa);
   if (dinfo[ipt].i_respa == dinfo[ipt].n_respa) {
      dinfo[ipt].curr += 1;
      if (dinfo[ipt].curr == dinfo[ipt].freq) {
        dinfo[ipt].to_file_curr += 1;
        dinfo[ipt].curr = 0;
      }
   }
   dinfo[ipt].timestep += 1;
//  if(np==1){
    if (Ree->on == 1 || Ree->on == 3) {
      zero_forces(Ree,Ree->n_atm_f); 
      force_Ree(clatoms_info, clatoms_pos, ipt);
    }
    if (Rgyr->on== 1 || Rgyr->on == 3) {
      zero_forces(Rgyr,Rgyr->n_atm_f);
      force_Rgyr(clatoms_info, clatoms_pos, ipt);
    }
    if (NH->on == 1 || NH->on == 3) {
      zero_forces(NH,NH->n_atm_f);
      force_NH(clatoms_info, clatoms_pos, ipt);
    }
    iflag = 0;
    if(Dih_cor->on==1||Dih_cor->on==3){
       zero_forces(Dih_cor,Dih_cor->n_atm_f);
       iflag += 1;
    }
    if(Nalpha->on==1||Nalpha->on==3){
       zero_forces(Nalpha,Nalpha->n_atm_f);
       iflag += 1;
    }
    if(Nbeta->on==1||Nbeta->on==3){
       zero_forces(Nbeta,Nbeta->n_atm_f);
       iflag += 1;
    }
    if(iflag>0){
       force_BBDih(clatoms_info,clatoms_pos,ipt);
    }
    for(i=1;i<=num_phi;i++){
       zero_forces(Phi+i,(Phi+i)->n_atm_f);
    }
    force_Phi(clatoms_info,clatoms_pos, ipt);
/*  }
  else{
    Barrier(class->communicate.world);
    if (Ree[ipt].on == 1 || Ree[ipt].on == 3) {
      zero_forces(&(Ree[ipt]),class->clatoms_info.natm_tot);
      if(myid==0){
	force_Ree(&(class->clatoms_info), class->clatoms_pos, ipt);
      }
      Barrier(world);
      Bcast(&(Ree[ipt].Fx[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
      Bcast(&(Ree[ipt].Fy[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
      Bcast(&(Ree[ipt].Fz[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
    }
    if (Rgyr[ipt].on== 1 || Rgyr[ipt].on == 3) {
      zero_forces(&(Rgyr[ipt]),class->clatoms_info.natm_tot);
      if(myid==0){
        force_Rgyr(&(class->clatoms_info), class->clatoms_pos, ipt);
      }
      Barrier(world);
      Bcast(&(Rgyr[ipt].Fx[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
      Bcast(&(Rgyr[ipt].Fy[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
      Bcast(&(Rgyr[ipt].Fz[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
    }

    if (NH[ipt].on == 1 || NH[ipt].on == 3) {
      zero_forces(&(NH[ipt]),class->clatoms_info.natm_tot);
      if(myid==0){
        force_NH(&(class->clatoms_info), class->clatoms_pos, ipt);
      }
      Barrier(world);
      Bcast(&(NH[ipt].Fx[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
      Bcast(&(NH[ipt].Fy[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
      Bcast(&(NH[ipt].Fz[1]),natm_tot,MPI_DOUBLE,0,world);
      Barrier(world);
    }
    for(i=1;i<=num_phi;i++){
      zero_forces(&(Phi[ipt][i]),class->clatoms_info.natm_tot);
    }
    div = (int)(num_phi/np);
    res = num_phi%np;
    if(myid<=res-1){
      phi_num_proc = div+1;
      phi_start = myid*phi_num_proc;
    }
    else{
      phi_num_proc = div;
      phi_start = (myid-res)*phi_num_proc+res*(div+1);
    }
    phi_end   = phi_start+phi_num_proc-1;
    force_Phi(&(class->clatoms_info),class->clatoms_pos, ipt,phi_start,phi_end);
    Barrier(world);
    for(i=phi_start;i<=phi_end;i++){
      Barrier(world);
      Bcast(&(Phi[ipt][i].Fx[1]),natm_tot,MPI_DOUBLE,my_id,world);
      Barrier(world);
      Bcast(&(Phi[ipt][i].Fy[1]),natm_tot,MPI_DOUBLE,my_id,world);
      Barrier(world);
      Bcast(&(Phi[ipt][i].Fz[1]),natm_tot,MPI_DOUBLE,my_id,world);
      Barrier(world);
    }*/
    force_dafed_final(clatoms_info, clatoms_pos, &(general_data->stat_avg[ipt]), ipt);
}





