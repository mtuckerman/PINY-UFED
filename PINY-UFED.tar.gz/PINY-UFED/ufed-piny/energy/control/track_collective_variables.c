/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                   Module: energy_control.c                               */
/*                                                                          */
/* This routine calls the required force and PE routines                    */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_energy_ctrl_entry.h"
#include "../proto_defs/proto_intra_entry.h"
#include "../proto_defs/proto_dafed_energy.h"
#include "../proto_defs/proto_real_space_entry.h"
#include "../proto_defs/proto_recip3d_entry.h"
#include "../proto_defs/proto_energy_ctrl_local.h"
#include "../proto_defs/proto_intra_con_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_dafed_helper.h"
#include "../proto_defs/proto_dafed_io.h"

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void track_collective_variables(CLASS *class, BONDED *bonded, 
                    GENERAL_DATA *general_data, int ipt)

/*========================================================================*/
  { /* Begin Routine */
/*========================================================================*/

  int    iii,i;
  double pvten_temp[10];
  int    np_forc     = class->communicate.np_forc;
  int    myid        = class->communicate.myid;
  MPI_Comm comm_forc = class->communicate.comm_forc;
  int npara_temps_proc_off = general_data->tempering_ctrl.npara_temps_proc_off;

  DAFED *Ree = class->clatoms_info.Ree;
  DAFED *Rgyr= class->clatoms_info.Rgyr;
  DAFED *NH  = class->clatoms_info.NH;
  DAFED_INFO *dinfo = class->clatoms_info.daf_info;

    if (dinfo[ipt].i_respa == dinfo[ipt].n_respa) {
       dinfo[ipt].curr += 1;
       if (dinfo[ipt].curr == dinfo[ipt].freq) {
         dinfo[ipt].to_file_curr += 1;
         dinfo[ipt].curr = 0;
       }
    }
    dinfo[ipt].timestep += 1;

    if (Ree[ipt].on == 2) {
      zero_forces(&(Ree[ipt]),class->clatoms_info.natm_tot); 
      force_Ree(&(class->clatoms_info), class->clatoms_pos, ipt);
      zero_forces(&(Ree[ipt]),class->clatoms_info.natm_tot); 
    }
    if (Rgyr[ipt].on== 2) {
      zero_forces(&(Rgyr[ipt]),class->clatoms_info.natm_tot);
      force_Rgyr(&(class->clatoms_info), class->clatoms_pos, ipt);
      zero_forces(&(Rgyr[ipt]),class->clatoms_info.natm_tot);
    }
    if (NH[ipt].on == 2) {
      zero_forces(&(NH[ipt]),class->clatoms_info.natm_tot);
      force_NH(&(class->clatoms_info), class->clatoms_pos, ipt);
      zero_forces(&(NH[ipt]),class->clatoms_info.natm_tot);
    }
     dafed_trajectory_io(&(class->clatoms_info), &(general_data->timeinfo), ipt, 
                         npara_temps_proc_off); 
}





