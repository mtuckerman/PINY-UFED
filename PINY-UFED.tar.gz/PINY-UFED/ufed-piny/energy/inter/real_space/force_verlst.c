/*==========================================================================*/
/*                      Brief description                                   */

/* The (nter)[i] atoms that interact with atom, i,                */
/* are stored in (jter)[i]                                        */
/* starting at element 1+(jver_off[i])]                           */
/* ending   at element (nter)[i]+(jver_off[i])]         */ 
/* These interactions are sent to the force routine in bundles of nlen.     */
/* Break points where memory conflicts can occur when summing the forces    */
/* are tablulated                                                           */

/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_real_space_local.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_communicate_wrappers.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void force_verlst(CLATOMS_INFO *clatoms_info,CLATOMS_POS *clatoms_pos,
                  FOR_SCR *for_scr,ATOMMAPS *atommaps,
                  CELL *cell,PTENS *ptens,INTERACT *interact,
                  ENERGY_CTRL *energy_ctrl, 
                  int nter[],list_int jter[],int jver_off[],
                  INTRA_SCR *intra_scr,double *vreal,double *vvdw,
                double *vcoul,CLASS_COMM_FORC_PKG *class_comm_forc_pkg)
     
{/*Begin Routine*/
  /*========================================================================*/
  /*          Local Variable declarations               */
  
  int ipart, jpart;           /* ith particle, jth particle          */
  int intact_tot;             /* total number interactions           */
  int intact_save;             /* total number interactions           */
  int num_call;               /*  number of force calls              */
  int num_call_save;          /*  number of force calls              */
  int lower,upper;            /* lower and upper limits on for loop  */
  int ifor_call;              /* force call flag                     */
  int joff, jind_off;     /* off sets                            */
  int i,iii,itemp;
  int nlen;
  int lst_typ=1;
  int natm_tot = clatoms_info->natm_tot;

/* Local Pointers */
  int *for_scr_intact    = &(for_scr->intact);
  int *for_scr_num_brk   = &(for_scr->num_brk);
  int *for_scr_num_brk_i = for_scr->num_brk_i;
  int *for_scr_i_index   = for_scr->i_index;  
  int *for_scr_j_index   = for_scr->j_index;  
  int myatm_start        = clatoms_info->myatm_start;
  int myatm_end          = clatoms_info->myatm_end;
  int myid                        = class_comm_forc_pkg->myid;

#ifdef REAL_PARA
  double vreal_t,vvdw_t,vcoul_t;
  double *fx             = clatoms_pos->fx;
  double *fy             = clatoms_pos->fy;
  double *fz             = clatoms_pos->fz;
  double *fx_t           = clatoms_pos->fx_t;
  double *fy_t           = clatoms_pos->fy_t;
  double *fz_t           = clatoms_pos->fz_t;
  double *fxt            = clatoms_pos->fxt;
  double *fyt            = clatoms_pos->fyt;
  double *fzt            = clatoms_pos->fzt;
  double *fxt_t          = clatoms_pos->fxt_t;
  double *fyt_t          = clatoms_pos->fyt_t;
  double *fzt_t          = clatoms_pos->fzt_t;

  double *hess_xx        = clatoms_pos->hess_xx;
  double *hess_xy        = clatoms_pos->hess_xy;
  double *hess_xz        = clatoms_pos->hess_xz;
  double *hess_yy        = clatoms_pos->hess_yy;
  double *hess_yz        = clatoms_pos->hess_yz;
  double *hess_zz        = clatoms_pos->hess_zz;
  double *hess_xx_t      = clatoms_pos->hess_xx_t;
  double *hess_xy_t      = clatoms_pos->hess_xy_t;
  double *hess_xz_t      = clatoms_pos->hess_xz_t;
  double *hess_yy_t      = clatoms_pos->hess_yy_t;
  double *hess_yz_t      = clatoms_pos->hess_yz_t;
  double *hess_zz_t      = clatoms_pos->hess_zz_t;
  double *pvten          = ptens->pvten;
  double *pvten_tot      = ptens->pvten_tot;
  double pvten_tmp[9];
  double pvten_tot_tmp[9];

  int pi_beads                    = clatoms_info->pi_beads;
  int hess_calc                   = clatoms_info->hess_calc;
  int nelem_hess                  = (clatoms_info->hess_calc > 1 ?natm_tot*natm_tot : natm_tot);
  int num_proc                    = class_comm_forc_pkg->num_proc;
  int intact_tot_t = 0;
  int num_call_t = 0;
  MPI_Comm comm_forc              = class_comm_forc_pkg->comm;
#endif
   


  //double start,end;//timing
  //DAFED_INFO *dinfo = clatoms_info->daf_info;


  /*========================================================================*/
  /*  I) Count the interactions and determine the number of force calls */

  intact_save = 0;
  nlen        =  (for_scr->nlen);
  for(ipart=1;ipart<=natm_tot;ipart++){
    intact_save += nter[ipart];
  }/*endfor*/
  num_call_save = intact_save/(nlen);
  if( (intact_save % (nlen))!=0 ){num_call_save += 1;}
  
  /*========================================================================*/
  /*  II) Initialize */
  
  (*for_scr_intact)  = 0;   
  (*for_scr_num_brk) = 0;
  num_call         = 0;
  intact_tot       = 0;
  
  /*========================================================================*/
  /* III) Loop over the possible interactions:                              */
#ifdef REAL_PARA
  if(myatm_start==1){myatm_start = 2;}
#else
  myatm_start = 2;
  myatm_end   = natm_tot;
#endif
  
  //printf("myid %i,st %i,end %i\n",myid,myatm_start,myatm_end);
  for(ipart=myatm_start;ipart<=myatm_end;ipart++){
    
    /*=======================================================================*/
    /*  A) Add interactions to the force routine interaction list            */
    /*     in chunks no greater than nlen: Keep track of the break points    */
    
    lower  = 1;
    upper  = 0;
    while(upper!=nter[ipart]){
      upper = nter[ipart];
      if(upper-lower+1+(*for_scr_intact)>(nlen)){
       upper = nlen - (*for_scr_intact) + lower-1;
      }/*endif*/
      jind_off = (*for_scr_intact)-lower+1;
      joff = jver_off[ipart];
      for(jpart=lower;jpart<=upper;jpart++){
       for_scr_j_index[(jpart+jind_off)]=jter[jpart+joff];
       for_scr_i_index[(jpart+jind_off)]=ipart;
      }/*endfor*/
      (*for_scr_intact) += upper-lower+1;
      (*for_scr_num_brk)++;
      for_scr_num_brk_i[(*for_scr_num_brk)] = upper-lower+1;
      lower = upper+1;
      
      /*=====================================================================*/
      /*  B) If enough interactions have accumulated (or you are done)       */
      /*       make a force call and then update and reinitialize            */
      /*       appropriate counters                                          */
      
      itemp = MIN(((nlen)-(*for_scr_intact)),1);
      if(!(itemp)){
       force_npol(clatoms_info,clatoms_pos,
                  for_scr,atommaps,
                  cell,ptens,interact,energy_ctrl,intra_scr,vreal,
                  vvdw,vcoul,num_call,lst_typ);


       num_call        += 1;
       intact_tot      += (*for_scr_intact);
       (*for_scr_intact)  = 0;   
       (*for_scr_num_brk) = 0;
     }/*endif*/


     if((*for_scr_num_brk)>=nlen){
       printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
       printf("Internal Error: If statement to dump force not performed\n ");
       printf("in routine for_verlst \n ");
       printf("Contact product support \n ");
       printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
       fflush(stdout);
       exit(1);
      }/*endif*/
    }/*endwhile*/
  }/*endfor*/
  /*========================================================================*/
  /* Communicate if real space parallel is turned on    */
  /* We can do this b/c inter-real is the first force calculated*/
#ifdef REAL_PARA
 if(num_proc>1){
  for(i=1;i<=natm_tot;i++){
     fx_t[i] = 0.0;
     fy_t[i] = 0.0;
     fz_t[i] = 0.0;
  }
  for(i=0;i<=8;i++){
    pvten_tmp[i] = 0.0;
    pvten_tot_tmp[i] = 0.0;
  }
  vreal_t = 0.0;
  vvdw_t  = 0.0;
  vcoul_t = 0.0;

  Barrier(comm_forc);
   Allreduce(&(fx[1]),&(fx_t[1]),natm_tot,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(&(fy[1]),&(fy_t[1]),natm_tot,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(&(fz[1]),&(fz_t[1]),natm_tot,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(vreal,&vreal_t,1,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(vvdw,&vvdw_t,1,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(vcoul,&vcoul_t,1,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(&(pvten[1]),pvten_tmp,9,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(&(pvten_tot[1]),pvten_tot_tmp,9,MPI_DOUBLE,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(&(intact_tot),&(intact_tot_t),1,MPI_INT,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);
   Allreduce(&(num_call),&(num_call_t),1,MPI_INT,MPI_SUM,1,comm_forc);
  Barrier(comm_forc);  

  for(i=1;i<=natm_tot;i++){
     fx[i] = fx_t[i];
     fy[i] = fy_t[i];
     fz[i] = fz_t[i];
  }
  for(i=1;i<=9;i++){
    pvten[i] = pvten_tmp[i-1];
    pvten_tot[i] = pvten_tot_tmp[i-1];
  }
  *(vreal) = vreal_t;
  *(vvdw)  = vvdw_t;
  *(vcoul) = vcoul_t;
  intact_tot = intact_tot_t;
  num_call   = num_call_t; 

  if(pi_beads>1){
    for(i=1;i<=natm_tot;i++){
      fx_t[i] = 0.0;
      fy_t[i] = 0.0;
      fz_t[i] = 0.0;
    }
    Barrier(comm_forc);
     Allreduce(&(fxt[1]),&(fxt_t[1]),natm_tot,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
     Allreduce(&(fyt[1]),&(fyt_t[1]),natm_tot,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
     Allreduce(&(fzt[1]),&(fzt_t[1]),natm_tot,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
    for(i=1;i<=natm_tot;i++){
      fxt[i] = fxt_t[i];
      fyt[i] = fyt_t[i];
      fzt[i] = fzt_t[i];
    }

  }//endif pi_beads
  if(hess_calc==1){
    for(i=1;i<=nelem_hess;i++){
      hess_xx_t[i] = 0.0;
      hess_xy_t[i] = 0.0;
      hess_xz_t[i] = 0.0;
      hess_yy_t[i] = 0.0;
      hess_yz_t[i] = 0.0;
      hess_zz_t[i] = 0.0;
    }
    Barrier(comm_forc);
     Allreduce(&(hess_xx[1]),&(hess_xx_t[1]),nelem_hess,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
     Allreduce(&(hess_xy[1]),&(hess_xy_t[1]),nelem_hess,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
     Allreduce(&(hess_xz[1]),&(hess_xz_t[1]),nelem_hess,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
     Allreduce(&(hess_yy[1]),&(hess_yy_t[1]),nelem_hess,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
     Allreduce(&(hess_yz[1]),&(hess_yz_t[1]),nelem_hess,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
     Allreduce(&(hess_zz[1]),&(hess_zz_t[1]),nelem_hess,MPI_DOUBLE,MPI_SUM,1,comm_forc);
    Barrier(comm_forc);
    for(i=1;i<=nelem_hess;i++){
      hess_xx[i] = hess_xx_t[i];
      hess_xy[i] = hess_xy_t[i];
      hess_xz[i] = hess_xz_t[i];
      hess_yy[i] = hess_yy_t[i];
      hess_yz[i] = hess_yz_t[i];
      hess_zz[i] = hess_zz_t[i];
    }
  }//endif hess_calc
 }//endif num_proc

#endif
  /*========================================================================*/

  if((*for_scr_intact)!=0) {
     force_npol(clatoms_info,clatoms_pos,
                for_scr,atommaps,
                cell,ptens,interact,energy_ctrl,intra_scr,vreal,
                vvdw,vcoul,num_call,lst_typ);
      num_call        += 1;
      intact_tot      += (*for_scr_intact);
      (*for_scr_intact)  = 0;   
      (*for_scr_num_brk) = 0;
  }/*endif*/
  
  /*========================================================================*/
  /* III) Check                */
  
  //printf("myid %i,tot %i,save %i\n",myid,intact_tot,intact_save);
  if(intact_tot!=intact_save){
    printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
    printf("Internal Error:\n ");
    printf("Incorrect number of interactions calculated\n ");
    printf("   in routine for_verlst \n ");
    printf("%d vs %d \n",intact_tot,intact_save);
    printf("Contact product support \n ");
    printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
    fflush(stdout);
    exit(1);
    /*endif*/}
   if(num_call!=num_call_save){
     printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
     printf("Internal Error:\n ");
     printf("Incorrect number of force calls\n ");
     printf("   in routine for_verlst \n ");
     printf("%d vs %d \n",num_call,num_call_save);
     printf("Contact product support \n ");
     fflush(stdout);
     printf("@@@@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
     exit(1);
     /*endif*/}
  
  /*------------------------------------------------------------------------*/
}/*end routine */
/*==========================================================================*/




