void md_switch_pt(CLASS *,BONDED *,GENERAL_DATA *, int ,char *);

void compute_wgt_frenkel(CLASS *, GENERAL_DATA *,char *);
