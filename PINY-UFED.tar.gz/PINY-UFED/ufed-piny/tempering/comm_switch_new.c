/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: switch_pt                                    */
/*                                                                          */
/* This subprogram performs the switching within the control_** structure   */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_cp.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_vel_sampl_class_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_temper_entry.h"
#include "../proto_defs/proto_temper_md.h"
#include "../proto_defs/proto_temper_local.h"

#define DEBUG_RAPH_PAR_OFF

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void switch_communicate_stat_avg(COMMUNICATE *communicate_m,
                                 COMMUNICATE *communicate, STAT_AVG *stat_avg,
                                 int npara_temps, int npara_temps_proc,
                                 int ipt_st, int ipt_end)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
  /* myid_m is the wide world                */
  /* comm_temper connects to the mini worlds */
#include "../typ_defs/typ_mask.h"

  int np_temper        = communicate_m->np_temper;
  int np_states        = communicate_m->np_states;
  int np_forc          = communicate_m->np_forc;
  int np_beads         = communicate_m->np_beads;
  int myid_temper      = communicate_m->myid_temper;
  int myid_m           = communicate_m->myid;

  MPI_Comm comm_temper = communicate_m->comm_temper;


  /* here are the mini worlds                */
  int myid             = communicate->myid;
  int myid_forc        = communicate->myid_forc;
  int myid_state       = communicate->myid_state;
  int myid_bead        = communicate->myid_bead;

  MPI_Comm comm_forc   = communicate->comm_forc;
  MPI_Comm comm_states = communicate->comm_states;
  MPI_Comm comm_bead   = communicate->comm_beads;

  int igo,i,j,k;
  int myid_inner;

  MPI_Comm comm_inner;

/*==========================================================================*/
/* I) Micro level communication : state/forc with beads                     */
 
  if(np_beads>1 && (np_states+np_forc-1)>1){
    if(myid_m==0){
      printf("Raph is too busy reading his biology to\n");
      printf("get four levels of parallel going now.\n");
      printf("Give him a call, perhaps he will be inspired\n");
    }/*endif*/
    Finalize();
    exit(1);
  }/*endif*/

/*==========================================================================*/
/* II) Low level communication : Bcast to guys helping with my temperers    */

   igo = 0;
   if(np_states>1){comm_inner=comm_states; myid_inner=myid_state; igo=1;}
   if(np_forc>1)  {comm_inner=comm_forc;   myid_inner=myid_forc;  igo=1;}
   if(np_beads>1) {comm_inner=comm_bead;   myid_inner=myid_bead;  igo=1;}

   if(igo==1){
     Bcast_stat_avg_grp(stat_avg,npara_temps,npara_temps_proc,comm_inner,myid_inner);
   }/*endif*/

/*==========================================================================*/
/* III) High level communication : Bcast edge guys to other temperers       */

   Send_stat_avg_updn(stat_avg,npara_temps,npara_temps_proc,
                      comm_temper,myid_temper,np_temper,ipt_st,ipt_end);

/*--------------------------------------------------------------------------*/
   }/*end routine*/
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void Bcast_stat_avg_grp(STAT_AVG *stat_avg,int npara_temps,
                        int npara_temps_proc,MPI_Comm comm,int myid)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

  int i,j;
  int nsend_dbl    = stat_avg[1].nsend_dbl;
  double *data_dbl = stat_avg[1].data_ds;
  double *rand     = stat_avg[1].rand_vec;

  if(myid==0){
    j = 1;
    for(i=1;i<=npara_temps_proc;i++){
      stat_avg_pack(data_dbl,stat_avg,j,i);
      j+=nsend_dbl;
    }/*endfor*/
  }/*endif*/

  Barrier(comm);
    Bcast(&(rand[1]),npara_temps,MPI_DOUBLE,0,comm);
    Bcast(&(data_dbl[1]),nsend_dbl*npara_temps_proc,MPI_DOUBLE,0,comm);
  Barrier(comm);

  if(myid!=0){
    j = 1;
    for(i=1;i<=npara_temps_proc;i++){
      stat_avg_unpack(data_dbl,stat_avg,j,i);
      j+=nsend_dbl;
    }/*endfor*/
  }/*endif*/

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void Send_stat_avg_updn(STAT_AVG *stat_avg,int npara_temps,
			int npara_temps_proc,MPI_Comm comm,int myid,int np,
                        int ipt_st,int ipt_end)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

  int i,j;
  int myid_up,myid_dn;
  int myid_up_st,myid_dn_st;
  int myid_up_rt,myid_dn_rt;

  int nsend_dbl    = stat_avg[1].nsend_dbl;
  int nsend_dbl_1  = stat_avg[1].nsend_dbl+1;
  double *data_us  = stat_avg[1].data_us;
  double *data_ds  = stat_avg[1].data_ds;
  double *data_ur  = stat_avg[1].data_ur;
  double *data_dr  = stat_avg[1].data_dr;
  double *rand    = stat_avg[1].rand_vec;

/*==========================================================================*/
/*  "Up" and "Down" myids                                                   */

  fetch_updn_id(np,myid,&myid_up,&myid_dn,&myid_up_st,&myid_dn_st,
                                  &myid_dn_rt,&myid_up_rt);

/*==========================================================================*/
/* the "Up"-send and "Down" receive                                         */

  j = 1;
  i = npara_temps_proc;
  stat_avg_pack(data_us,stat_avg,j,i);

  Barrier(comm);
    Send(&(data_us[1]),nsend_dbl,MPI_DOUBLE,myid_up,myid_up_st,comm);
    Recv(&(data_dr[1]),nsend_dbl,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
  Barrier(comm);

  j = 1;
  i = 0;
  stat_avg_unpack(data_dr,stat_avg,j,i);

/*==========================================================================*/
/* the "Down"-send and "Up"-receive                                         */

  j = 1;
  i = 1;
  stat_avg_pack(data_ds,stat_avg,j,i);
  data_ds[(nsend_dbl+1)] = rand[ipt_st];

  Barrier(comm);
    Send(&(data_ds[1]),nsend_dbl_1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
    Recv(&(data_ur[1]),nsend_dbl_1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
  Barrier(comm);

  j = 1;
  i = npara_temps_proc+1;
  stat_avg_unpack(data_ur,stat_avg,j,i);
  rand[(ipt_end+1)] = data_ur[(nsend_dbl+1)];

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void stat_avg_pack(double *data, STAT_AVG *stat_avg,int k,int i)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/

    int j=k;

    data[j] = stat_avg[i].vintert;        j++; 
    data[j] = stat_avg[i].vintrat;        j++;
    data[j] = stat_avg[i].kin_harm;       j++;
    data[j] = stat_avg[i].cp_ehart;       j++;
    data[j] = stat_avg[i].cp_eext;        j++;
    data[j] = stat_avg[i].cp_exc;         j++;
    data[j] = stat_avg[i].cp_eke;         j++;
    data[j] = stat_avg[i].cp_enl;         j++;
    data[j] = stat_avg[i].kinet_nhc_bead; j++;
    data[j] = stat_avg[i].kinet_cp;       j++;
    data[j] = stat_avg[i].kinet_nhc_cp;   j++;

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void stat_avg_unpack(double *data, STAT_AVG *stat_avg,int k,int i)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
    int j=k;

    stat_avg[i].vintert        = data[j];     j++; 
    stat_avg[i].vintrat        = data[j];     j++;
    stat_avg[i].kin_harm       = data[j];     j++;
    stat_avg[i].cp_ehart       = data[j];     j++;
    stat_avg[i].cp_eext        = data[j];     j++;
    stat_avg[i].cp_exc         = data[j];     j++;
    stat_avg[i].cp_eke         = data[j];     j++;
    stat_avg[i].cp_enl         = data[j];     j++;
    stat_avg[i].kinet_nhc_bead = data[j];     j++;
    stat_avg[i].kinet_cp       = data[j];     j++;
    stat_avg[i].kinet_nhc_cp   = data[j];     j++;

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void switch_communicate_atoms(int natm,int pimd_on, int npara_temps_proc,
                              int pi_beads_proc,CLATOMS_POS *clatoms_pos, 
                              MPI_Comm comm,int myid,int np,int myid_m, 
                              int myid_bead, int myid_forc)

/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

  int i,iii;
  int ip,ipt,jpt;
  int myid_up,myid_dn;
  int myid_up_st,myid_dn_st;
  int myid_up_rt,myid_dn_rt;

  int nsend1,nsend2,npt;
  double *chunk_send1, *chunk_recv1; /* this depends on the cool malloc */
  double *chunk_send2, *chunk_recv2; /* in mall_coords                  */
  double *x_ipt,*x_jpt;

  MPI_Request req_up_send1,req_up_send2;
  MPI_Request req_dn_recv1,req_dn_recv2;
  MPI_Request req_dn_send1,req_dn_send2;
  MPI_Request req_up_recv1,req_up_recv2;

  MPI_Status stat_up_send1,stat_up_send2;
  MPI_Status stat_dn_recv1,stat_dn_recv2;
  MPI_Status stat_dn_send1,stat_dn_send2;
  MPI_Status stat_up_recv1,stat_up_recv2;

/*==========================================================================*/
/*  "Up" and "Down" myids and constants                                     */

  fetch_updn_id(np,myid,&myid_up,&myid_dn,&myid_up_st,&myid_dn_st,
                                 &myid_dn_rt,&myid_up_rt);
#ifdef DEBUG_RAPH_PAR
  printf("comm_switch1: myid_m=%d myid=%d myid_up=%d myid_dn=%d np=%d\n",
          myid_m,myid,myid_up,myid_dn,np);
#endif
  nsend1 = natm*9+2;
  nsend2 = natm*9;

  npt    = npara_temps_proc; /* short and sweet */

/*==========================================================================*/
/* The up-send and dn-receive */

  for(ip=1;ip<=pi_beads_proc;ip++){
    ipt = ip + (npt-1)*pi_beads_proc; /* up send */
    jpt = ip - pi_beads_proc;             /* dn recv */

    /* positions, velocities forces */
    x_ipt                 = clatoms_pos[ipt].x;
    x_jpt                 = clatoms_pos[jpt].x;
    chunk_send1           = &(x_ipt[1]);
    chunk_recv1           = &(x_jpt[1]);
    chunk_send1[nsend1-2] = (double)(clatoms_pos[ipt].origin);
    chunk_send1[nsend1-1] = (double)(clatoms_pos[ipt].idirect);

    Barrier(comm);
      ISend(chunk_send1,nsend1,MPI_DOUBLE,myid_up,myid_up_st,comm,&req_up_send1);
      IRecv(chunk_recv1,nsend1,MPI_DOUBLE,myid_dn,myid_dn_rt,comm,&req_dn_recv1);
    Barrier(comm);
    myid_up_st += 2*np;
    myid_dn_rt += 2*np;

    if(pimd_on==1){
      /* mode positions,forces */
      x_ipt        = clatoms_pos[ipt].fxt;
      x_jpt        = clatoms_pos[jpt].fxt;
      chunk_send2  = &(x_ipt[1]);
      chunk_recv2  = &(x_jpt[1]);
      Barrier(comm);
        ISend(chunk_send2,nsend2,MPI_DOUBLE,myid_up,myid_up_st,comm,&req_up_send2);
        IRecv(chunk_recv2,nsend2,MPI_DOUBLE,myid_dn,myid_dn_rt,comm,&req_dn_recv2);
      Barrier(comm);
      myid_up_st += 2*np;
      myid_dn_rt += 2*np;
    }/*endif*/

    /* Call Waiting */
    Wait(&req_up_send1,&stat_up_send1);
    Wait(&req_dn_recv1,&stat_dn_recv1);
    if(pimd_on==1){
       Wait(&req_up_send2,&stat_up_send2);
       Wait(&req_dn_recv2,&stat_dn_recv2);
    }/*endif*/
    (clatoms_pos[jpt].origin)  = (int)(chunk_recv1[nsend1-2]);
    (clatoms_pos[jpt].idirect) = (int)(chunk_recv1[nsend1-1]);
#ifdef DEBUG_RAPH_PAR
    if(ip==1){
      printf("comm_switch2: myid_m=%d myid=%d myid_dn_recv %d myid_bead %d\n",
              myid_m,myid,((int)(chunk_recv1[nsend1-1])),myid_bead);
    }/*endif*/
#endif
  }/*endfor : ip*/

/*==========================================================================*/
/* The dn-send and up-receive */

  for(ip=1;ip<=pi_beads_proc;ip++){
    ipt = ip + npt*pi_beads_proc;  /* dn recv */
    jpt = ip;                      /* dn send */

    /* positions, velocities forces */
    x_ipt                 = clatoms_pos[ipt].x;
    x_jpt                 = clatoms_pos[jpt].x;
    chunk_recv1           = &(x_ipt[1]);
    chunk_send1           = &(x_jpt[1]);
    chunk_send1[nsend1-2] = (double)(clatoms_pos[jpt].origin);
    chunk_send1[nsend1-1] = (double)(clatoms_pos[jpt].idirect);
    Barrier(comm);
      ISend(chunk_send1,nsend1,MPI_DOUBLE,myid_dn,myid_dn_st,comm,&req_dn_send1);
      IRecv(chunk_recv1,nsend1,MPI_DOUBLE,myid_up,myid_up_rt,comm,&req_up_recv1);
    Barrier(comm);
    myid_dn_st += 2*np;
    myid_up_rt += 2*np;

    if(pimd_on==1){
       /* mode positions, velocities forces */
       x_ipt = clatoms_pos[ipt].fxt;
       x_jpt = clatoms_pos[jpt].fxt;
       chunk_recv2 = &(x_ipt[1]);
       chunk_send2 = &(x_jpt[1]);
       Barrier(comm);
         ISend(chunk_send2,nsend2,MPI_DOUBLE,myid_dn,myid_dn_st,comm,&req_dn_send2);
         IRecv(chunk_recv2,nsend2,MPI_DOUBLE,myid_up,myid_up_rt,comm,&req_up_recv2);
       Barrier(comm);
       myid_dn_st += 2*np;
       myid_up_rt += 2*np;
    }/*endif*/

    /* Call Waiting */
    Wait(&req_dn_send1,&stat_dn_send1);
    Wait(&req_up_recv1,&stat_up_recv1);
    if(pimd_on==1){
      Wait(&req_dn_send2,&stat_dn_send2);
      Wait(&req_up_recv2,&stat_up_recv2);
    }/*endif*/
    (clatoms_pos[ipt].origin)  =  (int)(chunk_recv1[nsend1-2]);
    (clatoms_pos[ipt].idirect) =  (int)(chunk_recv1[nsend1-1]);
  }/*endfor : ip*/

/*--------------------------------------------------------------------------*/
   }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void switch_communicate_states()
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"
/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void comm_switch_wave(int iadd,int mytoggle,int npara_temps_proc,int npara_temps,
                      int *move_accepted,CP *cp)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
/* Some conditions apply */

  if(cp_lsda==1){
      printf("Sorry dude, Raph has to make donuts with his SUV\n");
      printf("no parallel lsda state switches for you.\n");
      Finalize();
      exit(1);
   }/*endif*/

/*==========================================================================*/

/*  1) Communicate up into scratch             */
/*  2) check the move_accepted flag */
/*     if(move_accepted[npara_temps_proc]=1){ copy out the up move } */

/*  1) Communicate dn                                        */
/*  2) Check the move_accepted flag                          */
/*     if(move_accepted[0]=1){ copy out the dn move }        */

  int i,iii;
  int ip,ipt,jpt;
  int myid_up,myid_dn;
  int myid_up_stag,myid_dn_stag;
  int myid_up_rtag,myid_dn_rtag;

  int nsend,npt;

  npt    = npara_temps_proc; /* short and sweet */

/*==========================================================================*/
/*  "Up" and "Down" myids and constants                                     */

  fetch_updn_id(np,myid,&myid_up,&myid_dn,&myid_up_stag,&myid_dn_stag,
                                 &myid_dn_rtag,&myid_up_rtag);
#ifdef DEBUG_RAPH_PAR
  printf("comm_w_switch1: myid_m=%d myid=%d myid_up=%d myid_dn=%d np=%d\n",
          myid_m,myid,myid_up,myid_dn,np);
#endif

/*==========================================================================*/
/* here we need to mesh the up_send/dn_recv and the dn_send/up_recv */
  copy_flag =  move_accepted[npt];

  for(ip=1;ip<=pi_beads_proc;ip++){
    ipt_us = ip + (npt-1)*pi_beads_proc;     /* up send */
    jpt_dr = ip - pi_beads_proc;             /* dn recv */
    ipt_ur = ip + npt*pi_beads_proc;         /* up recv */
    jpt_ds = ip;                             /* dn send */

    if(myid%2==1){        /* send off odd ones, receive on even ones */











     /* send to scratch in cp_scr_wave */
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].cre_up,cp_scrwave[ipt].cre_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].cim_up,cp_scrwave[ipt].cim_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].vcre_up,cp_scrwave[ipt].vcre_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].vcim_up,cp_scrwave[ipt].vcim_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].fcre_up,cp_scrwave[ipt].fcre_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].fcim_up,cp_scrwave[ipt].fcim_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

     /* send to scratch in cp_scr_ovmat */
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].ksmat_up,cp_ovmat[ipt].ovlap1,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].norbmat_up,cp_ovmat[ipt].ovlap3,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].norbmati_up,cp_ovmat[ipt].ovlap4,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].ovmat_eigv_up,cp_ovmat[ipt].ovlap5,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].ksmat_eig_up_up,cp_ovmat[ipt].state_vec1,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

      /* send to special scratch in temper_pos */
    offset = cptherm_info->num_c_nhc*cptherm_info->len_c_nhc;

    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      therm_pos[ipt].c_nhc,therm_pos[ipt].rec_scr[0*offset],
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      therm_pos[ipt].vc_nhc,therm_pos[ipt].rec_scr[1*offset],
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      therm_pos[ipt].fc_nhc,therm_pos[ipt].rec_scr[2*offset],
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

      /* single number send as a blck */
       switch_val_dble(&(cp_pos[ipt].max_diag),&(cp_pos[jpt].max_diag));
       switch_val_dble(&(cp_pos[ipt].max_off_diag),&(cp_pos[jpt].max_off_diag));
       switch_val_dble(&(cp_pos[ipt].ks_offset),&(cp_pos[jpt].ks_offset));
       switch_val_dble(&(therm_pos[ipt].c_nhc_massiv),&(therm_pos[jpt].c_nhc_massiv));
      /* end */

  }/*endfor : ip*/

/*==========================================================================*/
/* The dn-send and up-receive */
  copy_flag =  move_accepted[0];

  for(ip=1;ip<=pi_beads_proc;ip++){
    ipt = ip + npt*pi_beads_proc;  /* dn recv */
    jpt = ip;                      /* dn send */
    if(myid%2==1){
     /* send to scratch in cp_scr_wave */
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].cre_up,cp_scrwave.cre_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[ipt].cim_up,cp_scrwave.cim_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].vcre_up,cp_scrwave.vcre_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].vcim_up,cp_scrwave.vcim_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].fcre_up,cp_scrwave.fcre_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].fcim_up,cp_scrwave.fcim_up,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

     /* send to scratch in cp_scr_ovmat */
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].ksmat_up,cp_ovmat[jpt].ovlap1,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].norbmat_up,cp_ovmat[jpt].ovlap3,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].norbmati_up,cp_ovmat[jpt].ovlap4,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].ovmat_eigv_up,cp_ovmat[jpt].ovlap5,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      cp_pos[jpt].ksmat_eig_up_up,cp_ovmat[jpt].state_vec1,
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

      /* send to special scratch in temper_pos */
    offset = cptherm_info->num_c_nhc*cptherm_info->len_c_nhc;

    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      therm_pos[jpt].c_nhc,therm_pos[jpt].rec_scr[0*offset],
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      therm_pos[jpt].vc_nhc,therm_pos[jpt].rec_scr[1*offset],
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;
    send_updn(nsize,myid_up,myid_dn,myid_up_stag,myid_up_rtag,
	      therm_pos[jpt].fc_nhc,therm_pos[jpt].rec_scr[2*offset],
	      comm,copy_flag);    myid_up_st += 2*np;    myid_dn_rt += 2*np;

      /* single number send as a blck */
       switch_val_dble(&(cp_pos[jpt].max_diag),&(cp_pos[ipt].max_diag));
       switch_val_dble(&(cp_pos[jpt].max_off_diag),&(cp_pos[ipt].max_off_diag));
       switch_val_dble(&(cp_pos[jpt].ks_offset),&(cp_pos[ipt].ks_offset));
       switch_val_dble(&(therm_pos[jpt].c_nhc_massiv),&(therm_pos[ipt].c_nhc_massiv));
      /* end */
    }/*endif*/
  }/*endfor : ip*/

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void fetch_updn_id(int np,int myid,int *myid_up,int *myid_dn,
                   int *myid_up_st,int *myid_dn_st,
                   int *myid_dn_rt,int *myid_up_rt)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/

   /* up/dn ids using PBC */
   myid_up[0] = (myid+1); if(myid_up[0]==np){myid_up[0] = 0;     }
   myid_dn[0] = (myid-1); if(myid_dn[0]==-1){myid_dn[0] = (np-1);}

   /* up/dn send tags */
   myid_up_st[0] = myid_up[0]+np;
   myid_dn_st[0] = myid_dn[0]+2*np;

   /* up/dn recv tags */
   myid_dn_rt[0] = myid+np;
   myid_up_rt[0] = myid+2*np;

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void send_updn(int nsize, int myid_send_to, int myid_recv_fr, int itag_send,
	       int itag_recv, double *send, double * recv,
               MPI_Comm comm, int move_accepted)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

  MPI_Request req_send;
  MPI_Request req_recv;

  MPI_Status stat_send;
  MPI_Status stat_recv;

  /* send "send" to "recv" */
    Barrier(comm);
      ISend(send,nsize,MPI_DOUBLE,myid_send_to,itag_send,comm,&req_send);
      IRecv(recv,nsize,MPI_DOUBLE,myid_recv_fr,itag_recv,comm,&req_recv);
    Barrier(comm);

    /* Call Waiting */
    Wait(&req_send,&stat_send);
    Wait(&req_recv,&stat_recv);

    /*I guess here we need to check if we copy and do it */
/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/
