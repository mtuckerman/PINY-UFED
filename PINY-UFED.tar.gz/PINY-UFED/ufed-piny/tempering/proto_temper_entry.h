/*---------------------------------------------------------------------*/
/* switcher.c      */

void control_switch_pt(CLASS *,BONDED *,GENERAL_DATA *,CP *, int ,char *);

void      cp_switch_pt(CLASS *,BONDED *,GENERAL_DATA *,CP *, int ,char *);

/*---------------------------------------------------------------------*/
/* para_temp_init.c   */

void mall_para_temp(CLASS *,BONDED *,GENERAL_DATA *,CP *);

void init_parallel_tempering(GENERAL_DATA *, CLASS *,CP *);

void prelim_paratemp(STAT_AVG *, CLATOMS_POS *, int ,int, int, int);

/*---------------------------------------------------------------------*/
