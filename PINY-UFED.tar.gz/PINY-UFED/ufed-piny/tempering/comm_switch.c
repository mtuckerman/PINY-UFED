/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: switch_pt                                    */
/*                                                                          */
/* This subprogram performs the switching within the control_** structure   */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_cp.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_vel_sampl_class_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_temper_entry.h"
#include "../proto_defs/proto_temper_md.h"
#include "../proto_defs/proto_temper_local.h"

#define DEBUG_RAPH_PAR_OFF

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void switch_communicate_stat_avg(COMMUNICATE *communicate_m,
                                 COMMUNICATE *communicate, STAT_AVG *stat_avg,
                                 CLATOMS_INFO *clatoms_info,
                                 int npara_temps, int npara_temps_proc,
                                 int ipt_st, int ipt_end, int opt)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
  /* myid_m is the wide world                */
  /* comm_temper connects to the mini worlds */
#include "../typ_defs/typ_mask.h"

  int np_temper        = communicate_m->np_temper;
  int np_states        = communicate_m->np_states;
  int np_forc          = communicate_m->np_forc;
  int np_beads         = communicate_m->np_beads;
  int myid_temper      = communicate_m->myid_temper;
  int myid_m           = communicate_m->myid;

  MPI_Comm comm_temper = communicate_m->comm_temper;


  /* here are the mini worlds                */
  int myid             = communicate->myid;
  int myid_forc        = communicate->myid_forc;
  int myid_state       = communicate->myid_state;
  int myid_bead        = communicate->myid_bead;

  MPI_Comm comm_forc   = communicate->comm_forc;
  MPI_Comm comm_states = communicate->comm_states;
  MPI_Comm comm_bead   = communicate->comm_beads;

  int igo,i,j,k;
  int myid_inner;

  MPI_Comm comm_inner;

/*==========================================================================*/
/* I) Micro level communication : state/forc with beads                     */
 
  if(np_beads>1 && (np_states+np_forc-1)>1){
    if(myid_m==0){
      printf("Raph is too busy reading his biology to\n");
      printf("get four levels of parallel going now.\n");
      printf("Give him a call, perhaps he will be inspired\n");
    }/*endif*/
    Finalize();
    exit(1);
  }/*endif*/

/*==========================================================================*/
/* II) Low level communication : Bcast to guys helping with my temperers    */

   igo = 0;
   if(np_states>1){comm_inner=comm_states; myid_inner=myid_state; igo=1;}
   if(np_forc>1)  {comm_inner=comm_forc;   myid_inner=myid_forc;  igo=1;}
   if(np_beads>1) {comm_inner=comm_bead;   myid_inner=myid_bead;  igo=1;}

   if(igo==1){
     Bcast_stat_avg_grp(stat_avg,clatoms_info,npara_temps,
                        npara_temps_proc,comm_inner,myid_inner,opt);
   }/*endif*/
      

/*==========================================================================*/
/* III) High level communication : Bcast edge guys to other temperers       */

   Send_stat_avg_updn(stat_avg,clatoms_info,npara_temps,npara_temps_proc,
                      comm_temper,myid_temper,np_temper,ipt_st,ipt_end,opt);

/*--------------------------------------------------------------------------*/
   }/*end routine*/
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void Bcast_stat_avg_grp(STAT_AVG *stat_avg,CLATOMS_INFO *clatoms_info,int npara_temps,
                        int npara_temps_proc,MPI_Comm comm,int myid,int opt)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

  int i,j;
  int n_freq;
  int nsend_dbl        = stat_avg[1].nsend_dbl;
  double *data_dbl     = stat_avg[1].data_ds;
  double *rand         = stat_avg[1].rand_vec;
  double *ree_s,*rgyr_s,*nh_s;        

  if(myid==0){
    j = 1;
    for(i=1;i<=npara_temps_proc;i++){
      stat_avg_pack(data_dbl,stat_avg,j,i);
      j+=nsend_dbl;
    }/*endfor*/
  }/*endif*/

  Barrier(comm);
    Bcast(&(rand[1]),npara_temps,MPI_DOUBLE,0,comm);
    Bcast(&(data_dbl[1]),nsend_dbl*npara_temps_proc,MPI_DOUBLE,0,comm);
  Barrier(comm);
  
  if(myid!=0){
    j = 1;
    for(i=1;i<=npara_temps_proc;i++){
      stat_avg_unpack(data_dbl,stat_avg,j,i);
      j+=nsend_dbl;
    }/*endfor*/
  }/*endif*/
  if(opt==2){
    for(i=1;i<=npara_temps_proc;i++){
         Barrier(comm);
          Bcast(&(clatoms_info->Ree[i].on),1,MPI_INT,0,comm);
          Bcast(&(clatoms_info->Rgyr[i].on),1,MPI_INT,0,comm);
          Bcast(&(clatoms_info->NH[i].on),1,MPI_INT,0,comm);
         Barrier(comm);
         if(clatoms_info->Ree[i].on>0){
           ree_s = &(clatoms_info->Ree[i].s);
           Barrier(comm);
            Bcast(ree_s,1,MPI_DOUBLE,0,comm);
           Barrier(comm);
         }
         if(clatoms_info->Rgyr[i].on>0){
           rgyr_s = &(clatoms_info->Rgyr[i].s); 
           Barrier(comm);
            Bcast(rgyr_s,1,MPI_DOUBLE,0,comm);
           Barrier(comm);
         }
         if(clatoms_info->NH[i].on>0){
           nh_s = &(clatoms_info->NH[i].s);
           Barrier(comm);
            Bcast(nh_s,1,MPI_DOUBLE,0,comm);
           Barrier(comm);
         }
     }/*end for*/

      
    if(myid==0){
      for(i=1;i<=npara_temps_proc;i++){
         cv_freq_pack(stat_avg,i,i);
         stat_avg[i].freq_x_recv = stat_avg[i].freq_x_send;
         stat_avg[i].freq_recv = stat_avg[i].freq_send;
      }/*endfor*/
    }
    for(i=1;i<=npara_temps_proc;i++){
       Barrier(comm);
         Bcast(stat_avg[i].freq_x_recv,stat_avg[i].n_freq,MPI_DOUBLE,0,comm);
         Bcast(stat_avg[i].freq_recv,stat_avg[i].n_freq,MPI_INT,0,comm);
       Barrier(comm);
    }/*endfor*/
    if(myid==0){
      for(i=1;i<=npara_temps_proc;i++){
         n_freq = stat_avg[i].n_freq;
         for(j=1;j<=n_freq;j++){
            cfree(&(stat_avg[i].freq_x_send[n_freq-j+1]));
            cfree(&(stat_avg[i].freq_send[n_freq-j+1]));
            cfree(&(stat_avg[i].freq_x_recv[n_freq-j+1]));
            cfree(&(stat_avg[i].freq_recv[n_freq-j+1]));
         }/*endfor*/
      }/*endfor*/
    }
    else{
      for(i=1;i<=npara_temps_proc;i++){
        cv_freq_unpack(stat_avg,i,i);
      }/*endfor i*/
    }/*endif myid*/
  }/*endif opt*/
      
/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void Send_stat_avg_updn(STAT_AVG *stat_avg,CLATOMS_INFO *clatoms_info,
                        int npara_temps,
			int npara_temps_proc,MPI_Comm comm,int myid,int np,
                        int ipt_st,int ipt_end,int opt)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

  int i,j;
  int myid_up,myid_dn;
  int myid_up_st,myid_dn_st;
  int myid_up_rt,myid_dn_rt;
  int n_list;

  int nsend_dbl    = stat_avg[1].nsend_dbl;
  int nsend_dbl_1  = stat_avg[1].nsend_dbl+1;
  double *data_us  = stat_avg[1].data_us;
  double *data_ds  = stat_avg[1].data_ds;
  double *data_ur  = stat_avg[1].data_ur;
  double *data_dr  = stat_avg[1].data_dr;
  double *rand     = stat_avg[1].rand_vec;
/*  double *freq_x_send  // = stat_avg[1].freq_x_send;
  double *freq_x_recv  // = stat_avg[1].freq_x_recv;
  double *freq_send    // = stat_avg[1].freq_send;
  double *freq_recv    // = stat_avg[1].freq_recv;
*/

/*==========================================================================*/
/*  "Up" and "Down" myids                                                   */

  fetch_updn_id(np,myid,&myid_up,&myid_dn,&myid_up_st,&myid_dn_st,
                                  &myid_dn_rt,&myid_up_rt);

/*==========================================================================*/
/* the "Up"-send and "Down" receive                                         */

  j = 1;
  i = npara_temps_proc;
  stat_avg_pack(data_us,stat_avg,j,i);
  
  Barrier(comm);
    Send(&(data_us[1]),nsend_dbl,MPI_DOUBLE,myid_up,myid_up_st,comm);
    Recv(&(data_dr[1]),nsend_dbl,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
  Barrier(comm);

  j = 1;
  i = 0;
  stat_avg_unpack(data_dr,stat_avg,j,i);
  
  if(opt==2){ //dafed
    j = 0; //receive index, different meaning with j before
    i = npara_temps_proc; //send index
    n_list = stat_avg[j].n_list;
    if(n_list==1){
      stat_avg[j].cv_x_min = (double *)cmalloc(n_list*sizeof(double))-1;
      stat_avg[j].cv_x_max = (double *)cmalloc(n_list*sizeof(double))-1;
      stat_avg[j].w_bin = (double *)cmalloc(n_list*sizeof(double))-1;
      Barrier(comm);
        Send(&(stat_avg[i].cv_x_min[1]),n_list,MPI_DOUBLE,myid_up,myid_up_st,comm);
        Recv(&(stat_avg[j].cv_x_min[1]),n_list,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
      Barrier(comm);
        Send(&(stat_avg[i].cv_x_max[1]),n_list,MPI_DOUBLE,myid_up,myid_up_st,comm);
        Recv(&(stat_avg[j].cv_x_max[1]),n_list,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
      Barrier(comm);
        Send(&(stat_avg[i].w_bin[1]),n_list,MPI_DOUBLE,myid_up,myid_up_st,comm);
        Recv(&(stat_avg[j].w_bin[1]),n_list,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
      Barrier(comm);
      if(clatoms_info->Ree[i].on>=1){
        Barrier(comm);
          Send(&(clatoms_info->Ree[i].s),1,MPI_DOUBLE,myid_up,myid_up_st,comm);
          Recv(&(clatoms_info->Ree[j].s),1,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
        Barrier(comm);
      }
      if(clatoms_info->Rgyr[i].on>=1){
        Barrier(comm);
          Send(&(clatoms_info->Rgyr[i].s),1,MPI_DOUBLE,myid_up,myid_up_st,comm);
          Recv(&(clatoms_info->Rgyr[j].s),1,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
        Barrier(comm);
      }
      if(clatoms_info->NH[i].on>=1){
        Barrier(comm);
          Send(&(clatoms_info->NH[i].s),1,MPI_DOUBLE,myid_up,myid_up_st,comm);
          Recv(&(clatoms_info->NH[j].s),1,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
        Barrier(comm);
      }
    }/*endif n_list*/
    cv_freq_pack(stat_avg,j,i);
    Barrier(comm);
      Send(&(stat_avg[i].freq_x_send[1]),stat_avg[i].n_freq,MPI_DOUBLE,myid_up,myid_up_st,comm);
      Recv(&(stat_avg[j].freq_x_recv[1]),stat_avg[j].n_freq,MPI_DOUBLE,myid_dn,myid_dn_rt,comm);
    Barrier(comm);
      Send(&(stat_avg[i].freq_send[1]),stat_avg[i].n_freq,MPI_INT,myid_up,myid_up_st,comm);
      Recv(&(stat_avg[j].freq_recv[1]),stat_avg[j].n_freq,MPI_INT,myid_dn,myid_dn_rt,comm);
    Barrier(comm);
    cv_freq_unpack(stat_avg,j,i);
  }

/*==========================================================================*/
/* the "Down"-send and "Up"-receive                                         */

  j = 1;
  i = 1;
  stat_avg_pack(data_ds,stat_avg,j,i);
  data_ds[(nsend_dbl+1)] = rand[ipt_st];

  Barrier(comm);
    Send(&(data_ds[1]),nsend_dbl_1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
    Recv(&(data_ur[1]),nsend_dbl_1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
  Barrier(comm);

  j = 1;
  i = npara_temps_proc+1;
  stat_avg_unpack(data_ur,stat_avg,j,i);
  rand[(ipt_end+1)] = data_ur[(nsend_dbl+1)];

  if(opt==2){ //dafed
    j = npara_temps_proc+1; //receive index, different meaning with j before
    i = 1; //send index
    n_list = stat_avg[j].n_list;
    if(n_list==1){
      stat_avg[j].cv_x_min = (double *)cmalloc(n_list*sizeof(double))-1;
      stat_avg[j].cv_x_max = (double *)cmalloc(n_list*sizeof(double))-1;
      stat_avg[j].w_bin = (double *)cmalloc(n_list*sizeof(double))-1;
      Barrier(comm);
        Send(&(stat_avg[i].cv_x_min[1]),1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
        Recv(&(stat_avg[j].cv_x_min[1]),1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
      Barrier(comm);
        Send(&(stat_avg[i].cv_x_max[1]),1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
        Recv(&(stat_avg[j].cv_x_max[1]),1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
      Barrier(comm);
        Send(&(stat_avg[i].w_bin[1]),1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
        Recv(&(stat_avg[j].w_bin[1]),1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
      Barrier(comm);
      if(clatoms_info->Ree[i].on>=1){
        Barrier(comm);
          Send(&(clatoms_info->Ree[i].s),1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
          Recv(&(clatoms_info->Ree[j].s),1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
        Barrier(comm);
      }
      if(clatoms_info->Rgyr[i].on>=1){
        Barrier(comm);
          Send(&(clatoms_info->Rgyr[i].s),1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
          Recv(&(clatoms_info->Rgyr[j].s),1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
        Barrier(comm);
      }
      if(clatoms_info->NH[i].on>=1){
        Barrier(comm);
          Send(&(clatoms_info->NH[i].s),1,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
          Recv(&(clatoms_info->NH[j].s),1,MPI_DOUBLE,myid_up,myid_up_rt,comm);
        Barrier(comm);
      }
    }/*endif n_list*/
    Barrier(comm);
    cv_freq_pack(stat_avg,j,i);
    Barrier(comm);
      Send(&(stat_avg[i].freq_x_send[1]),stat_avg[i].n_freq,MPI_DOUBLE,myid_dn,myid_dn_st,comm);
      Recv(&(stat_avg[j].freq_x_recv[1]),stat_avg[j].n_freq,MPI_DOUBLE,myid_up,myid_up_rt,comm);
    Barrier(comm);
      Send(&(stat_avg[i].freq_send[1]),stat_avg[i].n_freq,MPI_INT,myid_dn,myid_dn_st,comm);
      Recv(&(stat_avg[j].freq_recv[1]),stat_avg[j].n_freq,MPI_INT,myid_up,myid_up_rt,comm);
    Barrier(comm);    
    cv_freq_unpack(stat_avg,j,i);
  }

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void stat_avg_pack(double *data, STAT_AVG *stat_avg,int k,int i)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/

    int j=k;

    data[j] = stat_avg[i].vintert;           j++; 
    data[j] = stat_avg[i].vintrat;           j++;
    data[j] = stat_avg[i].kin_harm;          j++;
    data[j] = stat_avg[i].cp_ehart;          j++;
    data[j] = stat_avg[i].cp_eext;           j++;
    data[j] = stat_avg[i].cp_exc;            j++;
    data[j] = stat_avg[i].cp_eke;            j++;
    data[j] = stat_avg[i].cp_enl;            j++;
    data[j] = stat_avg[i].kinet_nhc_bead;    j++;
    data[j] = stat_avg[i].kinet_cp;          j++;
    data[j] = stat_avg[i].kinet_nhc_cp;      j++;
    data[j] = stat_avg[i].ds_ree.x;          j++;
    data[j] = stat_avg[i].ds_rgyr.x;         j++;
    data[j] = stat_avg[i].ds_nh.x;           j++;
    data[j] = (double)stat_avg[i].n_cv;      j++;
    data[j] = (double)stat_avg[i].n_sample;  j++;
    data[j] = (double)stat_avg[i].n_freq;    j++;
    data[j] = (double)stat_avg[i].n_list;    j++;
    data[j] = (double)stat_avg[i].ree_on;    j++;
    data[j] = (double)stat_avg[i].rgyr_on;   j++;
    data[j] = (double)stat_avg[i].nh_on;     j++;
    data[j] = stat_avg[i].ds_ree.x;          j++;
    data[j] = stat_avg[i].ds_rgyr.x;         j++;
    data[j] = stat_avg[i].ds_nh.x;           j++;
     


/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void stat_avg_unpack(double *data, STAT_AVG *stat_avg,int k,int i)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
    int j=k;

    stat_avg[i].vintert        = data[j];     j++; 
    stat_avg[i].vintrat        = data[j];     j++;
    stat_avg[i].kin_harm       = data[j];     j++;
    stat_avg[i].cp_ehart       = data[j];     j++;
    stat_avg[i].cp_eext        = data[j];     j++;
    stat_avg[i].cp_exc         = data[j];     j++;
    stat_avg[i].cp_eke         = data[j];     j++;
    stat_avg[i].cp_enl         = data[j];     j++;
    stat_avg[i].kinet_nhc_bead = data[j];     j++;
    stat_avg[i].kinet_cp       = data[j];     j++;
    stat_avg[i].kinet_nhc_cp   = data[j];     j++;
    stat_avg[i].ds_ree.x       = data[j];     j++;
    stat_avg[i].ds_rgyr.x      = data[j];     j++;
    stat_avg[i].ds_nh.x        = data[j];     j++;
    stat_avg[i].n_cv           = (int)data[j];    j++;
    stat_avg[i].n_sample       = (int)data[j];    j++;
    stat_avg[i].n_freq         = (int)data[j];    j++;
    stat_avg[i].n_list         = (int)data[j];    j++;
    stat_avg[i].ree_on         = (int)data[j];    j++;
    stat_avg[i].rgyr_on        = (int)data[j];    j++;
    stat_avg[i].nh_on          = (int)data[j];    j++;
    stat_avg[i].ds_ree.x       = data[j];         j++;
    stat_avg[i].ds_rgyr.x      = data[j];         j++;
    stat_avg[i].ds_nh.x        = data[j];         j++;


/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/



/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void cv_freq_pack(STAT_AVG *stat_avg,int j, int i)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/

    struct DAFED_FREQ *dafed_freq;
    int k = 1; 


/*==========================================================================*/

    stat_avg[i].freq_x_send = (double *)cmalloc(stat_avg[i].n_freq*sizeof(double))-1;
    stat_avg[i].freq_send   = (int *)cmalloc(stat_avg[i].n_freq*sizeof(int))-1;
    stat_avg[j].freq_x_recv = (double *)cmalloc(stat_avg[j].n_freq*sizeof(double))-1;
    stat_avg[j].freq_recv   = (int *)cmalloc(stat_avg[j].n_freq*sizeof(int))-1;
    
    if(stat_avg[i].ree_on>=1){dafed_freq = stat_avg[i].Ree_freq;}
    if(stat_avg[i].rgyr_on>=1){dafed_freq = stat_avg[i].Rgyr_freq;}
    if(stat_avg[i].nh_on>=1){dafed_freq = stat_avg[i].NH_freq;}

    while(dafed_freq->right!=NULL){
         stat_avg[i].freq_x_send[k] = dafed_freq->x;
         stat_avg[i].freq_send[k] = dafed_freq->freq;
         dafed_freq = dafed_freq->right;
         k++;
    }
    stat_avg[i].freq_x_send[k] = dafed_freq->x;
    stat_avg[i].freq_send[k] = dafed_freq->freq;

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void cv_freq_unpack(STAT_AVG *stat_avg,int j, int i)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/

    struct DAFED_FREQ *dafed_freq,*dafed_freq_back;
    int k = 1;
    int ree_on  = stat_avg[j].ree_on;
    int rgyr_on = stat_avg[j].rgyr_on;
    int nh_on   = stat_avg[j].nh_on;
    int n_freq;
    int test_sum = 0; 

/*==========================================================================*/


    if(ree_on>0&&rgyr_on==0&&nh_on==0){
      stat_avg[j].Ree_freq = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
      dafed_freq = stat_avg[j].Ree_freq;
    }
    if(ree_on==0&&rgyr_on>0&&nh_on==0){
      stat_avg[j].Rgyr_freq = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
      dafed_freq = stat_avg[j].Rgyr_freq;
    }
    if(ree_on==0&&rgyr_on==0&&nh_on>0){
      stat_avg[j].NH_freq = (struct DAFED_FREQ *)cmalloc(sizeof(struct DAFED_FREQ));
      dafed_freq = stat_avg[j].NH_freq;
    }
    
    n_freq = stat_avg[j].n_freq;
    for(k=1;k<=n_freq;k++){
       dafed_freq->x = stat_avg[j].freq_x_recv[k];
       dafed_freq->freq = stat_avg[j].freq_recv[k];
       test_sum += dafed_freq->freq;
     //  printf("x:%lg,freq:%i\n",dafed_freq->x,dafed_freq->freq);
       if(k<=n_freq-1){
          dafed_freq->right = (struct DAFED_FREQ*)cmalloc(sizeof(struct DAFED_FREQ));
          dafed_freq_back = dafed_freq;
          dafed_freq = dafed_freq->right;
          dafed_freq->left = dafed_freq_back;
       }/*endif*/
     }/*endfor*/
     printf("after unpack %lg,%i,%i\n",dafed_freq->x,dafed_freq->freq,test_sum);
     /*n_freq = stat_avg[j].n_freq;*/
     cfree(&(stat_avg[j].freq_x_recv[1]));
     cfree(&(stat_avg[j].freq_recv[1]));
     cfree(&(stat_avg[i].freq_x_send[1]));
     cfree(&(stat_avg[i].freq_send[1]));
       

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/



/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void switch_communicate_atoms(int natm,int pimd_on, int npara_temps_proc,
                              int pi_beads_proc,CLATOMS_POS *clatoms_pos, 
                              MPI_Comm comm,int myid,int np,int myid_m, 
                              int myid_bead, int myid_forc)

/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

  int i,iii;
  int ip,ipt,jpt;
  int myid_up,myid_dn;
  int myid_up_st,myid_dn_st;
  int myid_up_rt,myid_dn_rt;

  int nsend1,nsend2,npt;
  double *chunk_send1, *chunk_recv1; /* this depends on the cool malloc */
  double *chunk_send2, *chunk_recv2; /* in mall_coords                  */
  double *x_ipt,*x_jpt;

  MPI_Request req_up_send1,req_up_send2;
  MPI_Request req_dn_recv1,req_dn_recv2;
  MPI_Request req_dn_send1,req_dn_send2;
  MPI_Request req_up_recv1,req_up_recv2;

  MPI_Status stat_up_send1,stat_up_send2;
  MPI_Status stat_dn_recv1,stat_dn_recv2;
  MPI_Status stat_dn_send1,stat_dn_send2;
  MPI_Status stat_up_recv1,stat_up_recv2;

/*==========================================================================*/
/*  "Up" and "Down" myids and constants                                     */

  fetch_updn_id(np,myid,&myid_up,&myid_dn,&myid_up_st,&myid_dn_st,
                                 &myid_dn_rt,&myid_up_rt);
#ifdef DEBUG_RAPH_PAR
  printf("comm_switch1: myid_m=%d myid=%d myid_up=%d myid_dn=%d np=%d\n",
          myid_m,myid,myid_up,myid_dn,np);
#endif
  nsend1 = natm*9+2;
  nsend2 = natm*9;

  npt    = npara_temps_proc; /* short and sweet */

/*==========================================================================*/
/* The up-send and dn-receive */

  for(ip=1;ip<=pi_beads_proc;ip++){
    ipt = ip + (npt-1)*pi_beads_proc; /* up send */
    jpt = ip - pi_beads_proc;             /* dn recv */

    /* positions, velocities forces */
    x_ipt                 = clatoms_pos[ipt].x;
    x_jpt                 = clatoms_pos[jpt].x;
    chunk_send1           = &(x_ipt[1]);
    chunk_recv1           = &(x_jpt[1]);
    chunk_send1[nsend1-2] = (double)(clatoms_pos[ipt].origin);
    chunk_send1[nsend1-1] = (double)(clatoms_pos[ipt].idirect);

    Barrier(comm);
      ISend(chunk_send1,nsend1,MPI_DOUBLE,myid_up,myid_up_st,comm,&req_up_send1);
      IRecv(chunk_recv1,nsend1,MPI_DOUBLE,myid_dn,myid_dn_rt,comm,&req_dn_recv1);
    Barrier(comm);
    myid_up_st += 2*np;
    myid_dn_rt += 2*np;

    if(pimd_on==1){
      /* mode positions,forces */
      x_ipt        = clatoms_pos[ipt].fxt;
      x_jpt        = clatoms_pos[jpt].fxt;
      chunk_send2  = &(x_ipt[1]);
      chunk_recv2  = &(x_jpt[1]);
      Barrier(comm);
        ISend(chunk_send2,nsend2,MPI_DOUBLE,myid_up,myid_up_st,comm,&req_up_send2);
        IRecv(chunk_recv2,nsend2,MPI_DOUBLE,myid_dn,myid_dn_rt,comm,&req_dn_recv2);
      Barrier(comm);
      myid_up_st += 2*np;
      myid_dn_rt += 2*np;
    }/*endif*/

    /* Call Waiting */
    Wait(&req_up_send1,&stat_up_send1);
    Wait(&req_dn_recv1,&stat_dn_recv1);
    if(pimd_on==1){
       Wait(&req_up_send2,&stat_up_send2);
       Wait(&req_dn_recv2,&stat_dn_recv2);
    }/*endif*/
    (clatoms_pos[jpt].origin)  = (int)(chunk_recv1[nsend1-2]);
    (clatoms_pos[jpt].idirect) = (int)(chunk_recv1[nsend1-1]);
#ifdef DEBUG_RAPH_PAR
    if(ip==1){
      printf("comm_switch2: myid_m=%d myid=%d myid_dn_recv %d myid_bead %d\n",
              myid_m,myid,((int)(chunk_recv1[nsend1-1])),myid_bead);
    }/*endif*/
#endif
  }/*endfor : ip*/

/*==========================================================================*/
/* The dn-send and up-receive */

  for(ip=1;ip<=pi_beads_proc;ip++){
    ipt = ip + npt*pi_beads_proc;  /* dn recv */
    jpt = ip;                      /* dn send */

    /* positions, velocities forces */
    x_ipt                 = clatoms_pos[ipt].x;
    x_jpt                 = clatoms_pos[jpt].x;
    chunk_recv1           = &(x_ipt[1]);
    chunk_send1           = &(x_jpt[1]);
    chunk_send1[nsend1-2] = (double)(clatoms_pos[jpt].origin);
    chunk_send1[nsend1-1] = (double)(clatoms_pos[jpt].idirect);
    Barrier(comm);
      ISend(chunk_send1,nsend1,MPI_DOUBLE,myid_dn,myid_dn_st,comm,&req_dn_send1);
      IRecv(chunk_recv1,nsend1,MPI_DOUBLE,myid_up,myid_up_rt,comm,&req_up_recv1);
    Barrier(comm);
    myid_dn_st += 2*np;
    myid_up_rt += 2*np;

    if(pimd_on==1){
       /* mode positions, velocities forces */
       x_ipt = clatoms_pos[ipt].fxt;
       x_jpt = clatoms_pos[jpt].fxt;
       chunk_recv2 = &(x_ipt[1]);
       chunk_send2 = &(x_jpt[1]);
       Barrier(comm);
         ISend(chunk_send2,nsend2,MPI_DOUBLE,myid_dn,myid_dn_st,comm,&req_dn_send2);
         IRecv(chunk_recv2,nsend2,MPI_DOUBLE,myid_up,myid_up_rt,comm,&req_up_recv2);
       Barrier(comm);
       myid_dn_st += 2*np;
       myid_up_rt += 2*np;
    }/*endif*/

    /* Call Waiting */
    Wait(&req_dn_send1,&stat_dn_send1);
    Wait(&req_up_recv1,&stat_up_recv1);
    if(pimd_on==1){
      Wait(&req_dn_send2,&stat_dn_send2);
      Wait(&req_up_recv2,&stat_up_recv2);
    }/*endif*/
    (clatoms_pos[ipt].origin)  =  (int)(chunk_recv1[nsend1-2]);
    (clatoms_pos[ipt].idirect) =  (int)(chunk_recv1[nsend1-1]);
  }/*endfor : ip*/

/*--------------------------------------------------------------------------*/
   }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void switch_communicate_states()
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/
#include "../typ_defs/typ_mask.h"

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void fetch_updn_id(int np,int myid,int *myid_up,int *myid_dn,
                   int *myid_up_st,int *myid_dn_st,
                   int *myid_dn_rt,int *myid_up_rt)
/*==========================================================================*/
   {/*begin routine */
/*==========================================================================*/

   /* up/dn ids using PBC */
   myid_up[0] = (myid+1); if(myid_up[0]==np){myid_up[0] = 0;     }
   myid_dn[0] = (myid-1); if(myid_dn[0]==-1){myid_dn[0] = (np-1);}

   /* up/dn send tags */
   myid_up_st[0] = myid_up[0]+np;
   myid_dn_st[0] = myid_dn[0]+2*np;

   /* up/dn recv tags */
   myid_dn_rt[0] = myid+np;
   myid_up_rt[0] = myid+2*np;

/*--------------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/
