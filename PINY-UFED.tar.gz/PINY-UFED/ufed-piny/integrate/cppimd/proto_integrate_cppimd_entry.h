/*--------------------------------------------------------------------------*/
/* /cppimd/int_NVT_cp_pimd.c */

void int_NVT_cp_pimd(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cppimd/int_NPTI_cp_pimd.c */

void int_NPTI_cp_pimd(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cppimd/int_NPTF_cp_pimd.c */
void int_NPTF_cp_pimd(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
