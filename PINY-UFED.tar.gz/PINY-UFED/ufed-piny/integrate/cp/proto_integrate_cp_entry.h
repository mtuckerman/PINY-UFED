/*--------------------------------------------------------------------------*/
/* /cp/int_NVE_cp.c */

void int_NVE_cp(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cp/int_NVE_res.c */

void int_NVE_cp_res(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cp/int_NVT.c */

void int_NVT_cp(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cp/int_NVT_res.c */

void int_NVT_cp_res(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cp/int_NPTI.c */

void int_NPTI_cp(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cp/int_NPTI_res.c */

void int_NPTI_cp_res(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cp/int_NPTF.c */

void int_NPTF_cp(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
/* /cp/int_NPTF_res.c */

void int_NPTF_cp_res(CLASS *,BONDED *,GENERAL_DATA *,CP *,int );

/*--------------------------------------------------------------------------*/
