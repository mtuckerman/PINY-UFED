/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: check for NaN's                              */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"

void check_for_NaN(int,int,double*,double*,double*,char*,GENERAL_DATA*,CLASS*);

/*========================================================================*/
void check_for_NaN(int n, int ipt, double* x, double* y, double* z, char* s, 
                    GENERAL_DATA* general_data,CLASS *class)
/*========================================================================*/
  {/*begin routine*/
/*-----------------------------------------------------------------------*/
  int itime           = general_data->timeinfo.itime;
  int npara_temps     = general_data->tempering_ctrl.npara_temps;
  int ioff_pt         = general_data->tempering_ctrl.npara_temps_proc_off;
  int np_master       = class->communicate_m.np;
  int myid_temper     = class->communicate_m.myid_temper;
  int myid_master     = class->communicate_m.myid;
  int np_beads        = class->communicate.np_beads;
  int np_states       = class->communicate.np_states;
  int np_tot          = class->communicate.np;
  int np_forc         = class->communicate.np_forc;
  int myid            = class->communicate.myid_forc;
  int myid_state      = class->communicate.myid_state;
  int myid_bead       = class->communicate.myid_bead;
  int myid_ctrl       = class->communicate.myid;
  int i;
/*-----------------------------------------------------------------------*/
        for(i=1;i<=n;i++){
	  if(isnan(x[i]) !=0 || isnan(y[i])!=0||isnan(z[i])!=0 || 
             finite(x[i])==0 || finite(y[i])==0|| finite(z[i])==0){
 	    printf("position of NaN check in MD loop: %s\n",s);
	    printf("I'm proc %d of %d on step %d with temperer %d %d %d\n",
	    myid_master,np_master,itime,ipt+ioff_pt,ipt,ioff_pt);
            printf("sub id's:np_beads,np_tot,np_forc,myid,myid_forc,myid_bead\n");    
            printf("        : %d      %d     %d      %d   %d     %d\n",
		   np_beads,np_tot,np_forc,myid_ctrl,myid,myid_bead);
            fflush(stdout);
            if(np_tot>1){Finalize();}
	    exit(1);
          }/*endif*/
        }/*endfor : i*/

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/
