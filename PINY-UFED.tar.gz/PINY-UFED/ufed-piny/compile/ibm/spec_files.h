SPEC_FILES = math_rs.o
# SPEC_FILES = math_generic.o

