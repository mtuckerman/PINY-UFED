# user specific directories
#--------------------------
ROOT   = /home/mingchen/code/Piny_bias_nCV_ver4.7_hdiminterp
CODE   = $(ROOT)
DCODE  = $(ROOT)
ECODE  = $(ROOT)/runable

# general directories
#--------------------------
INCLUDES = $(DCODE)/include/pentium
EXE      = $(ECODE)/piny_partemp_pent.x

# HP compiler
#--------------------------
FC       =/usr/local/bin/mpif77 -fc=ifort
CC       =/usr/local/bin/mpicc -cc=icc
OPT      = -O2 -xHost -vec-report1
OPT_CARE = -O2 -xHost -vec-report1
OPT_GRP  = -O2 -xHost -vec-report1
#OPT       = -g
#OPT_CARE  = -g
#OPT_GRP   = -g
CFLAGS   = 
FFLAGS   = -nofor_main
LIBS     = $(LIB_PATH) $(MALLOC) 
           
           


