#SPEC_FILES = 
SPEC_FILES = math_generic.o

