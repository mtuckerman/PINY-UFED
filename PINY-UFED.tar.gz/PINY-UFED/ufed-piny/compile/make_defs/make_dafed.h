#=================================================================
#              MAIN_FILES 
#=================================================================


#=================================================================
control_dafed.o :        $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_LOC) $(DAFED_ENT) $(DAFED_HELP) \
                         $(DAFED_BIAS) \
                         $(DCODE)/dafed/control_dafed.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/dafed/control_dafed.c

integrate_dafed.o :      $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_LOC) $(DAFED_ENT) $(DAFED_HELP) $(DAFED_INT) \
                         $(DAFED_IO) $(DAFED_ENERGY) \
                         $(DCODE)/dafed/integrate_dafed.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/dafed/integrate_dafed.c


dafed_io.o :             $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_HELP) $(DAFED_IO) \
                         $(DCODE)/dafed/dafed_io.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/dafed/dafed_io.c

bias_update.o :          $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_LOC) $(DAFED_ENT) $(DAFED_HELP) $(DAFED_INT) \
                         $(DAFED_IO) $(DAFED_ENERGY) \
                         $(DCODE)/dafed/bias_update.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/dafed/bias_update.c

helper_dafed.o :         $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_LOC) $(DAFED_ENT) $(DAFED_HELP) \
                         $(DCODE)/dafed/helper_dafed.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/dafed/helper_dafed.c

energy_control_dafed.o : $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/control/energy_control_dafed.c
	$(ECHO)	$@
	$(COBJ)	$(DCODE)/energy/control/energy_control_dafed.c
track_collective_variables.o : $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) $(DAFED_IO) \
                         $(DCODE)/energy/control/track_collective_variables.c
	$(ECHO)	$@
	$(COBJ)	$(DCODE)/energy/control/track_collective_variables.c
                         
force_Ree.o :            $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/dafed/force_Ree.c
	$(ECHO)	$@
	$(COBJ)	$(DCODE)/energy/dafed/force_Ree.c
                         
force_Rgyr.o :            $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/dafed/force_Rgyr.c
	$(ECHO)	$@
	$(COBJ)	$(DCODE)/energy/dafed/force_Rgyr.c
                         
force_NH.o :            $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/dafed/force_NH.c
	$(ECHO)	$@
	$(COBJ)	$(DCODE)/energy/dafed/force_NH.c

force_Phi.o :            $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/dafed/force_Phi.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/energy/dafed/force_Phi.c

force_BBDih.o :          $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/dafed/force_BBDih.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/energy/dafed/force_BBDih.c

force_bias.o :           $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/dafed/force_bias.c
	$(ECHO) $@
	$(COBJ) $(DCODE)/energy/dafed/force_bias.c

                         
force_dafed_final.o :            $(STANDARD) $(DEFINES) \
                         $(TYP_CLASS) $(TYP_BND) $(TYP_GEN) \
                         $(TYP_STAT) \
                         $(TYP_CP) $(TYP_PAR) \
                         $(COMM_WRAP) $(COMM_ENT) \
                         $(DAFED_ENERGY) $(DAFED_HELP) \
                         $(DCODE)/energy/dafed/force_dafed_final.c
	$(ECHO)	$@
	$(COBJ)	$(DCODE)/energy/dafed/force_dafed_final.c
                         
#------------------------------------------------------------------
