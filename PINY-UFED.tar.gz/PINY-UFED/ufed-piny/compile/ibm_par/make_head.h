#===========================================================================
#ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
#===========================================================================
#
#  Machine specific compilation information
#
#===========================================================================
#ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
#===========================================================================

#============================
# user specific directories
#============================
ROOT   = /u/gmartyna/RAPH/PAR_TEMP
CODE   = $(ROOT)/V4.0
DCODE  = $(ROOT)/V4.0
ECODE  = $(DCODE)/runable

#============================
# general directories
#============================
INCLUDES = $(CODE)/include/ibm_par
EXE      = $(ECODE)/pi_ptmd_ibm.e
CMALLOC  = 

#============================
# IBM compiler 
#============================
FC     = mpxlf -g
CC     = mpcc  -g
CFLAGS =
FFLAGS =
# IF you need to allocate > 256 Mbytes of real memory you need the flags below 
#   these flags are for  2 gigabyte allocation
#   see man pages for xlf 
CFLAGS = -bmaxdata:0x80000000 -bmaxstack:0x10000000  
FFLAGS = -bmaxdata:0x80000000 -bmaxstack:0x10000000  
LIBS   = -lm  -lessl
#----------------------------
#  Low Opt
#----------------------------
OPT      = -O2 -qmaxmem=-1
OPT_CARE = -O2 -qmaxmem=-1
OPT_GRP  = -O2 -qmaxmem=-1
#----------------------------
#  Full Opt
#----------------------------
#OPT      = -O3 -qstrict -qarch=pwr2 -qmaxmem=-1
#OPT_CARE = -O3 -qstrict -qarch=pwr2 -qmaxmem=-1
#OPT_GRP  = -O3 -qstrict -qarch=pwr2 -qmaxmem=-1
#----------------------------
#  NOTE : 
#  If you are compiling for an IBM RISC workstation, 
#  take off the -qarch=pwr2 flag, since that is 
#  special for the SP2.
#============================

