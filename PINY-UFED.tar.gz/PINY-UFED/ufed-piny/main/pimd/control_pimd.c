/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: control_md                                   */
/*                                                                          */
/* This subprogram performs Path Integral MD on a classical potential energy*/ 
/*                             surface (PES)                                */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_main_local.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_integrate_pimd_entry.h"
#include "../proto_defs/proto_integrate_pimd_local.h"
#include "../proto_defs/proto_integrate_md_entry.h"
#include "../proto_defs/proto_output_entry.h"
#include "../proto_defs/proto_analysis_md_entry.h"
#include "../proto_defs/proto_vel_sampl_class_entry.h"
#include "../proto_defs/proto_energy_ctrl_entry.h"
#include "../proto_defs/proto_pimd_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_temper_md.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void control_pimd(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                  ANALYSIS *analysis)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/

#include "../typ_defs/typ_mask.h"

/*=======================================================================*/
/*            Local variable declarations                                */
  int ipt;
  int toggle =1;

  int itime,iii,nver_temp=0;        
  int ntime           = general_data->timeinfo.ntime;
  int pt_time       = general_data->tempering_ctrl.switch_steps;
  int error_check_on  = general_data->error_check_on;
  int npara_temps     = general_data->simopts.npara_temps;
  int npara_temps_proc= general_data->simopts.npara_temps_proc;

  int num_proc        = class->communicate.np;
  int np_beads        = class->communicate.np_beads;
  int np_forc         = class->communicate.np_forc;
  int myid_forc       = class->communicate.myid_forc;
  int myid            = class->communicate.myid;
  int myid_temper     = class->communicate.myid_temper;
  MPI_Comm comm_beads = class->communicate.comm_beads;
  MPI_Comm comm_forc  = class->communicate.comm_forc;
  MPI_Comm world      = class->communicate.world;

  int num_proc_m      = class->communicate_m.np;
  int myid_m          = class->communicate_m.myid;
  MPI_Comm world_m    = class->communicate_m.world;

  int jjj1,jjj2;
/*=======================================================================*/
/* 0) Preliminary MD stuff                                               */

  for(ipt=1;ipt<=npara_temps_proc;ipt++){
    prelim_pimd(class,bonded,general_data,ipt);
    general_data->stat_avg[ipt].updates = 0.0;
  }/*endfor ipt*/
  if(num_proc>1){Barrier(world_m);}

/*======================================================================*/
/* I) Write to Screen                                                   */

if(myid_m==0 && error_check_on==1){
  PRINT_LINE_STAR;
  printf("Running PIMD \n");
  PRINT_LINE_DASH;
}/*endif for error check on*/
/*======================================================================*/
/* II) Loop over the specified number of time steps */

  (class->energy_ctrl.itime)     = 0; /* Always get the total PE */

  for(itime = 1; itime<=ntime; itime++){
/*----------------------------------------------------------------------*/
   (general_data->timeinfo.itime) = itime;
   for(ipt = 1;ipt<=npara_temps_proc;ipt++){
    cputime(&(general_data->stat_avg[ipt].cpu1)); 
  /*----------------------------------------------------------------------*/
  /*   1)Do NVT dynamics:                                                 */
    if((general_data->ensopts.nvt)==1){
       int_NVT_pimd(class,bonded,general_data,analysis,ipt);
    }/*endif*/

    Barrier(world_m);
  /*---------------------------------------------------------------------*/
  /*   2)Do isotropic npt dynamics:                                      */
    if((general_data->ensopts.npt_i)==1){
       int_NPTI_pimd(class,bonded,general_data,analysis,ipt);
    }/*endif*/

  /*---------------------------------------------------------------------*/
  /*   3)Do flexible npt dynamics:                                       */
    if((general_data->ensopts.npt_f)==1){
       int_NPTF_pimd(class,bonded,general_data,analysis,ipt);
    }/*endif*/
  /*----------------------------------------------------------------------*/
  /*   4)Do nst dynamics:                                                 */

  /*---------------------------------------------------------------------*/
  /*  4.5) Analysis Routine                                               */
#ifdef JUNK
    analysis_pimd(class,general_data,bonded,analysis); 
#endif
  /*----------------------------------------------------------------------*/
  /*   5)Calculate some simple averages                                   */
    cputime(&(general_data->stat_avg[ipt].cpu2)); 
    (general_data->stat_avg[ipt].cpu_now)=(general_data->stat_avg[ipt].cpu2)-
                                     (general_data->stat_avg[ipt].cpu1);
    (general_data->stat_avg[ipt].acpu) += (general_data->stat_avg[ipt].cpu2)-
                                     (general_data->stat_avg[ipt].cpu1);

    simpavg_pimd(&(general_data->timeinfo),&(general_data->stat_avg[ipt]),
	         &(general_data->cell),&(bonded->constrnt),
	         &(general_data->ensopts),&(general_data->simopts),
	         &(general_data->ptens[ipt]),&(class->communicate));
  /*-----------------------------------------------------------------------*/
  /*   7)Produce the output specified by the user                          */

    if(np_forc>1){
      Reduce(&(class->nbr_list.verlist[ipt].nver_lst_now), 
	     &nver_temp,1,MPI_INT,
	     MPI_SUM,0,comm_forc);
      class->nbr_list.verlist[ipt].nver_lst_now = nver_temp;     
    }

/*=======================================================================*/
/* I) All gather velocities if necessary */ 

   if(np_forc>1){
    if(((general_data->timeinfo.itime%general_data->filenames.iwrite_confv)==0)||
      ((general_data->timeinfo.itime%general_data->filenames.iwrite_dump)==0)){
     forc_level_vel_gather(class,general_data,ipt);
    }/*endif*/
   }/*endif*/


    if(myid_m == 0){check_auto_exit(&(general_data->timeinfo.exit_flag));}
    if(num_proc > 1){Bcast(&(general_data->timeinfo.exit_flag),1,MPI_INT,0,world_m);}

    if(  (itime % (general_data->filenames.iwrite_screen))==0 ||
         (itime % (general_data->filenames.iwrite_dump  ))==0 ||
         (itime % (general_data->filenames.iwrite_confp ))==0 ||
         (itime % (general_data->filenames.iwrite_confv)) ==0 ||
         (itime % (general_data->filenames.iwrite_inst))  ==0 ||
         (general_data->timeinfo.exit_flag == 1)       ){
         (general_data->filenames.ifile_open) = 0;
         if(np_beads>1&&myid_forc==0){
           communicate_output_pimd(class,ipt);
	 }/*endif*/
         if(myid==0){
           output_pimd(class,general_data,bonded,ipt);
	 }/*endif : error_check_on*/
    }/*endif*/

  /*---------------------------------------------------------------------*/
  /*   8)Resample the particle velocities if desired                     */
    if(((class->vel_samp_class.ivel_smpl_on)==1) &&
       ((class->vel_samp_class.nvx_smpl)!=0)){
      if((itime % (class->vel_samp_class.nvx_smpl))==0){
	control_vx_smpl(class,bonded,&(general_data->ensopts),
			&(general_data->simopts),general_data,
                          general_data->error_check_on,ipt,1);
      }/*endif*/
    }/*endif*/
  /*---------------------------------------------------------------------*/
  /*   9) Resample the extended class velocities if desired             */
    if(((class->vel_samp_class.ivel_smpl_on)==1) &&
       ((class->vel_samp_class.nvnhc_smpl)!=0)){
      if((itime % (class->vel_samp_class.nvnhc_smpl))==0){
	control_vnhc_smpl(class,general_data,ipt,1);
      }/*endif*/
    }/*endif*/

  /*---------------------------------------------------------------------*/
   }/*endfor ipt */
  /*---------------------------------------------------------------------*/
  /*   10) Switch me baby                                                */

#ifdef JUNK
   if(num_proc_m>1){
     iii=itime;
     Barrier(world_m);

     Allreduce(&iii,&jjj1, 1, MPI_INT, MPI_MIN,0, world_m);
     Barrier(world_m);

     Allreduce(&iii,&jjj2, 1, MPI_INT, MPI_MAX,0, world_m);
     Barrier(world_m);

     if(jjj1!=jjj2){
       printf("I (%d) am toast! on step %d %d %d\n",myid_m,itime,jjj1,jjj2);
       Finalize();exit(1);
     }
   }
#endif

   if(npara_temps>1){
     if(itime%general_data->filenames.iwrite_confp==0){
       compute_wgt_frenkel(class,general_data,"pimd");
     }

     if(itime%pt_time==0){
       md_switch_pt(class,bonded,general_data,toggle,"pimd");
       /*switch between even and odd config swapping*/
       if(toggle==1){toggle=2;}else{toggle=1;}
     }/*endif time to switch*/
   }/*endif npara_temps>1*/

  /*---------------------------------------------------------------------*/
  /*   11) Check for exit condition                                      */


   if(general_data->timeinfo.exit_flag == 1) {
      itime = ntime;
      if(np_beads > 1) Barrier(world_m);
   }/* endif */

  }/*endfor:itime */


  /*======================================================================*/
  /*  III)Write to Screen                                                 */

  if(ipt==npara_temps_proc){
    if(myid_m==0){
      PRINT_LINE_DASH;
      printf("Completed PIMD run \n");
      PRINT_LINE_STAR;
    }/*endif*/
  }/*endif for error check on*/

/*-----------------------------------------------------------------------*/
}/*end routine*/
/*==========================================================================*/





/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void prelim_pimd(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,int ipt)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/

#include "../typ_defs/typ_mask.h"

/*=======================================================================*/
/*            Local variable declarations                                */
  /*  int ipt=1;*/

  int i,j,iflag,ip,iflag_mass,iii,ipp;        
  int itemper_off,itemper_off1;
  int pi_beads = class->clatoms_info.pi_beads;
  int pi_beads_proc = class->clatoms_info.pi_beads_proc;
  int pi_beads_proc_st = class->clatoms_info.pi_beads_proc_st;
  int rank      = class->communicate.myid_bead;
  int myid_forc = class->communicate.myid_forc;
  int error_check_on = general_data->error_check_on;
  int nver_temp = 0;
  int mytherm_start     = class->therm_info_class[ipt].mytherm_start;
  int mytherm_end       = class->therm_info_class[ipt].mytherm_end;
  double kinet_temp=0.0;
  double vintrat_temp=0.0;
  double vintert_temp=0.0;
  double vvdw_temp = 0.0; /*DY*/
  double vcoul_temp = 0.0; /*DY*/
  double kinet_nhc_temp=0.0;
  double kinet_nhc_bead_temp=0.0;
  double vbondt_temp=0.0;
  double vbendt_temp=0.0;
  double vbend_bnd_bond_temp=0.0;
  double vbend_bnd_bend_temp=0.0;
  double vtorst_temp=0.0;
  double vonfot_temp = 0.0;
  double pi_ke_prim_temp = 0.0;
  double pi_ke_vir_temp = 0.0;
  double kin_harm_temp = 0.0;
  int start_proc;

  int npara_temps     = general_data->simopts.npara_temps;
  int npara_temps_proc = general_data->simopts.npara_temps_proc;
  int iptoff           = general_data->simopts.npara_temps_proc_off+ipt;
  int istart           = general_data->filenames.istart;
  int ipt_restart      = general_data->filenames.ipt_restart;

  int myid_m          = class->communicate_m.myid;
  int num_proc        = class->communicate.np;
  int num_proc_beads  = class->communicate.np_beads;
  int np_forc         = class->communicate.np_forc;
  MPI_Comm comm_forc  = class->communicate.comm_forc;
  MPI_Comm comm_beads = class->communicate.comm_beads;
  MPI_Comm world      = class->communicate.world;

  start_proc = (pi_beads_proc_st == 1 ? 2:1);


/*=======================================================================*/
/*   I) Write to Screen                                                  */

  if(iptoff==1){
    if(myid_m==0){
      PRINT_LINE_STAR;
      printf("Performing preliminary tasks for pimd \n");
      PRINT_LINE_DASH;printf("\n");
    }/*endif*/
  }/*endif*/

/*=======================================================================*/
/*  II) Initialize In-output                                             */

  general_data->stat_avg[ipt].updates   = 0.0;
  general_data->stat_avg[ipt].acpu      = 0.0;

/*=======================================================================*/
/* III)Get Energy and particle Forces                                    */

  if(iptoff==1){
   if(error_check_on==1){
    printf("Getting initial energy\n");
   }/*endif*/
  }/*endif*/
 
  (general_data->timeinfo.itime) = 0;
  (class->energy_ctrl.itime)     = 0;
  class->energy_ctrl.iget_full_inter = 1;
  class->energy_ctrl.iget_res_inter  = 0;
  if(general_data->timeinfo.int_res_ter==1){
    class->energy_ctrl.iget_res_inter=1;
  }
  class->energy_ctrl.iget_full_intra = 1;
  class->energy_ctrl.iget_res_intra  = 0;
  if((general_data->timeinfo.int_res_tra)==1){
    class->energy_ctrl.iget_res_intra=1;
  }

  class->clatoms_info.wght_pimd = 1;

    control_pimd_trans_mode(class,general_data,ipt);
    mode_energy_control(class,general_data,ipt);
    control_pimd_trans_pos(class,general_data,ipt);

  energy_control_pimd(class,bonded,general_data,ipt);

  get_tvten_pimd(class,general_data,ipt);

  itemper_off  = (ipt-1)*pi_beads_proc;
  itemper_off1 = (ipt-1)*pi_beads_proc+1;

  if(iptoff==npara_temps_proc){
   if(myid_m==0){
     printf("Completed initial energy\n");
   }/*endif*/
  }/*endif*/

/*=======================================================================*/
/* IV)Get NHC Forces                                                     */

  if((general_data->ensopts.nvt)==1){
     iflag_mass = 1;
     if(class->clatoms_info.pi_beads_proc_st==1){
       init_NHC_par(&(class->clatoms_info),&(class->clatoms_pos[itemper_off1]),
              &(class->therm_info_class[ipt]),&(class->therm_class[ipt]),
              &(class->int_scr),iflag_mass,&(class->class_comm_forc_pkg));
     }/*endif*/
     iflag_mass = 2;
     for(ipp=start_proc;ipp<=pi_beads_proc;ipp++){
      ip = itemper_off + ipp;
      init_NHC_par(&(class->clatoms_info),&(class->clatoms_pos[ip]),
                    &(class->therm_info_bead[ipt]),&(class->therm_bead[ip]),
                    &(class->int_scr),iflag_mass,&(class->class_comm_forc_pkg));
     }/*endfor*/
    iflag = 0;
    nhc_vol_potkin_pimd(class,general_data,iflag,ipt);
  }/*endif*/

  if((general_data->ensopts.npt_i)==1){
     if(class->clatoms_info.pi_beads_proc_st==1){
       init_NHCPI_par(&(class->clatoms_info),&(class->clatoms_pos[itemper_off1]),
                &(class->therm_info_class[ipt]),&(class->therm_class[ipt]),
                &(general_data->baro),
                &(class->int_scr),&(class->class_comm_forc_pkg));
     }/*endif*/
     iflag_mass = 2;
     for(ipp=start_proc;ipp<=pi_beads_proc;ipp++){
      ip = itemper_off + ipp;
      init_NHC_par(&(class->clatoms_info),&(class->clatoms_pos[ip]),
                    &(class->therm_info_bead[ipt]),&(class->therm_bead[ip]),
                    &(class->int_scr),iflag_mass,&(class->class_comm_forc_pkg));
     }/*endfor*/
    iflag = 1;
    nhc_vol_potkin_pimd(class,general_data,iflag,ipt);
  }/*endif*/

  if((general_data->ensopts.npt_f)==1){
     if(class->clatoms_info.pi_beads_proc_st==1){
       init_NHCPF_par(&(class->clatoms_info),&(class->clatoms_pos[itemper_off1]),
                &(class->therm_info_class[ipt]),&(class->therm_class[ipt]),
                &(general_data->baro),
                &(general_data->par_rahman),&(general_data->cell),
                &(class->int_scr),&(class->class_comm_forc_pkg));
     }/*endif*/
     iflag_mass = 2;
     for(ipp=start_proc;ipp<=pi_beads_proc;ipp++){
      ip = itemper_off + ipp;
      init_NHC_par(&(class->clatoms_info),&(class->clatoms_pos[ip]),
                   &(class->therm_info_bead[ipt]),&(class->therm_bead[ip]),
                   &(class->int_scr),iflag_mass,&(class->class_comm_forc_pkg));
     }/*endfor*/
    iflag = 2;
    nhc_vol_potkin_pimd(class,general_data,iflag,ipt);
  }/*endif*/

  if((general_data->ensopts.npt_i+general_data->ensopts.npt_f)==0){
    general_data->stat_avg[ipt].kinet_v       = 0.0;
  }/*endif*/
  if((general_data->ensopts.npt_i+general_data->ensopts.npt_f+
                                  general_data->ensopts.nvt)==0){
    general_data->stat_avg[ipt].kinet_nhc     = 0.0;
  }/*endif*/

/*========================================================================*/
/* VI) Initialize free energy stuff                                       */

  if(bonded->bond_free[ipt].num != 0){
    for(i=1;i<= (bonded->bond_free[ipt].num);i++){
      bonded->bond_free[ipt].hist[i] = 0.0;
    }
  }/*endif*/
  if(bonded->bend_free[ipt].num != 0){
    for(i=1;i<= (bonded->bend_free[ipt].num);i++){
      bonded->bend_free[ipt].hist[i] = 0.0;
    }
  }/*endif*/
  if(bonded->tors_free[ipt].num == 1){
    for(i=1;i<= bonded->tors_free[ipt].num;i++){
      bonded->tors_free[ipt].hist[i] = 0.0;
    }
  }/*endif*/
  if(bonded->tors_free[ipt].num == 2){
    for(i=1;i<= bonded->tors_free[ipt].nhist;i++){
    for(j=1;j<= bonded->tors_free[ipt].nhist;j++){
      bonded->tors_free[ipt].hist_2d[i][j] = 0.0;
    }/*endfor*/
    }/*endfor*/
  }/*endif*/

/*=======================================================================*/
/* IIIb) Initialise PT stuff         */

  general_data->tempering_ctrl.nswitch = 0.0;
  for(ipp=1;ipp<=pi_beads_proc;ipp++){
    ip=(ipt-1)*pi_beads_proc+ipp;
    prelim_paratemp(&(general_data->stat_avg[ipt]),
		    &(class->clatoms_pos[ip]),iptoff,npara_temps,
		    istart,ipt_restart);

  }/*endfor*/


/*=======================================================================*/
/*  IV) Write Energy to screen                                           */
/*=======================================================================*/

  general_data->filenames.ifile_open = 1;

  general_data->timeinfo.itime = 0;
  
  /*=======================================================================*/
  /*  Collect initial energies (needs its own routine)                     */
  /*=======================================================================*/

  general_data->stat_avg[ipt].vol = general_data->cell.vol;
  if(num_proc>1){
    Reduce(&(class->nbr_list.verlist[ipt].nver_lst_now), &nver_temp,1,MPI_INT,
                   MPI_SUM,0,comm_forc);
    Reduce(&(general_data->stat_avg[ipt].vintert), &vintert_temp,1,MPI_DOUBLE,
                   MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vintrat), &vintrat_temp,1,MPI_DOUBLE,
                   MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vvdw), &vvdw_temp,1,MPI_DOUBLE,
                   MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vcoul),&vcoul_temp,1,MPI_DOUBLE,
                   MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].kinet), &kinet_temp,1,MPI_DOUBLE,
                   MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vbondt), &vbondt_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vbendt), &vbendt_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vbend_bnd_bond), &vbend_bnd_bond_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vbend_bnd_bend), &vbend_bnd_bend_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vtorst), &vtorst_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].vonfot), &vonfot_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].pi_ke_vir), &pi_ke_vir_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    Reduce(&(general_data->stat_avg[ipt].kin_harm), &kin_harm_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);

 

    general_data->stat_avg[ipt].kinet          = kinet_temp;
    general_data->stat_avg[ipt].vintert        = vintert_temp;
    general_data->stat_avg[ipt].vintrat        = vintrat_temp;
    general_data->stat_avg[ipt].vvdw           = vvdw_temp;  
    general_data->stat_avg[ipt].vcoul          = vcoul_temp; 
    general_data->stat_avg[ipt].vbondt         = vbondt_temp;
    general_data->stat_avg[ipt].vbendt         = vbendt_temp;
    general_data->stat_avg[ipt].vbend_bnd_bond = vbend_bnd_bond_temp;
    general_data->stat_avg[ipt].vbend_bnd_bend = vbend_bnd_bend_temp;
    general_data->stat_avg[ipt].vtorst         = vtorst_temp;
    general_data->stat_avg[ipt].vonfot         = vonfot_temp;
    general_data->stat_avg[ipt].pi_ke_vir      = pi_ke_vir_temp;
    general_data->stat_avg[ipt].kin_harm       = kin_harm_temp;
    class->nbr_list.verlist[ipt].nver_lst_now  = nver_temp;


    Reduce(&(general_data->stat_avg[ipt].kinet_nhc_bead), &kinet_nhc_bead_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world); 
    general_data->stat_avg[ipt].kinet_nhc_bead = kinet_nhc_bead_temp; 

    Reduce(&(general_data->stat_avg[ipt].kinet_nhc), &kinet_nhc_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,world);
    general_data->stat_avg[ipt].kinet_nhc = kinet_nhc_temp;
 
  }/*endif*/


  if(num_proc_beads>1){
    Reduce(&(general_data->stat_avg[ipt].pi_ke_prim), &pi_ke_prim_temp,1,
                   MPI_DOUBLE,MPI_SUM,0,comm_beads);
    general_data->stat_avg[ipt].pi_ke_prim     = pi_ke_prim_temp;
  }/*endif*/

  if(error_check_on==1){
   output_pimd(class,general_data,bonded,ipt);
  }/*endif*/


/*=======================================================================*/
/*   VII) Write to Screen         */

  if(iptoff==npara_temps_proc){
    if(myid_m==0){
      printf("\n");
      PRINT_LINE_DASH;
      printf("Completed preliminary tasks for pi_md \n");
      PRINT_LINE_STAR;printf("\n");
     }/*endif for error check on*/
  }/*endif*/

/*-----------------------------------------------------------------------*/
   }/*end routine*/
/*==========================================================================*/









