/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: control_md                                   */
/*                                                                          */
/* This subprogram performs MD on a classical potential energy surface (PES)*/
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_stat.h"
#include "../proto_defs/proto_main_local.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_integrate_md_entry.h"
#include "../proto_defs/proto_integrate_md_local.h"
#include "../proto_defs/proto_output_entry.h"
#include "../proto_defs/proto_analysis_md_entry.h"
#include "../proto_defs/proto_vel_sampl_class_entry.h"
#include "../proto_defs/proto_intra_con_entry.h"
#include "../proto_defs/proto_energy_ctrl_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_temper_md.h"
#include "../proto_defs/proto_output_local.h"
#include "../proto_defs/proto_dafed_bias.h"

#define DEBUG_ME_OFF

void check_for_NaN(int,int,double*,double*,double*,char*,GENERAL_DATA*,CLASS*);
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void control_md(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                ANALYSIS *analysis)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"
  int ipt=1,jpt;

  int itime,iii,i;        
  int pt_time       = general_data->tempering_ctrl.switch_steps;
  int toggle=1;
  DAFED_INFO *dinfo = class->clatoms_info.daf_info;
  int ntime         = general_data->timeinfo.ntime;

  int ensopts_nve   = general_data->ensopts.nve;
  int ensopts_nvt   = general_data->ensopts.nvt;
  int ensopts_npt_i = general_data->ensopts.npt_i;
  int ensopts_npt_f = general_data->ensopts.npt_f;
  int npara_temps   = general_data->simopts.npara_temps;
  int npara_temps_proc = general_data->simopts.npara_temps_proc;
       
  int int_res_tra   = general_data->timeinfo.int_res_tra;
  int int_res_ter   = general_data->timeinfo.int_res_ter;

  int iwrite_screen = general_data->filenames.iwrite_screen;
  int iwrite_dump   = general_data->filenames.iwrite_dump;
  int iwrite_confp  = general_data->filenames.iwrite_confp;
  int iwrite_confv  = general_data->filenames.iwrite_confv;
  int iwrite_inst   = general_data->filenames.iwrite_inst;

  int ivel_smpl_on  = class->vel_samp_class.ivel_smpl_on;
  int nvx_smpl      = class->vel_samp_class.nvx_smpl;
  int nvnhc_smpl    = class->vel_samp_class.nvnhc_smpl;
  int iconstrnt     = bonded->constrnt.iconstrnt;

  int num_proc      = class->communicate.np;
  int myid          = class->communicate.myid;
  MPI_Comm world    = class->communicate.world;

  int num_proc_m    = class->communicate_m.np;
  int myid_m        = class->communicate_m.myid;
  MPI_Comm world_m  = class->communicate_m.world;

  int ioff        = general_data->simopts.npara_temps_proc_off;
  int jjj1,jjj2,jjj;

  int natm_tot    = class->clatoms_info.natm_tot;
  double *x,*y,*z;
  double econv_now;

  int bias_on     = dinfo[ipt].bias_on;
  int steps_bias  = dinfo[ipt].steps_bias;
  int num_bias    = dinfo[ipt].num_bias;

  general_data->timeinfo.exit_flag = 0;

/*=======================================================================*/
/* 0) Preliminary MD stuff                                               */

  for(ipt=1;ipt<=npara_temps_proc;ipt++){
    prelim_md(class,bonded,general_data,ipt);
  }/*endfor ipt*/
  Barrier(world);
  Barrier(world);
  //exit(0);
/*======================================================================*/
/* I) Write to Screen                                                   */

  if(myid_m==0){
    PRINT_LINE_STAR;
    printf("Running MD \n");
    PRINT_LINE_DASH;
  }/*endif*/

/*======================================================================*/
/* II) Loop over the specified number of time steps */

  for(itime = 1;itime<=ntime;itime++){
   (general_data->timeinfo.itime) = itime;
   (class->energy_ctrl.itime)     = itime;
   

/*---------------------------------------------------------------------*/
   for(ipt=1;ipt<=npara_temps_proc;ipt++){/* paratemp*/
/*---------------------------------------------------------------------*/
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   "positions.top",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   "velocities.top",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   "forces.top",general_data,class);
/*---------------------------------------------------------------------*/

     if(num_proc_m>1){ Barrier(world_m);}
     cputime(&(general_data->stat_avg[ipt].cpu1)); 
    /* (general_data->simopts.econs_exit_flag) = 0;*/
#ifdef DEBUG_ME
   printf("Step 1 : itime %d : myid %d ipt %d %d %d\n",itime,myid_m,ipt+ioff,
	  ioff,npara_temps_proc);fflush(stdout);
#endif
   /*---------------------------------------------------------------------*/
   /*   1)Do NVE dynamics                                                 */

     if(ensopts_nve==1){
       if((int_res_tra==0) && (int_res_ter==0)){
	 int_NVE(class,bonded,general_data,ipt);
       }else{
	 int_NVE_res(class,bonded,general_data,ipt);
       }/*endif*/
     }/*endif*/

   /*----------------------------------------------------------------------*/
   /*   2)Do NVT dynamics:                                                 */
     if(ensopts_nvt==1){
       if((int_res_tra==0) && (int_res_ter==0)){
	 int_NVT(class,bonded,general_data,ipt);
        }else{
	  if (dinfo[ipt].n_respa < 2 || dinfo[ipt].dafed_on == 0){
             int_NVT_res(class,bonded,general_data,ipt);
          }
          else{
             int_NVT_dafed_res(class,bonded,general_data,ipt);
          }
        }/*endif*/
     }/*endif*/
     //printf("after2\n");

   /*---------------------------------------------------------------------*/
   /*   3)Do isotropic npt dynamics:                                      */

     if(ensopts_npt_i==1){
       if((int_res_ter==0) && (int_res_tra==0)){
	 int_NPTI(class,bonded,general_data,ipt);
       }else{
	 int_NPTI_res(class,bonded,general_data,ipt);
       }/*endif*/
     }/*endif*/

   /*---------------------------------------------------------------------*/
   /*   4)Do flexible npt dynamics:                                       */

     if(ensopts_npt_f==1){
       if((int_res_ter==0) && (int_res_tra==0)){
	 int_NPTF(class,bonded,general_data,ipt);
       }else{
	 int_NPTF_res(class,bonded,general_data,ipt);
       }/*endif*/
     }/*endif*/

#ifdef DEBUG_ME
    printf("Step 2 : itime %d : myid %d ipt %d %d\n",itime,myid_m,ipt+ioff,ioff);fflush(stdout);
#endif

   /*----------------------------------------------------------------------*/
   /*   5)Do analysis md no longer:                                                 */
#ifdef DEVELOP_ANALYSIS
     analysis_md(class,general_data,bonded,analysis); 
#endif

   /*-----------------------------------------------------------------------*/
     /*check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   "positions.middle0",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   "velocities.middle0",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   "forces.middle0",general_data,class);*/
   /*----------------------------------------------------------------------*/
   /*   6)Calculate some simple averages                                   */

     cputime(&(general_data->stat_avg[ipt].cpu2)); 
     (general_data->stat_avg[ipt].cpu_now)=(general_data->stat_avg[ipt].cpu2)-
       (general_data->stat_avg[ipt].cpu1);
     (general_data->stat_avg[ipt].acpu) += (general_data->stat_avg[ipt].cpu2)-
       (general_data->stat_avg[ipt].cpu1);

     if(num_proc_m>1){ Barrier(world_m);}
     simpavg_md(&(general_data->timeinfo),&(general_data->stat_avg[ipt]),
		&(general_data->cell),&(bonded->constrnt),
		&(general_data->ensopts),&(general_data->simopts),
		&(general_data->ptens[ipt]),&(class->communicate),
		&(class->nbr_list.verlist[ipt]),&(class->energy_ctrl),pt_time);
     if(num_proc_m>1){ Barrier(world_m);}
#ifdef DEBUG_ME
    printf("Step 3 : itime %d : myid %d ipt %d %d\n",itime,myid_m,ipt+ioff,ioff);fflush(stdout);
#endif
    //printf("after6\n");

   /*-----------------------------------------------------------------------*/
     /*check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   "positions.middle",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   "velocities.middle",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   "forces.middle",general_data,class);*/
   /*-----------------------------------------------------------------------*/
   /*   7)Produce the output specified by the user                          */

    //econv_now = general_data->stat_avg[ipt].econv/((double)(general_data->timeinfo.itime%pt_time+1));
    /*check_econs_cut(general_data->simopts.econs_cut,
                    econv_now,
                    &(general_data->simopts.econs_exit_flag));*/

#ifdef I_LOVE_AUTO_EXIT
     if(num_proc_m>1){Bcast(&(general_data->timeinfo.exit_flag),1,MPI_INT,
			    0,world_m);}
#else
     general_data->timeinfo.exit_flag = 0;
#endif
     if(  ((itime % iwrite_screen))==0 ||
	  ((itime % iwrite_dump  ))==0 ||
	  ((itime % iwrite_confp ))==0 ||
	  ((itime % iwrite_confv ))==0 ||
	  ((itime % iwrite_inst  ))==0 ||
         (general_data->timeinfo.exit_flag == 1) ||
         (general_data->simopts.econs_exit_flag == 1)){
#ifdef DEBUG_ME
     printf("Step 3.5 (output) : itime %d : myid %d ipt %d %d\n",
             itime,myid_m,ipt+ioff,ioff);
#endif
       if(num_proc_m>1){ Barrier(world_m);}
       (general_data->filenames.ifile_open) = 0;    
       output_md(class,general_data,bonded,ipt);
     }/*endif*/
     if(num_proc_m>1){ Barrier(world_m);}

#ifdef DEBUG_ME
   printf("Step 4 : itime %d : myid %d ipt %d %d\n",itime,myid_m,ipt+ioff,ioff);fflush(stdout);
#endif
     //printf("after7\n");
   /*-----------------------------------------------------------------------*/
     /*check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   "positions.out",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   "velocities.out",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   "forces.out",general_data,class);*/
   /*---------------------------------------------------------------------*/
   /*   8)Resample the particle velocities if desired                     */

     if( (ivel_smpl_on==1) && (nvx_smpl!=0) ){
       if( (itime % nvx_smpl)==0){
	 control_vx_smpl(class,bonded,&(general_data->ensopts),
			 &(general_data->simopts),general_data,
			 general_data->error_check_on,ipt,1);
	 if(iconstrnt==1){
	   init_constraint(bonded,&(general_data->ptens[ipt]));
	 }/*endif:init constraints*/
       }/*endif*/
     }/*endif*/

   /*---------------------------------------------------------------------*/
   /*   9) Resample the extended class velocities if desired             */

     if( (ivel_smpl_on==1) && (nvnhc_smpl!=0) ){
       if((itime % nvnhc_smpl)==0){
	 control_vnhc_smpl(class,general_data,ipt,1);
       }/*endif*/
     }/*endif*/
   /*---------------------------------------------------------------------*/
   /*   10) Update the bias_potential for dafed if necessary              */
     if(bias_on==1&&itime%steps_bias==0&&general_data->stat_avg[ipt].i_bias<num_bias){
       general_data->stat_avg[ipt].i_bias += 1;
       if(myid==0){
         bias_update(class,general_data,ipt,general_data->stat_avg[ipt].i_bias);
       }
     }
     //printf("after10\n");
/*---------------------------------------------------------------------*/
  }/*endfor : para temps */
/*---------------------------------------------------------------------*/
  /*   10) Switch me baby                                                */

#ifdef DEBUG_ME
   printf("Step 5 : itime %d : myid %d\n",itime,myid_m);fflush(stdout);
#endif

   if(npara_temps>1){
     if(num_proc_m>1){ Barrier(world_m);}
     if((itime % iwrite_confp)==0){
       compute_wgt_frenkel(class,general_data,"md");
     }/*endif*/

     if(itime%pt_time==0){
       md_switch_pt(class,bonded,general_data,toggle,"md");
       /*switch between even and odd config swapping*/
       if(general_data->tempering_ctrl.para_type==2){
         for (ipt=1;ipt<=npara_temps_proc;ipt++){
           energy_control(class, bonded, general_data, ipt);
         }/*recalculate the force after switching*/
       }
       if(toggle==1){toggle=2;}else{toggle=1;}
     }/*endif time to switch*/
     if(num_proc_m>1){ Barrier(world_m);}
   }/*endif npara_temps>1*/
   
  /*---------------------------------------------------------------------*/
   /*for (ipt=1;ipt<=npara_temps_proc;ipt++){ 
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   "positions.switch",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   "velocities.switch",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   "forces.switch",general_data,class);
   
   }//endfor ipt*/
  /*---------------------------------------------------------------------*/
  /*   11) Check for exit condition                                      */

#ifdef DEBUG_ME
  printf("Step 6 : itime %d : myid %d\n",itime,myid_m);fflush(stdout);
#endif

#ifdef I_LOVE_AUTO_EXIT
    if(myid_m == 0)check_auto_exit(&(general_data->timeinfo.exit_flag));
#else
    general_data->timeinfo.exit_flag = 0;
#endif
    if(general_data->timeinfo.exit_flag == 1) itime = ntime;
    if(general_data->simopts.econs_exit_flag == 1) itime = ntime;

    if(num_proc_m>1){ 
      Barrier(world_m);
       iii = 1; jjj = 1;
       Allreduce(&iii,&jjj,1,MPI_INT,MPI_SUM,0,world_m);
       if(jjj!=num_proc_m){
         printf("control md fails at step %d\n",itime);
         Finalize();
         exit(1);
       }/*endif*/
      Barrier(world_m);
    }/*endif*/
    
    //printf("after all\n");
  /*---------------------------------------------------------------------*/
  }/*endfor:itime */

/*======================================================================*/
/*  III)Write to Screen                                                 */
  
  if(myid_m==0){
    PRINT_LINE_DASH;
    printf("Completed MD run \n");
    PRINT_LINE_STAR;
  }/*endif*/

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/





/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void prelim_md(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,int ipt)

/*=======================================================================*/
/*            Begin subprogram:                                          */
{   /*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */

#include "../typ_defs/typ_mask.h"
  /*  int ipt=1;*/

  int i,j,k,m,iflag,iii;

  int npairs_tmp             = 0;
  int npairs_res_tmp         = 0;
  int iflag_mass             = 1;
  double kinet_temp          = 0.0;
  double vintrat_temp        = 0.0;
  double vintert_temp        = 0.0;
  double vbondt_temp         = 0.0;
  double vbendt_temp         = 0.0;
  double vbend_bnd_bond_temp = 0.0;
  double vbend_bnd_bend_temp = 0.0;
  double vtorst_temp         = 0.0;
  double vonfot_temp         = 0.0;
  double vcoul_temp          = 0.0;
  double vvdw_temp           = 0.0;

  int npara_temps      = general_data->simopts.npara_temps;
  int npara_temps_proc = general_data->simopts.npara_temps_proc;
  int iptoff           = general_data->simopts.npara_temps_proc_off+ipt;
  int istart           = general_data->filenames.istart;
  int ipt_restart      = general_data->filenames.ipt_restart;

  int myid_m                 = class->communicate_m.myid;
  int myid                   = class->communicate.myid;
  MPI_Comm comm_forc         = class->communicate.comm_forc;
  int num_proc               = class->communicate.np;
  int np_forc                = class->class_comm_forc_pkg.num_proc; 

/*=======================================================================*/
/* I) Write to Screen                                                  */
  
  if(iptoff==1){
    if(myid==0){
      PRINT_LINE_STAR;
      printf("Performing preliminary tasks for md \n");
      PRINT_LINE_DASH;printf("\n");
    }/*endif*/
  }/*endif*/

/*=======================================================================*/
/*  II) Initialize In-output                                             */

  general_data->stat_avg[ipt].updates   = 0.0;
  general_data->stat_avg[ipt].acpu      = 0.0;

/*=======================================================================*/
/* III)Get Energy and particle Forces                                    */

  if(bonded->constrnt.iconstrnt==1){
     init_constraint(bonded,&(general_data->ptens[ipt]));
  }/*endif:init constraints, must be done before getting the energy*/

  general_data->stat_avg[ipt].iter_shake   = 0;
  general_data->stat_avg[ipt].iter_ratl    = 0;
  general_data->stat_avg[ipt].iter_23    = 0;
  general_data->stat_avg[ipt].iter_33    = 0;
  general_data->stat_avg[ipt].iter_46    = 0;

  (general_data->timeinfo.itime) = 0;
  (class->energy_ctrl.itime)     = 0;
  class->energy_ctrl.iget_full_inter = 1;
  class->energy_ctrl.iget_res_inter  = 0;
  if(general_data->timeinfo.int_res_ter==1){
    class->energy_ctrl.iget_res_inter=1;
  }
  class->energy_ctrl.iget_full_intra = 1;
  class->energy_ctrl.iget_res_intra  = 0;
  if((general_data->timeinfo.int_res_tra)==1){
    class->energy_ctrl.iget_res_intra=1;
  }

  if(iptoff==1){
    if(myid_m==0 ){
      printf("Getting initial energies.\n");
    }/*endif*/
  }/*endif*/

  energy_control(class,bonded,general_data,ipt);

  if(iptoff==npara_temps_proc){
    if(myid_m==0 ){
      printf("Completed initial energy.\n");
    }/*endif*/
  }/*endif*/

  get_tvten(&(class->clatoms_info),&(class->clatoms_pos[ipt]),
            &(general_data->stat_avg[ipt]),&(general_data->ptens[ipt]),
            &(general_data->cell));

/*=======================================================================*/
/* IV)Get NHC Forces                                                     */
  if((general_data->ensopts.nvt)==1){
     init_NHC_par(&(class->clatoms_info),&(class->clatoms_pos[ipt]),
              &(class->therm_info_class[ipt]),&(class->therm_class[ipt]),
              &(class->int_scr),iflag_mass,&(class->class_comm_forc_pkg));

    iflag = 0;
    nhc_vol_potkin(&(class->therm_info_class[ipt]),
		   &(class->therm_class[ipt]),
                   &(general_data->baro),&(general_data->par_rahman),
		   &(general_data->stat_avg[ipt]), 
                   &(general_data->statepoint[ipt]),iflag,
                     class->class_comm_forc_pkg.myid);
  }/*endif*/
  if((general_data->ensopts.npt_i)==1){
     init_NHCPI_par(&(class->clatoms_info),&(class->clatoms_pos[ipt]),
                &(class->therm_info_class[ipt]),&(class->therm_class[ipt]),
                &(general_data->baro),
                &(class->int_scr),&(class->class_comm_forc_pkg));
    iflag = 1;
    nhc_vol_potkin(&(class->therm_info_class[ipt]),
		   &(class->therm_class[ipt]),
                   &(general_data->baro),&(general_data->par_rahman),
		   &(general_data->stat_avg[ipt]), 
                   &(general_data->statepoint[ipt]),iflag,
                     class->class_comm_forc_pkg.myid);
  }/*endif*/
  if((general_data->ensopts.npt_f)==1){
     init_NHCPF_par(&(class->clatoms_info),&(class->clatoms_pos[ipt]),
                &(class->therm_info_class[ipt]),&(class->therm_class[ipt]),
                &(general_data->baro),
                &(general_data->par_rahman),&(general_data->cell),
                                            &(class->int_scr),
                &(class->class_comm_forc_pkg));
    iflag = 2;
    nhc_vol_potkin(&(class->therm_info_class[ipt]),
		   &(class->therm_class[ipt]),
                   &(general_data->baro),&(general_data->par_rahman),
		   &(general_data->stat_avg[ipt]), 
                   &(general_data->statepoint[ipt]),iflag,
                     class->class_comm_forc_pkg.myid);
  }/*endif*/

  if((general_data->ensopts.npt_i+general_data->ensopts.npt_f)==0){
    general_data->stat_avg[ipt].kinet_v       = 0.0;
  }/*endif*/
  if((general_data->ensopts.npt_i+general_data->ensopts.npt_f+
                                  general_data->ensopts.nvt)==0){
    general_data->stat_avg[ipt].kinet_nhc     = 0.0;
  }/*endif*/
/*========================================================================*/
/* V) Initialize free energy stuff                                        */

  if(bonded->bond_free[ipt].num != 0){
    for(i=1;i<= (bonded->bond_free[ipt].nhist);i++){
      bonded->bond_free[ipt].hist[i] = 0.0;
    }/*endfor*/
  }/*endif*/

  if(bonded->bend_free[ipt].num != 0){
    for(i=1;i<= (bonded->bend_free[ipt].nhist);i++){
      bonded->bend_free[ipt].hist[i] = 0.0;
    }/*endfor*/
  }/*endif*/

  if(bonded->tors_free[ipt].num == 1){
    for(i=1;i<= bonded->tors_free[ipt].nhist;i++){
      bonded->tors_free[ipt].hist[i] = 0.0;
    }/*endfor*/
  }/*endif*/
  if(bonded->tors_free[ipt].num == 2){
    for(i=1;i<= bonded->tors_free[ipt].nhist;i++){
    for(j=1;j<= bonded->tors_free[ipt].nhist;j++){
      bonded->tors_free[ipt].hist_2d[i][j] = 0.0;
    }/*endfor*/
    }/*endfor*/
  }/*endif*/

  if(bonded->rbar_sig_free[ipt].nfree != 0){
    for(i=1;i<=bonded->rbar_sig_free[ipt].nhist_sig;i++){
     for(j=1;j<=bonded->rbar_sig_free[ipt].nhist_bar;j++){
       bonded->rbar_sig_free[ipt].hist[j][i] = 0.0;
     }/*endfor*/
    }/*endfor*/
    for(m=1;m<=bonded->rbar_sig_free[ipt].nfree;m++){
     for(k=1;k<=bonded->rbar_sig_free[ipt].nhist_bar;k++){
        bonded->rbar_sig_free[ipt].hist_rn[m][k] = 0.0;
     }/*endfor*/
    }/*endfor*/
  }/*endif*/


/*=======================================================================*/
/* Vb) Initialise PT stuff         */

  general_data->tempering_ctrl.nswitch = 0.0;
  prelim_paratemp(&(general_data->stat_avg[ipt]),
		  &(class->clatoms_pos[ipt]),iptoff,npara_temps,
                  istart,ipt_restart);

/*=======================================================================*/
/* VI) Communicate initial energies                                      */
 //printf("NHC kin:%10g myid:%i\n",general_data->stat_avg[ipt].kinet_nhc,myid_m);
 general_data->stat_avg[ipt].vol = general_data->cell.vol;
 if(num_proc>1){
    simpavg_md_communicate(&(general_data->stat_avg[ipt]),
			   &(general_data->ensopts),
			   &(general_data->ptens[ipt]),0,&(class->communicate),
			   &(class->nbr_list.verlist[ipt]),
			   general_data->timeinfo.int_res_ter,1,1);
 }/*endif*/
 //printf("NHC kin:%10g myid:%i\n",general_data->stat_avg[ipt].kinet_nhc,myid_m);
/*=======================================================================*/
/*  VII) Write Energy to screen                                           */

  general_data->filenames.ifile_open = 1;
  general_data->timeinfo.itime       = 0;

  output_md(class,general_data,bonded,ipt);
 
/*=======================================================================*/
/* VIII) Reinitailize update flag */

  general_data->stat_avg[ipt].updates   = 0.0;

/*=======================================================================*/
/* IX) Write to Screen         */

  if(iptoff==npara_temps_proc){
    if(myid_m==0){
      printf("\n");
      PRINT_LINE_DASH;
      printf("Completed preliminary tasks for md \n");
      PRINT_LINE_STAR;printf("\n");
    }/*endif*/
  }/*endif*/
  Barrier(class->communicate.world);
  /*if(myid==1){
  for(i=class->therm_info_class[1].mytherm_start;i<=class->therm_info_class[1].mytherm_end;i++){
    for(j=1;j<=class->therm_info_class[1].len_nhc;j++){
      printf("mass i %i, j %i, %lg\n",i,j,class->therm_class[1].v_nhc[j][i]);
    }
  }
  }*/
  Barrier(class->communicate.world);
/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


